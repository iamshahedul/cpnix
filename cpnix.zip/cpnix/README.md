# CPNix — Production-Grade Independent Hosting Control Panel

[![License](https://img.shields.io/badge/License-Apache_2.0-blue.svg)](https://opensource.org/licenses/Apache-2.0)
[![Status](https://img.shields.io/badge/Status-Production--Ready-emerald.svg)](https://cpnix.org)
[![PHP](https://img.shields.io/badge/PHP-8.2%20%7C%208.3-indigo.svg)](https://php.net)
[![Go](https://img.shields.io/badge/Go-1.21%2B-cyan.svg)](https://go.dev)
[![Architecture](https://img.shields.io/badge/Architecture-Multi--Node%20mTLS-purple.svg)](docs/architecture.md)

**Domain:** [cpnix.org](https://cpnix.org)  
**Brand:** CPNix  
**Product Type:** Independent cPanel/WHM Alternative  

---

## 1. What is CPNix?

CPNix is an independent, enterprise-ready web hosting control panel engineered for server administrators, hosting providers, resellers, and website owners. Built entirely on an open-source infrastructure plane (Nginx, PHP-FPM, MariaDB, PowerDNS, Postfix, Dovecot, nftables), CPNix manages native Linux services with strict multi-tenant process and filesystem isolation.

CPNix completely decouples the control-plane web application from privileged node operations via a secure, dedicated Go daemon (`cpnix-agent`). The web application never runs as `root` and never executes arbitrary remote shell strings.

---

## 2. Key Architecture & Features

- **No Proprietary Dependencies**: Completely free of cPanel, WHM, Plesk, DirectAdmin, or commercial licensing constraints.
- **Privilege Separation & Security**:
  - Control plane runs as unprivileged user `cpnix:cpnix`.
  - Node agent communicates over mutual TLS (mTLS) with HMAC-SHA256 payload signing and nonce-based replay defense.
  - Zero dynamic shell concatenation (`sh -c`); fixed executable paths only.
- **Native Linux Multi-Tenant Isolation**:
  - Unique system UIDs/GIDs per customer (UID >= 10000).
  - Isolated home directories (`0750` mode with web group traversal).
  - Dedicated PHP-FPM pool per account running as the customer's own identity.
- **Multi-Server & Reseller Clustering**:
  - Centralized management of distributed Linux worker nodes.
  - Reseller system with hierarchical disk, bandwidth, and account quotas.
- **Durable Provisioning State Machine**:
  - 7-step durable provisioning workflow with step-level tracking, rollback compensation, and real-time execution logs.
- **Relational Databases & DNS**:
  - MariaDB least-privilege customer credentials.
  - PowerDNS Authoritative / BIND zone management with pre-reload validation.
- **Automated SSL/TLS**:
  - Let's Encrypt integration via automated ACME HTTP-01 challenges.
- **Verified Backups**:
  - Structured tarball snapshots with SHA-256 manifest integrity verification.

---

## 3. Technology Stack

| Layer | Component | Description |
| :--- | :--- | :--- |
| **Control Plane** | Laravel 11 / PHP 8.2+ | Eloquent ORM, Blade Templates, Tailwind CSS, Queue Jobs |
| **Node Agent** | Go 1.21+ | Hardened system daemon (`cpnix-agent`), mTLS HTTPS REST API |
| **Web Server** | Nginx (Primary) / Apache | Virtual host configuration with pre-reload syntax validation |
| **PHP Runtime** | PHP-FPM | Multi-version pool isolation (7.4, 8.0, 8.1, 8.2, 8.3) |
| **Database** | MariaDB / MySQL | Relational control plane & tenant database instances |
| **DNS** | PowerDNS / BIND | Authoritative DNS server with automatic SOA serial increment |
| **Mail** | Postfix + Dovecot | SMTP submission and IMAP/POP3 Maildir storage |
| **Firewall** | nftables / ufw / firewalld | Automated port and perimeter filtering |

---

## 4. Documentation Index

- [Architecture Specification](docs/architecture.md)
- [Security Model & Boundaries](docs/security-model.md)
- [Threat Model (STRIDE)](docs/threat-model.md)
- [Installation & Setup Guide](docs/installation.md)
- [Production Deployment Guide](docs/deployment.md)
- [Development Roadmap](docs/development-roadmap.md)
- [Compatibility Matrix](docs/compatibility-matrix.md)
- [Dependency Licenses](docs/dependency-licenses.md)
- [Backup & Disaster Recovery](docs/backup-and-recovery.md)
- [REST API Reference](docs/api.md)
- [Troubleshooting Guide](docs/troubleshooting.md)
- [Release Checklist](docs/release-checklist.md)

---

## 5. Quick Installation (Supported Linux Server)

On a clean installation of **Ubuntu 22.04/24.04 LTS**, **AlmaLinux 8/9**, or **Rocky Linux 8/9**:

```bash
# 1. Elevate to root
sudo -i

# 2. Download and verify the installer
curl -sSL https://raw.githubusercontent.com/cpnix/cpnix/main/scripts/install.sh -o install.sh
chmod +x install.sh

# 3. Run preflight check
./install.sh --preflight

# 4. Install CPNix Control Plane and Node Agent
./install.sh --domain panel.yourdomain.com --admin-email admin@yourdomain.com
```

---

## 6. Running Tests

CPNix includes a comprehensive cross-stack verification suite covering syntax integrity, security regex allowlists, path traversal defense, RBAC multi-tenant isolation, cryptographic HMAC signatures, hierarchical quotas, and relational schema integrity:

```bash
python3 scripts/test-runner.py
```

---

## 7. License

CPNix is open-source software licensed under the [Apache License 2.0](LICENSE).
All product names, logos, and brands are property of their respective owners.

