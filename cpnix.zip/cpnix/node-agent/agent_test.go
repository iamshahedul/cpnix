package main

import (
	"crypto/hmac"
	"crypto/sha256"
	"encoding/hex"
	"fmt"
	"testing"
	"time"

	"github.com/cpnix/cpnix/node-agent/internal/auth"
)

func TestHMACSignatureVerification(t *testing.T) {
	secret := "test_secret_key_12345"
	method := "POST"
	uri := "/api/v1/health"
	timestamp := fmt.Sprintf("%d", time.Now().Unix())
	nonce := "random_nonce_abc123"
	body := `{"ping":true}`

	// Generate valid signature
	message := fmt.Sprintf("%s\n%s\n%s\n%s\n%s", method, uri, timestamp, nonce, body)
	mac := hmac.New(sha256.New, []byte(secret))
	mac.Write([]byte(message))
	validSig := hex.EncodeToString(mac.Sum(nil))

	// 1. Should succeed with valid signature
	err := auth.VerifySignature(secret, method, uri, timestamp, nonce, body, validSig, 60)
	if err != nil {
		t.Fatalf("Expected valid signature, got error: %v", err)
	}

	// 2. Should reject duplicate nonce (replay attack)
	err = auth.VerifySignature(secret, method, uri, timestamp, nonce, body, validSig, 60)
	if err == nil {
		t.Fatal("Expected replay attack error on duplicate nonce, got nil")
	}

	// 3. Should reject invalid signature
	newNonce := "nonce_xyz_789"
	err = auth.VerifySignature(secret, method, uri, timestamp, newNonce, body, "bad_signature_hex", 60)
	if err == nil {
		t.Fatal("Expected error for forged signature, got nil")
	}

	// 4. Should reject expired timestamp
	oldTimestamp := fmt.Sprintf("%d", time.Now().Unix()-120)
	newerNonce := "nonce_old_111"
	err = auth.VerifySignature(secret, method, uri, oldTimestamp, newerNonce, body, validSig, 60)
	if err == nil {
		t.Fatal("Expected error for expired timestamp drift, got nil")
	}
}

