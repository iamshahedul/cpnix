package main

import (
	"context"
	"flag"
	"log"
	"os"
	"os/signal"
	"syscall"
	"time"

	"github.com/cpnix/cpnix/node-agent/internal/adapter"
	"github.com/cpnix/cpnix/node-agent/internal/config"
	"github.com/cpnix/cpnix/node-agent/internal/server"
)

func main() {
	configPath := flag.String("config", "/etc/cpnix/agent.conf", "Path to agent configuration file")
	flag.Parse()

	log.Println("==================================================")
	log.Println("CPNix Node Agent v1.0.0")
	log.Println("High-Security Privileged Infrastructure Daemon")
	log.Println("==================================================")

	cfg, err := config.LoadConfig(*configPath)
	if err != nil {
		log.Fatalf("FATAL: Failed to load configuration: %v", err)
	}

	sysAdapter := adapter.DetectAdapter()
	info, _ := sysAdapter.DetectSystem()
	log.Printf("Detected Host OS: %s (version: %s)", info.OSFamily, info.OSVersion)

	srv := server.NewServer(cfg, sysAdapter)

	// Graceful shutdown handling
	stop := make(chan os.Signal, 1)
	signal.Notify(stop, os.Interrupt, syscall.SIGTERM)

	go func() {
		if err := srv.Start(); err != nil {
			log.Printf("Agent server stopped: %v", err)
		}
	}()

	<-stop
	log.Println("Shutting down cpnix-agent gracefully...")

	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	if err := srv.Shutdown(ctx); err != nil {
		log.Printf("Error during shutdown: %v", err)
	}

	log.Println("Agent daemon stopped safely.")
}

