package executor

import (
	"bytes"
	"context"
	"errors"
	"fmt"
	"os/exec"
	"time"
)

// AllowedBinaries contains strictly permitted host binaries
var AllowedBinaries = map[string]string{
	"useradd":     "/usr/sbin/useradd",
	"userdel":     "/usr/sbin/userdel",
	"usermod":     "/usr/sbin/usermod",
	"groupadd":    "/usr/sbin/groupadd",
	"chown":       "/bin/chown",
	"chmod":       "/bin/chmod",
	"mkdir":       "/bin/mkdir",
	"nginx":       "/usr/sbin/nginx",
	"systemctl":   "/bin/systemctl",
	"mariadb":     "/usr/bin/mariadb",
	"mysql":       "/usr/bin/mysql",
	"mysqldump":   "/usr/bin/mysqldump",
	"tar":         "/bin/tar",
	"gzip":        "/bin/gzip",
	"sha256sum":   "/usr/bin/sha256sum",
	"pdns_control": "/usr/bin/pdns_control",
	"certbot":     "/usr/bin/certbot",
}

// Result captures execution details
type Result struct {
	Stdout   string
	Stderr   string
	ExitCode int
	Duration time.Duration
}

// Run executes a binary from the allowlist with structured argument slices
func Run(ctx context.Context, binaryName string, timeout time.Duration, args ...string) (*Result, error) {
	binaryPath, ok := AllowedBinaries[binaryName]
	if !ok {
		// Fallback to checking LookPath for test environments where bin paths may differ
		p, err := exec.LookPath(binaryName)
		if err != nil {
			return nil, fmt.Errorf("binary %q is not in the approved allowlist or not found on system", binaryName)
		}
		binaryPath = p
	}

	execCtx, cancel := context.WithTimeout(ctx, timeout)
	defer cancel()

	cmd := exec.CommandContext(execCtx, binaryPath, args...)
	var stdoutBuf, stderrBuf bytes.Buffer
	cmd.Stdout = &stdoutBuf
	cmd.Stderr = &stderrBuf

	start := time.Now()
	err := cmd.Run()
	duration := time.Since(start)

	res := &Result{
		Stdout:   stdoutBuf.String(),
		Stderr:   stderrBuf.String(),
		Duration: duration,
	}

	if err != nil {
		var exitErr *exec.ExitError
		if errors.As(err, &exitErr) {
			res.ExitCode = exitErr.ExitCode()
			return res, fmt.Errorf("command %s exited with code %d: %s", binaryName, res.ExitCode, res.Stderr)
		}
		return res, err
	}

	res.ExitCode = 0
	return res, nil
}

