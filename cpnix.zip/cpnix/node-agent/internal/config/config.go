package config

import (
	"encoding/json"
	"os"
)

type Config struct {
	ListenPort     int      `json:"listen_port"`
	ListenAddress  string   `json:"listen_address"`
	SharedSecret   string   `json:"shared_secret"`
	TLSCertPath    string   `json:"tls_cert_path"`
	TLSKeyPath     string   `json:"tls_key_path"`
	CACertPath     string   `json:"ca_cert_path"`
	EnableMTLS     bool     `json:"enable_mtls"`
	AllowedIPs     []string `json:"allowed_ips"`
	MaxReplaySecs  int64    `json:"max_replay_secs"`
	WebServer      string   `json:"web_server"` // "nginx" or "apache"
	DefaultPHP     string   `json:"default_php"`
	DatabaseEngine string   `json:"database_engine"` // "mariadb" or "mysql"
}

func DefaultConfig() *Config {
	return &Config{
		ListenPort:     9443,
		ListenAddress:  "0.0.0.0",
		SharedSecret:   "cpnix_default_node_token",
		TLSCertPath:    "/etc/cpnix/certs/agent.crt",
		TLSKeyPath:     "/etc/cpnix/certs/agent.key",
		CACertPath:     "/etc/cpnix/certs/ca.crt",
		EnableMTLS:     false,
		AllowedIPs:     []string{"127.0.0.1"},
		MaxReplaySecs:  60,
		WebServer:      "nginx",
		DefaultPHP:     "8.2",
		DatabaseEngine: "mariadb",
	}
}

func LoadConfig(path string) (*Config, error) {
	cfg := DefaultConfig()
	data, err := os.ReadFile(path)
	if err != nil {
		if os.IsNotExist(err) {
			return cfg, nil
		}
		return nil, err
	}

	if err := json.Unmarshal(data, cfg); err != nil {
		return nil, err
	}

	return cfg, nil
}

