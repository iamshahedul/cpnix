package adapter

import (
	"context"
	"fmt"
	"os"
	"strings"

	"github.com/cpnix/cpnix/node-agent/internal/executor"
)

type RHELAdapter struct{}

func NewRHELAdapter() *RHELAdapter {
	return &RHELAdapter{}
}

func (a *RHELAdapter) DetectSystem() (*SystemInfo, error) {
	info := &SystemInfo{
		OSFamily:  "almalinux",
		OSVersion: "9.3",
	}

	data, err := os.ReadFile("/etc/os-release")
	if err == nil {
		lines := strings.Split(string(data), "\n")
		for _, line := range lines {
			if strings.HasPrefix(line, "ID=") {
				info.OSFamily = strings.Trim(strings.TrimPrefix(line, "ID="), `"`)
			} else if strings.HasPrefix(line, "VERSION_ID=") {
				info.OSVersion = strings.Trim(strings.TrimPrefix(line, "VERSION_ID="), `"`)
			}
		}
	}

	return info, nil
}

func (a *RHELAdapter) GetNginxConfigDir() string {
	return "/etc/nginx/conf.d"
}

func (a *RHELAdapter) GetPhpPoolDir(version string) string {
	// Remi repo PHP-FPM pools
	vClean := strings.ReplaceAll(version, ".", "")
	return fmt.Sprintf("/etc/opt/remi/php%s/php-fpm.d", vClean)
}

func (a *RHELAdapter) TestNginxConfig(ctx context.Context) error {
	_, err := executor.Run(ctx, "nginx", defaultTimeout(), "-t")
	return err
}

func (a *RHELAdapter) ReloadNginx(ctx context.Context) error {
	if err := a.TestNginxConfig(ctx); err != nil {
		return fmt.Errorf("nginx config syntax check failed: %w", err)
	}
	_, err := executor.Run(ctx, "systemctl", defaultTimeout(), "reload", "nginx")
	return err
}

func (a *RHELAdapter) RestartPhpFpm(ctx context.Context, version string) error {
	vClean := strings.ReplaceAll(version, ".", "")
	service := fmt.Sprintf("php%s-php-fpm", vClean)
	_, err := executor.Run(ctx, "systemctl", defaultTimeout(), "reload", service)
	return err
}

func (a *RHELAdapter) ApplyFirewallRule(ctx context.Context, port int, proto string) error {
	rule := fmt.Sprintf("--add-port=%d/%s", port, proto)
	_, err := executor.Run(ctx, "firewall-cmd", defaultTimeout(), "--permanent", rule)
	if err != nil {
		return err
	}
	_, err = executor.Run(ctx, "firewall-cmd", defaultTimeout(), "--reload")
	return err
}

