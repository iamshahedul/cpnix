package adapter

import (
	"context"
	"os"
	"strings"
	"time"
)

type SystemInfo struct {
	OSFamily      string `json:"os_family"`      // "ubuntu", "debian", "rhel", "almalinux", "rocky"
	OSVersion     string `json:"os_version"`     // e.g. "22.04"
	KernelVersion string `json:"kernel_version"` // e.g. "5.15.0-101-generic"
}

type SystemAdapter interface {
	DetectSystem() (*SystemInfo, error)
	GetNginxConfigDir() string
	GetPhpPoolDir(version string) string
	ReloadNginx(ctx context.Context) error
	TestNginxConfig(ctx context.Context) error
	RestartPhpFpm(ctx context.Context, version string) error
	ApplyFirewallRule(ctx context.Context, port int, proto string) error
}

func DetectAdapter() SystemAdapter {
	data, err := os.ReadFile("/etc/os-release")
	if err == nil {
		content := strings.ToLower(string(data))
		if strings.Contains(content, "ubuntu") || strings.Contains(content, "debian") {
			return NewDebianAdapter()
		}
		if strings.Contains(content, "rhel") || strings.Contains(content, "almalinux") || strings.Contains(content, "rocky") || strings.Contains(content, "centos") {
			return NewRHELAdapter()
		}
	}

	// Default fallback to Debian/Ubuntu conventions
	return NewDebianAdapter()
}

func defaultTimeout() time.Duration {
	return 15 * time.Second
}

