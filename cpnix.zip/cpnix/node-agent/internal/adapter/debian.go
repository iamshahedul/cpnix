package adapter

import (
	"context"
	"fmt"
	"os"
	"strings"

	"github.com/cpnix/cpnix/node-agent/internal/executor"
)

type DebianAdapter struct{}

func NewDebianAdapter() *DebianAdapter {
	return &DebianAdapter{}
}

func (a *DebianAdapter) DetectSystem() (*SystemInfo, error) {
	info := &SystemInfo{
		OSFamily:  "ubuntu",
		OSVersion: "22.04",
	}

	data, err := os.ReadFile("/etc/os-release")
	if err == nil {
		lines := strings.Split(string(data), "\n")
		for _, line := range lines {
			if strings.HasPrefix(line, "ID=") {
				info.OSFamily = strings.Trim(strings.TrimPrefix(line, "ID="), `"`)
			} else if strings.HasPrefix(line, "VERSION_ID=") {
				info.OSVersion = strings.Trim(strings.TrimPrefix(line, "VERSION_ID="), `"`)
			}
		}
	}

	return info, nil
}

func (a *DebianAdapter) GetNginxConfigDir() string {
	return "/etc/nginx/sites-available"
}

func (a *DebianAdapter) GetPhpPoolDir(version string) string {
	return fmt.Sprintf("/etc/php/%s/fpm/pool.d", version)
}

func (a *DebianAdapter) TestNginxConfig(ctx context.Context) error {
	_, err := executor.Run(ctx, "nginx", defaultTimeout(), "-t")
	return err
}

func (a *DebianAdapter) ReloadNginx(ctx context.Context) error {
	if err := a.TestNginxConfig(ctx); err != nil {
		return fmt.Errorf("nginx config syntax check failed: %w", err)
	}
	_, err := executor.Run(ctx, "systemctl", defaultTimeout(), "reload", "nginx")
	return err
}

func (a *DebianAdapter) RestartPhpFpm(ctx context.Context, version string) error {
	service := fmt.Sprintf("php%s-fpm", version)
	_, err := executor.Run(ctx, "systemctl", defaultTimeout(), "reload", service)
	return err
}

func (a *DebianAdapter) ApplyFirewallRule(ctx context.Context, port int, proto string) error {
	// ufw allow port/proto
	rule := fmt.Sprintf("%d/%s", port, proto)
	_, err := executor.Run(ctx, "ufw", defaultTimeout(), "allow", rule)
	return err
}

