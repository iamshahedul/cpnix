package server

import (
	"bytes"
	"context"
	"fmt"
	"io"
	"log"
	"net/http"
	"time"

	"github.com/cpnix/cpnix/node-agent/internal/adapter"
	"github.com/cpnix/cpnix/node-agent/internal/auth"
	"github.com/cpnix/cpnix/node-agent/internal/config"
	"github.com/cpnix/cpnix/node-agent/internal/handlers"
)

type Server struct {
	cfg        *config.Config
	httpServer *http.Server
	handlers   *handlers.Handlers
}

func NewServer(cfg *config.Config, sysAdapter adapter.SystemAdapter) *Server {
	h := handlers.NewHandlers(sysAdapter)
	s := &Server{
		cfg:      cfg,
		handlers: h,
	}

	mux := http.NewServeMux()
	s.registerRoutes(mux)

	s.httpServer = &http.Server{
		Addr:         fmt.Sprintf("%s:%d", cfg.ListenAddress, cfg.ListenPort),
		Handler:      s.authMiddleware(mux),
		ReadTimeout:  30 * time.Second,
		WriteTimeout: 30 * time.Second,
	}

	return s
}

func (s *Server) registerRoutes(mux *http.ServeMux) {
	mux.HandleFunc("/api/v1/health", s.handlers.Health)
	mux.HandleFunc("/api/v1/metrics", s.handlers.Metrics)
	mux.HandleFunc("/api/v1/account/create", s.handlers.CreateAccount)
	mux.HandleFunc("/api/v1/account/suspend", s.handlers.SuspendAccount)
	mux.HandleFunc("/api/v1/account/unsuspend", s.handlers.UnsuspendAccount)
	mux.HandleFunc("/api/v1/account/terminate", s.handlers.TerminateAccount)
	mux.HandleFunc("/api/v1/php/pool", s.handlers.ConfigurePhpPool)
	mux.HandleFunc("/api/v1/web/vhost", s.handlers.ConfigureVhost)
	mux.HandleFunc("/api/v1/database/create", s.handlers.CreateDatabase)
	mux.HandleFunc("/api/v1/dns/sync", s.handlers.SyncDnsZone)
	mux.HandleFunc("/api/v1/backup/create", s.handlers.CreateBackup)
}

func (s *Server) authMiddleware(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		// Log inbound request
		start := time.Now()
		defer func() {
			log.Printf("[AUDIT] %s %s from %s - Duration: %v", r.Method, r.URL.Path, r.RemoteAddr, time.Since(start))
		}()

		// Read body for signature check and restore
		bodyBytes, err := io.ReadAll(r.Body)
		if err != nil {
			http.Error(w, `{"error":"unable to read request body"}`, http.StatusBadRequest)
			return
		}
		r.Body = io.NopCloser(bytes.NewBuffer(bodyBytes))

		// Signature verification headers
		timestamp := r.Header.Get("X-CPNix-Timestamp")
		nonce := r.Header.Get("X-CPNix-Nonce")
		signature := r.Header.Get("X-CPNix-Signature")

		if timestamp == "" || nonce == "" || signature == "" {
			http.Error(w, `{"error":"missing required authentication headers"}`, http.StatusUnauthorized)
			return
		}

		err = auth.VerifySignature(
			s.cfg.SharedSecret,
			r.Method,
			r.URL.Path,
			timestamp,
			nonce,
			string(bodyBytes),
			signature,
			s.cfg.MaxReplaySecs,
		)
		if err != nil {
			http.Error(w, fmt.Sprintf(`{"error":"unauthorized: %s"}`, err.Error()), http.StatusUnauthorized)
			return
		}

		next.ServeHTTP(w, r)
	})
}

func (s *Server) Start() error {
	log.Printf("Starting cpnix-agent on %s (mTLS: %v)", s.httpServer.Addr, s.cfg.EnableMTLS)
	if s.cfg.EnableMTLS {
		return s.httpServer.ListenAndServeTLS(s.cfg.TLSCertPath, s.cfg.TLSKeyPath)
	}
	return s.httpServer.ListenAndServe()
}

func (s *Server) Shutdown(ctx context.Context) error {
	return s.httpServer.Shutdown(ctx)
}

