package auth

import (
	"crypto/hmac"
	"crypto/sha256"
	"crypto/subtle"
	"encoding/hex"
	"errors"
	"fmt"
	"strconv"
	"sync"
	"time"
)

type NonceCache struct {
	mu     sync.Mutex
	nonces map[string]int64
}

var globalNonces = &NonceCache{
	nonces: make(map[string]int64),
}

func (nc *NonceCache) Add(nonce string, timestamp int64) bool {
	nc.mu.Lock()
	defer nc.mu.Unlock()

	// Clean entries older than 2 minutes
	cutoff := time.Now().Unix() - 120
	for k, v := range nc.nonces {
		if v < cutoff {
			delete(nc.nonces, k)
		}
	}

	if _, exists := nc.nonces[nonce]; exists {
		return false
	}

	nc.nonces[nonce] = timestamp
	return true
}

// VerifySignature validates method, uri, timestamp, nonce, and body against the shared secret
func VerifySignature(secret string, method, uri, timestampStr, nonce, body, signature string, maxDriftSecs int64) error {
	if secret == "" {
		return errors.New("missing shared secret")
	}

	ts, err := strconv.ParseInt(timestampStr, 10, 64)
	if err != nil {
		return errors.New("invalid timestamp format")
	}

	now := time.Now().Unix()
	drift := now - ts
	if drift < 0 {
		drift = -drift
	}

	if drift > maxDriftSecs {
		return fmt.Errorf("request timestamp drift too large (%d seconds)", drift)
	}

	if !globalNonces.Add(nonce, ts) {
		return errors.New("duplicate request nonce detected (replay attack)")
	}

	message := fmt.Sprintf("%s\n%s\n%s\n%s\n%s", method, uri, timestampStr, nonce, body)
	mac := hmac.New(sha256.New, []byte(secret))
	mac.Write([]byte(message))
	expectedSignature := hex.EncodeToString(mac.Sum(nil))

	if subtle.ConstantTimeCompare([]byte(expectedSignature), []byte(signature)) != 1 {
		return errors.New("invalid cryptographic HMAC signature")
	}

	return nil
}

