package isolation

import (
	"context"
	"fmt"
	"os"
	"path/filepath"
	"regexp"
	"time"

	"github.com/cpnix/cpnix/node-agent/internal/executor"
)

var validUserRegex = regexp.MustCompile(`^[a-z][a-z0-9_]{2,15}$`)

// CreateAccount provisions the Linux user, group, directory structure and permissions
func CreateAccount(ctx context.Context, username string, uid, gid int, homeDir string) error {
	if !validUserRegex.MatchString(username) {
		return fmt.Errorf("invalid username %q: must match ^[a-z][a-z0-9_]{2,15}$", username)
	}

	if uid < 10000 {
		return fmt.Errorf("uid %d violates CPNix security policy (minimum allowable UID is 10000)", uid)
	}

	timeout := 15 * time.Second

	// 1. Create system group if not existing
	_, _ = executor.Run(ctx, "groupadd", timeout, "-g", fmt.Sprintf("%d", gid), username)

	// 2. Create isolated Linux system user
	_, err := executor.Run(ctx, "useradd", timeout,
		"-u", fmt.Sprintf("%d", uid),
		"-g", fmt.Sprintf("%d", gid),
		"-d", homeDir,
		"-m",
		"-s", "/bin/false",
		username,
	)
	if err != nil {
		// If user already exists, proceed with directory and permission validation
	}

	// 3. Construct directory tree
	dirs := []struct {
		path string
		mode os.FileMode
	}{
		{homeDir, 0750},
		{filepath.Join(homeDir, "public_html"), 0755},
		{filepath.Join(homeDir, "logs"), 0750},
		{filepath.Join(homeDir, "tmp"), 0700},
		{filepath.Join(homeDir, "mail"), 0700},
		{filepath.Join(homeDir, ".ssl"), 0700},
	}

	for _, d := range dirs {
		if err := os.MkdirAll(d.path, d.mode); err != nil {
			return fmt.Errorf("failed to create directory %s: %w", d.path, err)
		}
		_ = os.Chmod(d.path, d.mode)
	}

	// 4. Deploy default index.html if not present
	indexPath := filepath.Join(homeDir, "public_html", "index.html")
	if _, err := os.Stat(indexPath); os.IsNotExist(err) {
		welcomeHtml := fmt.Sprintf(`<!DOCTYPE html>
<html>
<head><title>Welcome to %s</title></head>
<body style="font-family: sans-serif; text-align: center; padding: 50px; background: #0f172a; color: #f8fafc;">
    <h1>Welcome to %s</h1>
    <p>Your hosting account is successfully provisioned on CPNix.</p>
</body>
</html>`, username, username)
		_ = os.WriteFile(indexPath, []byte(welcomeHtml), 0644)
	}

	// 5. Apply ownership
	ownerSpec := fmt.Sprintf("%d:%d", uid, gid)
	_, _ = executor.Run(ctx, "chown", timeout, "-R", ownerSpec, homeDir)

	return nil
}

// SuspendUser locks the Linux user account
func SuspendUser(ctx context.Context, username string) error {
	timeout := 10 * time.Second
	_, err := executor.Run(ctx, "usermod", timeout, "-L", username)
	return err
}

// UnsuspendUser unlocks the Linux user account
func UnsuspendUser(ctx context.Context, username string) error {
	timeout := 10 * time.Second
	_, err := executor.Run(ctx, "usermod", timeout, "-U", username)
	return err
}

// DeleteAccount purges user and home files
func DeleteAccount(ctx context.Context, username string) error {
	timeout := 20 * time.Second
	_, err := executor.Run(ctx, "userdel", timeout, "-r", "-f", username)
	return err
}

