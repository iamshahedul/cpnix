module github.com/cpnix/cpnix/node-agent

go 1.21

