<?php

use App\Models\Server;
use App\Services\Agent\NodeAgentClient;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Schedule;

Artisan::command('cpnix:health-check', function () {
    $this->info("=== CPNix System Health Verification ===");
    
    $servers = Server::all();
    $this->line("Checking connectivity for {$servers->count()} registered nodes...");

    foreach ($servers as $server) {
        $client = new NodeAgentClient($server);
        $ping = $client->ping();

        if ($ping['success']) {
            $this->info("[OK] Server: {$server->name} ({$server->ip_address}) - Online");
            $server->update([
                'status' => 'online',
                'last_heartbeat_at' => now(),
            ]);
        } else {
            $this->error("[FAIL] Server: {$server->name} ({$server->ip_address}) - Unreachable ({$ping['error']})");
            $server->update(['status' => 'unreachable']);
        }
    }
})->purpose('Verify node agent communication and system health');

// Scheduled Tasks
Schedule::command('cpnix:health-check')->everyFiveMinutes();
Schedule::command('cpnix:collect-usage')->hourly();
Schedule::command('cpnix:renew-certificates')->dailyAt('02:00');
Schedule::command('cpnix:prune-backups')->dailyAt('04:00');
