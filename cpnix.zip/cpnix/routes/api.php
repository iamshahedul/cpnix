<?php

use App\Http\Controllers\Api\ApiAccountController;
use App\Http\Controllers\Api\ApiServerController;
use Illuminate\Support\Facades\Route;

Route::prefix('v1')->group(function () {
    // Accounts API
    Route::get('/accounts', [ApiAccountController::class, 'index']);
    Route::post('/accounts', [ApiAccountController::class, 'store']);
    Route::get('/accounts/{account}', [ApiAccountController::class, 'show']);

    // Servers API
    Route::get('/servers', [ApiServerController::class, 'index']);
    Route::get('/servers/{server}/health', [ApiServerController::class, 'health']);
});

