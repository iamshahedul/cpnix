<?php

use App\Http\Controllers\Admin\AccountController as AdminAccountController;
use App\Http\Controllers\Admin\AdminDashboardController;
use App\Http\Controllers\Admin\AuditLogController;
use App\Http\Controllers\Admin\PackageController as AdminPackageController;
use App\Http\Controllers\Admin\ServerController as AdminServerController;
use App\Http\Controllers\Admin\ServiceController as AdminServiceController;
use App\Http\Controllers\Auth\LoginController;
use App\Http\Controllers\Customer\BackupController as CustomerBackupController;
use App\Http\Controllers\Customer\CronController as CustomerCronController;
use App\Http\Controllers\Customer\CustomerDashboardController;
use App\Http\Controllers\Customer\DatabaseController as CustomerDatabaseController;
use App\Http\Controllers\Customer\DnsController as CustomerDnsController;
use App\Http\Controllers\Customer\DomainController as CustomerDomainController;
use App\Http\Controllers\Customer\EmailController as CustomerEmailController;
use App\Http\Controllers\Customer\FileManagerController;
use App\Http\Controllers\Customer\PhpController as CustomerPhpController;
use App\Http\Controllers\Customer\SslController as CustomerSslController;
use App\Http\Controllers\Reseller\ResellerAccountController;
use App\Http\Controllers\Reseller\ResellerDashboardController;
use Illuminate\Support\Facades\Route;

// Guest Authentication Routes
Route::middleware('guest')->group(function () {
    Route::get('/', [LoginController::class, 'showLoginForm'])->name('home');
    Route::get('/login', [LoginController::class, 'showLoginForm'])->name('login');
    Route::post('/login', [LoginController::class, 'login']);
});

Route::post('/logout', [LoginController::class, 'logout'])->middleware('auth')->name('logout');

// Administrator Routes
Route::prefix('admin')->name('admin.')->middleware(['auth'])->group(function () {
    Route::get('/dashboard', [AdminDashboardController::class, 'index'])->name('dashboard');

    // Server Management
    Route::resource('servers', AdminServerController::class);
    Route::post('servers/{server}/test', [AdminServerController::class, 'testConnection'])->name('servers.test');

    // Service Management
    Route::get('services', [AdminServiceController::class, 'index'])->name('services.index');
    Route::post('services/{server}/operate', [AdminServiceController::class, 'operate'])->name('services.operate');

    // Account Management
    Route::resource('accounts', AdminAccountController::class);
    Route::post('accounts/{account}/suspend', [AdminAccountController::class, 'suspend'])->name('accounts.suspend');
    Route::post('accounts/{account}/unsuspend', [AdminAccountController::class, 'unsuspend'])->name('accounts.unsuspend');

    // Packages & Audit
    Route::resource('packages', AdminPackageController::class);
    Route::get('audit-logs', [AuditLogController::class, 'index'])->name('audit-logs.index');
});

// Reseller Routes
Route::prefix('reseller')->name('reseller.')->middleware(['auth'])->group(function () {
    Route::get('/dashboard', [ResellerDashboardController::class, 'index'])->name('dashboard');
    Route::resource('accounts', ResellerAccountController::class);
    Route::post('accounts/{account}/suspend', [ResellerAccountController::class, 'suspend'])->name('accounts.suspend');
    Route::post('accounts/{account}/unsuspend', [ResellerAccountController::class, 'unsuspend'])->name('accounts.unsuspend');
});

// Customer Hosting Management Routes
Route::prefix('customer')->name('customer.')->middleware(['auth'])->group(function () {
    Route::get('/dashboard', [CustomerDashboardController::class, 'index'])->name('dashboard');

    // Domains & DNS
    Route::get('/domains', [CustomerDomainController::class, 'index'])->name('domains.index');
    Route::post('/domains', [CustomerDomainController::class, 'store'])->name('domains.store');
    Route::get('/dns', [CustomerDnsController::class, 'index'])->name('dns.index');
    Route::post('/dns/records', [CustomerDnsController::class, 'storeRecord'])->name('dns.record.store');
    Route::delete('/dns/records/{record}', [CustomerDnsController::class, 'destroyRecord'])->name('dns.record.destroy');

    // Databases
    Route::get('/databases', [CustomerDatabaseController::class, 'index'])->name('databases.index');
    Route::post('/databases', [CustomerDatabaseController::class, 'storeDatabase'])->name('databases.store');
    Route::post('/databases/user', [CustomerDatabaseController::class, 'storeUser'])->name('databases.store_user');

    // File Manager
    Route::get('/files', [FileManagerController::class, 'index'])->name('files.index');
    Route::get('/files/edit', [FileManagerController::class, 'editFile'])->name('files.edit');
    Route::post('/files/save', [FileManagerController::class, 'saveFile'])->name('files.save');

    // PHP Configuration & Directives
    Route::get('/php', [CustomerPhpController::class, 'index'])->name('php.index');
    Route::post('/php/version', [CustomerPhpController::class, 'updateVersion'])->name('php.version');
    Route::post('/php/directives', [CustomerPhpController::class, 'updateDirectives'])->name('php.directives');

    // Email
    Route::get('/email', [CustomerEmailController::class, 'index'])->name('email.index');
    Route::post('/email', [CustomerEmailController::class, 'store'])->name('email.store');

    // Cron Jobs
    Route::get('/cron', [CustomerCronController::class, 'index'])->name('cron.index');
    Route::post('/cron', [CustomerCronController::class, 'store'])->name('cron.store');
    Route::post('/cron/{cronJob}/toggle', [CustomerCronController::class, 'toggle'])->name('cron.toggle');
    Route::delete('/cron/{cronJob}', [CustomerCronController::class, 'destroy'])->name('cron.destroy');

    // SSL
    Route::get('/ssl', [CustomerSslController::class, 'index'])->name('ssl.index');
    Route::post('/ssl/request', [CustomerSslController::class, 'requestCertificate'])->name('ssl.request');

    // Backups
    Route::get('/backups', [CustomerBackupController::class, 'index'])->name('backups.index');
    Route::post('/backups', [CustomerBackupController::class, 'create'])->name('backups.create');
});
