<?php

namespace Tests\Feature;

use App\Models\HostingAccount;
use App\Models\User;
use App\Policies\HostingAccountPolicy;
use PHPUnit\Framework\TestCase;

class TenantIsolationTest extends TestCase
{
    public function test_customer_cannot_view_another_customer_account(): void
    {
        $policy = new HostingAccountPolicy();

        $customer1 = new User(['id' => 10, 'role' => 'customer']);
        $customer2 = new User(['id' => 20, 'role' => 'customer']);

        $account1 = new HostingAccount(['id' => 101, 'user_id' => 10]);
        $account2 = new HostingAccount(['id' => 102, 'user_id' => 20]);

        // Customer 1 viewing own account
        $this->assertTrue($policy->view($customer1, $account1));

        // Customer 1 attempting to view Customer 2 account
        $this->assertFalse($policy->view($customer1, $account2));

        // Customer 1 attempting to delete or modify Customer 2 account
        $this->assertFalse($policy->update($customer1, $account2));
        $this->assertFalse($policy->delete($customer1, $account2));
    }
}

