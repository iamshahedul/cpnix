<?php

namespace Tests\Unit;

use PHPUnit\Framework\TestCase;

class SecurityTest extends TestCase
{
    public function test_username_validation_regex(): void
    {
        $regex = '/^[a-z][a-z0-9_]{2,15}$/';

        $this->assertMatchesRegularExpression($regex, 'user123');
        $this->assertMatchesRegularExpression($regex, 'my_site');
        $this->assertMatchesRegularExpression($regex, 'alpha');

        // Illegal names
        $this->doesNotMatchRegularExpression($regex, 'root'); // Prohibited by reserved list
        $this->doesNotMatchRegularExpression($regex, '123user'); // Cannot start with number
        $this->doesNotMatchRegularExpression($regex, 'us'); // Too short (< 3)
        $this->doesNotMatchRegularExpression($regex, 'toolongusernameforlinuxaccount'); // Too long (> 16)
        $this->doesNotMatchRegularExpression($regex, 'user;rm -rf /'); // Command injection attempt
        $this->doesNotMatchRegularExpression($regex, 'user$name'); // Shell special char
    }

    public function test_path_traversal_is_blocked(): void
    {
        $baseHome = '/home/testuser';
        $attackPath = '../../etc/shadow';
        
        $clean = str_replace(['../', '..\\'], '', $attackPath);
        $fullPath = rtrim($baseHome, '/') . '/' . ltrim($clean, '/');

        $this->assertStringStartsWith($baseHome, $fullPath);
        $this->assertStringNotContainsString('../', $fullPath);
    }
}

