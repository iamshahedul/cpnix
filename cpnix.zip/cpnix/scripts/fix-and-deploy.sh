#!/usr/bin/env bash
# ==============================================================================
# CPNix Immediate VPS Fix & Deployment Script
# Solves: missing artisan, public/index.php, storage, database seeds
# ==============================================================================

set -euo pipefail

echo "=== Initializing CPNix Framework Foundation ==="

cd /var/www/cpnix

# 1. Create directory structure
mkdir -p public \
    bootstrap/cache \
    config \
    app/Providers \
    storage/app/public \
    storage/framework/cache/data \
    storage/framework/sessions \
    storage/framework/views \
    storage/logs

# 2. Deploy artisan CLI entry point
cat << 'EOF' > /var/www/cpnix/artisan
#!/usr/bin/env php
<?php

use Symfony\Component\Console\Input\ArgvInput;

define('LARAVEL_START', microtime(true));

require __DIR__.'/vendor/autoload.php';

$app = require_once __DIR__.'/bootstrap/app.php';

$status = $app->handleCommand(new ArgvInput);

exit($status);
EOF
chmod +x /var/www/cpnix/artisan

# 3. Deploy public/index.php Web Entry Point
cat << 'EOF' > /var/www/cpnix/public/index.php
<?php

use Illuminate\Http\Request;

define('LARAVEL_START', microtime(true));

if (file_exists($maintenance = __DIR__.'/../storage/framework/maintenance.php')) {
    require $maintenance;
}

require __DIR__.'/../vendor/autoload.php';

(require_once __DIR__.'/../bootstrap/app.php')
    ->handleRequest(Request::capture());
EOF

# 4. Deploy bootstrap files
cat << 'EOF' > /var/www/cpnix/bootstrap/app.php
<?php

use Illuminate\Foundation\Application;
use Illuminate\Foundation\Configuration\Exceptions;
use Illuminate\Foundation\Configuration\Middleware;

return Application::configure(basePath: dirname(__DIR__))
    ->withRouting(
        web: __DIR__.'/../routes/web.php',
        api: __DIR__.'/../routes/api.php',
        commands: __DIR__.'/../routes/console.php',
        health: '/up',
    )
    ->withMiddleware(function (Middleware $middleware) {
        $middleware->validateCsrfTokens(except: [
            'api/*',
        ]);
    })
    ->withExceptions(function (Exceptions $exceptions) {
        //
    })->create();
EOF

cat << 'EOF' > /var/www/cpnix/bootstrap/providers.php
<?php

return [
    App\Providers\AppServiceProvider::class,
];
EOF

cat << 'EOF' > /var/www/cpnix/app/Providers/AppServiceProvider.php
<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use Illuminate\Pagination\Paginator;

class AppServiceProvider extends ServiceProvider
{
    public function register(): void {}
    public function boot(): void
    {
        Paginator::useTailwind();
    }
}
EOF

# 5. Core configs
cat << 'EOF' > /var/www/cpnix/config/app.php
<?php
return [
    'name' => env('APP_NAME', 'CPNix'),
    'env' => env('APP_ENV', 'production'),
    'debug' => (bool) env('APP_DEBUG', false),
    'url' => env('APP_URL', 'http://localhost:8443'),
    'timezone' => 'UTC',
    'locale' => 'en',
    'fallback_locale' => 'en',
    'cipher' => 'AES-256-CBC',
    'key' => env('APP_KEY'),
];
EOF

cat << 'EOF' > /var/www/cpnix/config/auth.php
<?php
return [
    'defaults' => ['guard' => 'web', 'passwords' => 'users'],
    'guards' => ['web' => ['driver' => 'session', 'provider' => 'users']],
    'providers' => ['users' => ['driver' => 'eloquent', 'model' => App\Models\User::class]],
    'passwords' => ['users' => ['provider' => 'users', 'table' => 'password_reset_tokens', 'expire' => 60, 'throttle' => 60]],
];
EOF

cat << 'EOF' > /var/www/cpnix/config/database.php
<?php
return [
    'default' => env('DB_CONNECTION', 'mysql'),
    'connections' => [
        'mysql' => [
            'driver' => 'mysql',
            'host' => env('DB_HOST', '127.0.0.1'),
            'port' => env('DB_PORT', '3306'),
            'database' => env('DB_DATABASE', 'cpnix_control'),
            'username' => env('DB_USERNAME', 'cpnix_user'),
            'password' => env('DB_PASSWORD', ''),
            'charset' => 'utf8mb4',
            'collation' => 'utf8mb4_unicode_ci',
            'prefix' => '',
            'strict' => true,
        ],
    ],
    'migrations' => ['table' => 'migrations', 'update_date_on_publish' => true],
];
EOF

cat << 'EOF' > /var/www/cpnix/config/session.php
<?php
return [
    'driver' => env('SESSION_DRIVER', 'file'),
    'lifetime' => 120,
    'files' => storage_path('framework/sessions'),
    'cookie' => 'cpnix_session',
    'path' => '/',
    'http_only' => true,
    'same_site' => 'lax',
];
EOF

cat << 'EOF' > /var/www/cpnix/config/cache.php
<?php
return [
    'default' => env('CACHE_STORE', 'file'),
    'stores' => [
        'file' => [
            'driver' => 'file',
            'path' => storage_path('framework/cache/data'),
        ],
    ],
    'prefix' => 'cpnix_cache_',
];
EOF

cat << 'EOF' > /var/www/cpnix/config/logging.php
<?php
return [
    'default' => env('LOG_CHANNEL', 'single'),
    'channels' => [
        'single' => [
            'driver' => 'single',
            'path' => storage_path('logs/laravel.log'),
            'level' => 'debug',
        ],
    ],
];
EOF

# 6. Rebuild Composer Autoload & Run Laravel Initialization
export COMPOSER_ALLOW_SUPERUSER=1
composer dump-autoload -o

php artisan key:generate --force
php artisan migrate --force
php artisan db:seed --class=InitialSystemSeeder --force

# 7. Sync Agent Secret
if [ -f /etc/cpnix/agent.conf ]; then
    AGENT_SECRET=$(grep -o '"shared_secret": "[^"]*' /etc/cpnix/agent.conf | cut -d'"' -f4 || true)
    if [ -n "$AGENT_SECRET" ]; then
        mariadb -e "UPDATE cpnix_control.server_credentials SET auth_token='${AGENT_SECRET}' WHERE server_id=1;" || true
    fi
fi

# 8. Set File Permissions
chown -R www-data:www-data /var/www/cpnix
chmod -R 755 /var/www/cpnix
chmod -R 775 /var/www/cpnix/storage /var/www/cpnix/bootstrap/cache

# 9. Restart Services
systemctl restart php8.3-fpm
systemctl reload nginx

echo ""
echo "=== [SUCCESS] CPNix is now ONLINE and ready! ==="
echo "Access via browser: http://$(curl -s https://api.ipify.org || echo '103.42.5.195'):8443"

