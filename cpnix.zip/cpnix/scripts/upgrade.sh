#!/usr/bin/env bash
# ==============================================================================
# CPNix Safe Upgrade Orchestrator
# Performs pre-upgrade backups, database migrations, and health checks
# ==============================================================================

set -euo pipefail

echo "=== CPNix Safe Upgrade Initiated ==="

if [ "$(id -u)" -ne 0 ]; then
    echo "[ERROR] Upgrade script must be executed as root." >&2
    exit 1
fi

APP_DIR="/var/www/cpnix"
BACKUP_DIR="/var/cpnix/backups/system"
TIMESTAMP=$(date +%Y%m%d_%H%M%S)

mkdir -p "${BACKUP_DIR}"

echo "[1/5] Backing up Control Plane Database..."
mysqldump --single-transaction --quick cpnix_control > "${BACKUP_DIR}/cpnix_db_${TIMESTAMP}.sql"
gzip "${BACKUP_DIR}/cpnix_db_${TIMESTAMP}.sql"
echo "Database backed up to ${BACKUP_DIR}/cpnix_db_${TIMESTAMP}.sql.gz"

echo "[2/5] Putting Application in Maintenance Mode..."
cd "${APP_DIR}"
php artisan down --render="errors::503" || true

echo "[3/5] Running Database Migrations..."
php artisan migrate --force

echo "[4/5] Clearing and Precompiling Caches..."
php artisan config:cache
php artisan route:cache
php artisan view:cache

echo "[5/5] Bringing Application Back Online..."
php artisan up

echo "=== CPNix Upgrade Completed Successfully ==="

