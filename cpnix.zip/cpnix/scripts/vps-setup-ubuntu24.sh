#!/usr/bin/env bash
# ==============================================================================
# CPNix One-Click Automated Installer for Ubuntu 24.04 LTS
# Target: Production VPS Deployment
# ==============================================================================

set -euo pipefail

RED='\033[0;31m'
GREEN='\033[0;32m'
CYAN='\033[0;36m'
YELLOW='\033[1;33m'
BOLD='\033[1m'
NC='\033[0m'

clear
echo -e "${CYAN}======================================================${NC}"
echo -e "${CYAN}${BOLD}       CPNix Automated VPS Installer (Ubuntu 24.04)     ${NC}"
echo -e "${CYAN}======================================================${NC}"

# 1. Root Check
if [ "$(id -u)" -ne 0 ]; then
    echo -e "${RED}[ERROR] Please run this script as root (sudo -i or sudo bash).${NC}" >&2
    exit 1
fi

# Detect VPS IP
SERVER_IP=$(curl -4 -s ifconfig.me || curl -4 -s icanhazip.com || hostname -I | awk '{print $1}')
echo -e "Detected Server Public IP: ${GREEN}${SERVER_IP}${NC}"

PANEL_DOMAIN="${1:-${SERVER_IP}}"
echo -e "Configuring CPNix Panel for: ${BOLD}${PANEL_DOMAIN}${NC}\n"

# 2. Update System Packages
echo -e "${YELLOW}[1/8] Updating package lists & installing base tools...${NC}"
export DEBIAN_FRONTEND=noninteractive
apt-get update -y
apt-get install -y curl wget git unzip tar gzip software-properties-common ufw openssl

# 3. Install Web Server, PHP 8.3 & Extensions, MariaDB, Redis, Go
echo -e "\n${YELLOW}[2/8] Installing Nginx, PHP 8.3 stack, MariaDB & Redis...${NC}"
apt-get install -y nginx mariadb-server redis-server golang-go \
    php8.3 php8.3-cli php8.3-fpm php8.3-mysql php8.3-mbstring php8.3-xml \
    php8.3-curl php8.3-zip php8.3-bcmath php8.3-intl php8.3-sqlite3

# Install Composer globally if not present
if ! command -v composer &> /dev/null; then
    echo -e "Installing Composer..."
    curl -sS https://getcomposer.org/installer | php -- --install-dir=/usr/local/bin --filename=composer
fi

# 4. Create System User and Directory
echo -e "\n${YELLOW}[3/8] Setting up CPNix directories and permissions...${NC}"
groupadd -f cpnix-web
usermod -a -G cpnix-web www-data || true

mkdir -p /var/www/cpnix
mkdir -p /var/cpnix/backups
mkdir -p /var/cpnix/acme-challenges
mkdir -p /etc/cpnix/certs
mkdir -p /run/php

# 5. Extract or Sync Code to /var/www/cpnix
echo -e "\n${YELLOW}[4/8] Deploying application files...${NC}"
CURRENT_DIR="$(pwd)"

if [ -f "cpnix.zip" ]; then
    echo "Found cpnix.zip in current directory. Extracting..."
    unzip -q -o cpnix.zip -d /var/www/cpnix/
elif [ -f "/root/cpnix.zip" ]; then
    echo "Found /root/cpnix.zip. Extracting..."
    unzip -q -o /root/cpnix.zip -d /var/www/cpnix/
elif [ -d "app" ] && [ -f "artisan" ]; then
    echo "Copying from current repository..."
    cp -rn . /var/www/cpnix/
else
    echo "Downloading latest CPNix package..."
    wget -qO /tmp/cpnix.zip https://raw.githubusercontent.com/iamshahedul/cpnix/main/cpnix.zip || true
    if [ -f /tmp/cpnix.zip ]; then
        unzip -q -o /tmp/cpnix.zip -d /var/www/cpnix/
    fi
fi

cd /var/www/cpnix

# Fix directory structure if zip extracted into a subfolder
if [ -d "/var/www/cpnix/cpnix" ] && [ -f "/var/www/cpnix/cpnix/artisan" ]; then
    cp -rn /var/www/cpnix/cpnix/* /var/www/cpnix/
    cp -rn /var/www/cpnix/cpnix/.* /var/www/cpnix/ 2>/dev/null || true
    rm -rf /var/www/cpnix/cpnix
fi

# 6. Database Setup
echo -e "\n${YELLOW}[5/8] Configuring MariaDB database...${NC}"
systemctl enable --now mariadb
DB_PASS=$(openssl rand -hex 16)
DB_NAME="cpnix_control"
DB_USER="cpnix_user"

mariadb -e "CREATE DATABASE IF NOT EXISTS \`${DB_NAME}\` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;"
mariadb -e "CREATE USER IF NOT EXISTS '${DB_USER}'@'localhost' IDENTIFIED BY '${DB_PASS}';"
mariadb -e "GRANT ALL PRIVILEGES ON \`${DB_NAME}\`.* TO '${DB_USER}'@'localhost'; FLUSH PRIVILEGES;"

# 7. Environment File & Migrations
echo -e "\n${YELLOW}[6/8] Configuring Laravel environment and running database seeds...${NC}"
if [ ! -f .env ]; then
    cp .env.example .env
fi

sed -i "s/DB_DATABASE=.*/DB_DATABASE=${DB_NAME}/" .env
sed -i "s/DB_USERNAME=.*/DB_USERNAME=${DB_USER}/" .env
sed -i "s/DB_PASSWORD=.*/DB_PASSWORD=${DB_PASS}/" .env
sed -i "s|APP_URL=.*|APP_URL=http://${PANEL_DOMAIN}:8443|" .env

# Run Composer Install
composer install --no-interaction --prefer-dist --optimize-autoloader --no-dev

# Generate App Key & Run DB migrations with initial seed
php artisan key:generate --force
php artisan migrate --force
php artisan db:seed --class=InitialSystemSeeder --force

# Storage Permissions
chown -R www-data:www-data /var/www/cpnix
chmod -R 755 /var/www/cpnix
chmod -R 775 /var/www/cpnix/storage /var/www/cpnix/bootstrap/cache

# 8. Build & Install Node Agent (Go daemon)
echo -e "\n${YELLOW}[7/8] Compiling and starting cpnix-agent daemon...${NC}"
cd /var/www/cpnix/node-agent
go build -o /usr/local/bin/cpnix-agent cmd/cpnix-agent/main.go
chmod 755 /usr/local/bin/cpnix-agent

AGENT_SECRET=$(openssl rand -hex 32)
cat <<EOF > /etc/cpnix/agent.conf
{
  "listen_port": 9443,
  "listen_address": "127.0.0.1",
  "shared_secret": "${AGENT_SECRET}",
  "web_server": "nginx",
  "default_php": "8.3",
  "database_engine": "mariadb"
}
EOF
chmod 600 /etc/cpnix/agent.conf

cp /var/www/cpnix/node-agent/systemd/cpnix-agent.service /etc/systemd/system/
systemctl daemon-reload
systemctl enable --now cpnix-agent

# Update server credential in database for node agent
mariadb -e "UPDATE cpnix_control.server_credentials SET auth_token='${AGENT_SECRET}' WHERE server_id=1;" || true

# 9. Configure Nginx Control Panel VHost on Port 8443
echo -e "\n${YELLOW}[8/8] Configuring Nginx Control Panel virtual host...${NC}"
cat <<EOF > /etc/nginx/sites-available/cpnix-panel.conf
server {
    listen 8443 default_server;
    listen [::]:8443 default_server;
    server_name _;

    root /var/www/cpnix/public;
    index index.php index.html;

    client_max_body_size 128M;

    location / {
        try_files \$uri \$uri/ /index.php?\$args;
    }

    location ~ \.php$ {
        include fastcgi_params;
        fastcgi_pass unix:/run/php/php8.3-fpm.sock;
        fastcgi_param SCRIPT_FILENAME \$document_root\$fastcgi_script_name;
        fastcgi_read_timeout 300;
    }

    location ~ /\. {
        deny all;
    }
}
EOF

ln -sf /etc/nginx/sites-available/cpnix-panel.conf /etc/nginx/sites-enabled/
nginx -t && systemctl reload nginx

# Open Firewall Ports
ufw allow 22/tcp || true
ufw allow 80/tcp || true
ufw allow 443/tcp || true
ufw allow 8443/tcp || true

echo -e "\n${GREEN}======================================================${NC}"
echo -e "${GREEN}${BOLD}     CPNix Successfully Installed on Your VPS!         ${NC}"
echo -e "${GREEN}======================================================${NC}"
echo -e "Control Panel URL:   ${BOLD}http://${SERVER_IP}:8443${NC}"
echo -e "Default Admin Login:"
echo -e "  - Email:    ${BOLD}admin@cpnix.org${NC}"
echo -e "  - Password: ${BOLD}CPNixAdminPass2026!${NC}"
echo -e "\nReseller Login:"
echo -e "  - Email:    ${BOLD}reseller@cpnix.org${NC}"
echo -e "  - Password: ${BOLD}ResellerPass2026!${NC}"
echo -e "\nCustomer Login:"
echo -e "  - Email:    ${BOLD}client@cpnix.org${NC}"
echo -e "  - Password: ${BOLD}ClientPass2026!${NC}"
echo -e "\nDatabase Password:   ${DB_PASS}"
echo -e "Agent Daemon:        Active on 127.0.0.1:9443"
echo -e "${GREEN}======================================================${NC}\n"
