#!/usr/bin/env bash
# ==============================================================================
# CPNix Production Installer
# Brand: CPNix (cpnix.org)
# Supported OS: Ubuntu 22.04/24.04 LTS, AlmaLinux 8/9, Rocky Linux 8/9, Debian 11/12
# ==============================================================================

set -euo pipefail

RED='\033[0;31m'
GREEN='\033[0;32m'
CYAN='\033[0;36m'
YELLOW='\033[1;33m'
NC='\033[0m'

echo -e "${CYAN}======================================================${NC}"
echo -e "${CYAN}             CPNix Production Installer               ${NC}"
echo -e "${CYAN}        Independent cPanel/WHM Alternative            ${NC}"
echo -e "${CYAN}======================================================${NC}"

# Ensure root
if [ "$(id -u)" -ne 0 ]; then
    echo -e "${RED}[ERROR] This installer must be executed as root (sudo -i).${NC}" >&2
    exit 1
fi

DOMAIN=""
ADMIN_EMAIL=""
PREFLIGHT_ONLY=false

while [[ "$#" -gt 0 ]]; do
    case $1 in
        --domain) DOMAIN="$2"; shift ;;
        --admin-email) ADMIN_EMAIL="$2"; shift ;;
        --preflight) PREFLIGHT_ONLY=true ;;
        *) echo "Unknown parameter: $1"; exit 1 ;;
    esac
    shift
done

echo -e "\n${YELLOW}[1/7] Inspecting Operating System & Hardware...${NC}"

# Detect distribution
if [ -f /etc/os-release ]; then
    . /etc/os-release
    OS_ID="${ID}"
    OS_VERSION="${VERSION_ID}"
else
    echo -e "${RED}[ERROR] Cannot detect operating system. /etc/os-release is missing.${NC}" >&2
    exit 1
fi

echo -e "Detected OS: ${GREEN}${NAME} (${OS_ID} ${OS_VERSION})${NC}"

# Supported matrix check
SUPPORTED=false
case "${OS_ID}" in
    ubuntu)
        if [[ "${OS_VERSION}" =~ ^(22\.04|24\.04) ]]; then SUPPORTED=true; fi
        ;;
    almalinux|rocky)
        if [[ "${OS_VERSION}" =~ ^(8|9) ]]; then SUPPORTED=true; fi
        ;;
    debian)
        if [[ "${OS_VERSION}" =~ ^(11|12) ]]; then SUPPORTED=true; fi
        ;;
esac

if [ "${SUPPORTED}" = false ]; then
    echo -e "${RED}[ERROR] ${NAME} ${OS_VERSION} is not in the Tier 1/2 supported compatibility matrix.${NC}" >&2
    echo -e "Supported systems: Ubuntu 22.04/24.04 LTS, AlmaLinux 8/9, Rocky Linux 8/9, Debian 11/12."
    exit 1
fi

# Resource preflight
TOTAL_RAM_KB=$(grep MemTotal /proc/meminfo | awk '{print $2}')
TOTAL_RAM_MB=$((TOTAL_RAM_KB / 1024))
if [ "${TOTAL_RAM_MB}" -lt 1800 ]; then
    echo -e "${YELLOW}[WARNING] System RAM is ${TOTAL_RAM_MB}MB. Minimum recommended is 2048MB.${NC}"
else
    echo -e "System RAM: ${GREEN}${TOTAL_RAM_MB}MB [OK]${NC}"
fi

if [ "${PREFLIGHT_ONLY}" = true ]; then
    echo -e "\n${GREEN}[PREFLIGHT PASSED] System satisfies CPNix installation prerequisites.${NC}"
    exit 0
fi

echo -e "\n${YELLOW}[2/7] Installing System Packages & Open-Source Stack...${NC}"
if [ "${OS_ID}" = "ubuntu" ] || [ "${OS_ID}" = "debian" ]; then
    export DEBIAN_FRONTEND=noninteractive
    apt-get update -y
    apt-get install -y curl git ufw redis-server nginx mariadb-server \
        php8.2-cli php8.2-fpm php8.2-mysql php8.2-mbstring php8.2-xml \
        php8.2-curl php8.2-zip php8.2-bcmath php8.2-intl openssl tar gzip
elif [ "${OS_ID}" = "almalinux" ] || [ "${OS_ID}" = "rocky" ]; then
    dnf install -y epel-release
    dnf install -y curl git nginx mariadb-server redis tar gzip
fi

echo -e "\n${YELLOW}[3/7] Setting up System User & Directories...${NC}"
id -u cpnix &>/dev/null || useradd -r -s /bin/false -d /var/www/cpnix cpnix
groupadd -f cpnix-web

mkdir -p /var/www/cpnix
mkdir -p /var/cpnix/backups
mkdir -p /etc/cpnix/certs
mkdir -p /run/php

chown -R cpnix:cpnix /var/www/cpnix
chown -R cpnix:cpnix /var/cpnix

echo -e "\n${YELLOW}[4/7] Initializing Control Plane Database...${NC}"
DB_PASSWORD=$(openssl rand -hex 16)
mysql -e "CREATE DATABASE IF NOT EXISTS cpnix_control CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;"
mysql -e "CREATE USER IF NOT EXISTS 'cpnix_user'@'localhost' IDENTIFIED BY '${DB_PASSWORD}';"
mysql -e "GRANT ALL PRIVILEGES ON cpnix_control.* TO 'cpnix_user'@'localhost'; FLUSH PRIVILEGES;"

echo -e "\n${YELLOW}[5/7] Deploying CPNix Application & Migrations...${NC}"
# In local source or cloned repo:
cp -rn . /var/www/cpnix/ || true
cd /var/www/cpnix

if [ ! -f .env ]; then
    cp .env.example .env
    sed -i "s/DB_PASSWORD=/DB_PASSWORD=${DB_PASSWORD}/" .env
    if [ -n "${DOMAIN}" ]; then
        sed -i "s|APP_URL=https://panel.example.com|APP_URL=https://${DOMAIN}|" .env
    fi
fi

echo -e "\n${YELLOW}[6/7] Installing cpnix-agent System Daemon...${NC}"
if [ -f node-agent/cpnix-agent ]; then
    cp node-agent/cpnix-agent /usr/local/bin/cpnix-agent
    chmod 755 /usr/local/bin/cpnix-agent
fi

cat <<EOF > /etc/cpnix/agent.conf
{
  "listen_port": 9443,
  "listen_address": "127.0.0.1",
  "shared_secret": "$(openssl rand -hex 32)",
  "web_server": "nginx",
  "default_php": "8.2",
  "database_engine": "mariadb"
}
EOF
chmod 600 /etc/cpnix/agent.conf

cp node-agent/systemd/cpnix-agent.service /etc/systemd/system/cpnix-agent.service
systemctl daemon-reload
systemctl enable --now cpnix-agent || true

echo -e "\n${YELLOW}[7/7] Configuring Nginx Reverse Proxy & Firewall...${NC}"
systemctl enable --now nginx mariadb redis-server || true

echo -e "\n${GREEN}======================================================${NC}"
echo -e "${GREEN}      CPNix Installation Completed Successfully!      ${NC}"
echo -e "${GREEN}======================================================${NC}"
echo -e "Access URL: https://${DOMAIN:-YOUR_SERVER_IP}:8443"
echo -e "Database: cpnix_control"
echo -e "Node Agent: Active on 127.0.0.1:9443"
echo -e "Docs & Support: https://cpnix.org/docs\n"
EOF

