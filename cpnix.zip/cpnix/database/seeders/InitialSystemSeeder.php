<?php

namespace Database\Seeders;

use App\Models\AuditLog;
use App\Models\Database as AppDatabase;
use App\Models\DatabaseUser;
use App\Models\DnsZone;
use App\Models\EmailAccount;
use App\Models\HostingAccount;
use App\Models\HostingPackage;
use App\Models\Reseller;
use App\Models\Server;
use App\Models\ServerCredential;
use App\Models\SslCertificate;
use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;

class InitialSystemSeeder extends Seeder
{
    public function run(): void
    {
        // 1. Create Super Administrator
        $admin = User::firstOrCreate(
            ['email' => 'admin@cpnix.org'],
            [
                'name' => 'System Administrator',
                'password' => Hash::make('CPNixAdminPass2026!'),
                'role' => 'admin',
                'is_active' => true,
            ]
        );

        // 2. Create Infrastructure Server Node
        $server = Server::firstOrCreate(
            ['hostname' => 'node1.cpnix.org'],
            [
                'name' => 'Primary Production Node',
                'ip_address' => '127.0.0.1',
                'port' => 9443,
                'status' => 'online',
                'os_family' => 'ubuntu',
                'os_version' => '22.04',
                'kernel_version' => '5.15.0-generic',
                'agent_version' => '1.0.0',
                'max_accounts' => 100,
                'is_active' => true,
                'last_heartbeat_at' => now(),
            ]
        );

        ServerCredential::firstOrCreate(
            ['server_id' => $server->id],
            [
                'auth_token' => Str::random(48),
            ]
        );

        // 3. Create Standard Hosting Packages
        $starterPkg = HostingPackage::firstOrCreate(
            ['slug' => 'starter-plan'],
            [
                'name' => 'Starter Plan',
                'description' => 'Ideal for personal blogs and single websites',
                'disk_quota_mb' => 5000,
                'bandwidth_quota_mb' => 50000,
                'max_domains' => 1,
                'max_subdomains' => 5,
                'max_databases' => 2,
                'max_email_accounts' => 5,
                'max_cron_jobs' => 2,
                'allowed_php_versions' => ['8.1', '8.2', '8.3'],
                'backup_retention_days' => 7,
                'is_active' => true,
            ]
        );

        $proPkg = HostingPackage::firstOrCreate(
            ['slug' => 'pro-business'],
            [
                'name' => 'Pro Business Plan',
                'description' => 'High-performance shared hosting for e-commerce and agencies',
                'disk_quota_mb' => 25000,
                'bandwidth_quota_mb' => 250000,
                'max_domains' => 5,
                'max_subdomains' => 25,
                'max_databases' => 10,
                'max_email_accounts' => 25,
                'max_cron_jobs' => 10,
                'allowed_php_versions' => ['7.4', '8.0', '8.1', '8.2', '8.3'],
                'backup_retention_days' => 14,
                'is_active' => true,
            ]
        );

        // 4. Create Sample Reseller
        $resellerUser = User::firstOrCreate(
            ['email' => 'reseller@cpnix.org'],
            [
                'name' => 'Apex Web Solutions',
                'password' => Hash::make('ResellerPass2026!'),
                'role' => 'reseller',
                'is_active' => true,
            ]
        );

        $reseller = Reseller::firstOrCreate(
            ['user_id' => $resellerUser->id],
            [
                'company_name' => 'Apex Web Solutions Ltd.',
                'disk_quota_mb' => 100000,
                'bandwidth_quota_mb' => 1000000,
                'max_accounts' => 20,
            ]
        );

        // 5. Create Sample Customer & Hosting Account
        $customerUser = User::firstOrCreate(
            ['email' => 'client@cpnix.org'],
            [
                'name' => 'Demo Client',
                'password' => Hash::make('ClientPass2026!'),
                'role' => 'customer',
                'is_active' => true,
            ]
        );

        $account = HostingAccount::firstOrCreate(
            ['username' => 'usr_demo'],
            [
                'user_id' => $customerUser->id,
                'server_id' => $server->id,
                'package_id' => $proPkg->id,
                'reseller_id' => $reseller->id,
                'uid' => 10001,
                'gid' => 10001,
                'primary_domain' => 'demo.cpnix.org',
                'home_directory' => '/home/usr_demo',
                'php_version' => '8.2',
                'status' => 'ACTIVE',
                'provisioned_at' => now(),
            ]
        );

        // 6. Create Primary Domain & DNS Zone
        $account->domains()->firstOrCreate(
            ['domain' => 'demo.cpnix.org'],
            [
                'document_root' => '/home/usr_demo/public_html',
                'is_primary' => true,
                'is_subdomain' => false,
                'php_version' => '8.2',
                'ssl_enabled' => true,
            ]
        );

        $zone = DnsZone::firstOrCreate(
            ['name' => 'demo.cpnix.org'],
            [
                'hosting_account_id' => $account->id,
                'primary_ns' => 'ns1.cpnix.org',
                'admin_email' => 'hostmaster.demo.cpnix.org',
                'serial' => 2026110801,
                'ttl' => 3600,
            ]
        );

        $zone->records()->firstOrCreate(['name' => '@', 'type' => 'A'], ['content' => '127.0.0.1', 'ttl' => 3600]);
        $zone->records()->firstOrCreate(['name' => 'www', 'type' => 'CNAME'], ['content' => 'demo.cpnix.org.', 'ttl' => 3600]);
        $zone->records()->firstOrCreate(['name' => 'mail', 'type' => 'A'], ['content' => '127.0.0.1', 'ttl' => 3600]);
        $zone->records()->firstOrCreate(['name' => '@', 'type' => 'MX'], ['content' => 'mail.demo.cpnix.org.', 'priority' => 10, 'ttl' => 3600]);

        // 7. Create Database & User
        $db = AppDatabase::firstOrCreate(
            ['name' => 'usr_demo_app'],
            [
                'hosting_account_id' => $account->id,
                'charset' => 'utf8mb4',
                'collation' => 'utf8mb4_unicode_ci',
                'size_bytes' => 1048576,
            ]
        );

        $dbUser = DatabaseUser::firstOrCreate(
            ['username' => 'usr_demo_user'],
            [
                'hosting_account_id' => $account->id,
                'host' => 'localhost',
            ]
        );

        $db->users()->syncWithoutDetaching([$dbUser->id => ['privileges' => json_encode(['ALL'])]]);

        // 8. Create Email Mailbox
        EmailAccount::firstOrCreate(
            ['email' => 'info@demo.cpnix.org'],
            [
                'hosting_account_id' => $account->id,
                'local_part' => 'info',
                'domain' => 'demo.cpnix.org',
                'password_hash' => '{SHA512-CRYPT}$6$dummyhash',
                'quota_mb' => 1000,
                'used_mb' => 12,
                'is_active' => true,
            ]
        );

        // 9. Create SSL Record
        SslCertificate::firstOrCreate(
            ['domain' => 'demo.cpnix.org'],
            [
                'hosting_account_id' => $account->id,
                'provider' => 'lets_encrypt',
                'certificate' => '-----BEGIN CERTIFICATE-----\n[Mock Certificate]\n-----END CERTIFICATE-----',
                'private_key' => '-----BEGIN RSA PRIVATE KEY-----\n[Mock Key]\n-----END RSA PRIVATE KEY-----',
                'issued_at' => now(),
                'expires_at' => now()->addDays(90),
                'auto_renew' => true,
                'status' => 'active',
            ]
        );

        AuditLog::record('system.seeded', 'User', $admin->id, ['environment' => 'development']);
    }
}

