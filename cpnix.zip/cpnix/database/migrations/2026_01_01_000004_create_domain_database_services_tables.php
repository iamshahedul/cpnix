<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        // Account Domains & Subdomains
        Schema::create('account_domains', function (Blueprint $table) {
            $table->id();
            $table->foreignId('hosting_account_id')->constrained('hosting_accounts')->cascadeOnDelete();
            $table->string('domain')->unique();
            $table->string('document_root');
            $table->boolean('is_primary')->default(false);
            $table->boolean('is_subdomain')->default(false);
            $table->string('php_version', 10)->nullable();
            $table->boolean('ssl_enabled')->default(false);
            $table->boolean('force_https')->default(true);
            $table->timestamps();
            $table->softDeletes();
        });

        // DNS Zones & Records
        Schema::create('dns_zones', function (Blueprint $table) {
            $table->id();
            $table->foreignId('hosting_account_id')->constrained('hosting_accounts')->cascadeOnDelete();
            $table->string('name')->unique();
            $table->string('primary_ns');
            $table->string('admin_email');
            $table->unsignedBigInteger('serial')->default(2026110801);
            $table->unsignedInteger('refresh')->default(10800);
            $table->unsignedInteger('retry')->default(3600);
            $table->unsignedInteger('expire')->default(604800);
            $table->unsignedInteger('ttl')->default(3600);
            $table->boolean('is_active')->default(true);
            $table->timestamps();
        });

        Schema::create('dns_records', function (Blueprint $table) {
            $table->id();
            $table->foreignId('dns_zone_id')->constrained('dns_zones')->cascadeOnDelete();
            $table->string('name');
            $table->enum('type', ['A', 'AAAA', 'CNAME', 'MX', 'TXT', 'NS', 'SRV', 'CAA', 'PTR'])->index();
            $table->text('content');
            $table->unsignedInteger('ttl')->default(3600);
            $table->unsignedInteger('priority')->nullable();
            $table->timestamps();
        });

        // Databases & Users
        Schema::create('databases', function (Blueprint $table) {
            $table->id();
            $table->foreignId('hosting_account_id')->constrained('hosting_accounts')->cascadeOnDelete();
            $table->string('name')->unique(); // e.g. usr_dbname
            $table->string('charset')->default('utf8mb4');
            $table->string('collation')->default('utf8mb4_unicode_ci');
            $table->bigInteger('size_bytes')->default(0);
            $table->timestamps();
        });

        Schema::create('database_users', function (Blueprint $table) {
            $table->id();
            $table->foreignId('hosting_account_id')->constrained('hosting_accounts')->cascadeOnDelete();
            $table->string('username')->unique(); // e.g. usr_dbuser
            $table->string('host')->default('localhost');
            $table->timestamps();
        });

        Schema::create('database_grants', function (Blueprint $table) {
            $table->id();
            $table->foreignId('database_id')->constrained('databases')->cascadeOnDelete();
            $table->foreignId('database_user_id')->constrained('database_users')->cascadeOnDelete();
            $table->json('privileges')->nullable(); // ALL or ['SELECT', 'INSERT', ...]
            $table->timestamps();
        });

        // Email Accounts
        Schema::create('email_accounts', function (Blueprint $table) {
            $table->id();
            $table->foreignId('hosting_account_id')->constrained('hosting_accounts')->cascadeOnDelete();
            $table->string('email')->unique();
            $table->string('local_part');
            $table->string('domain');
            $table->string('password_hash');
            $table->bigInteger('quota_mb')->default(1000);
            $table->bigInteger('used_mb')->default(0);
            $table->boolean('is_active')->default(true);
            $table->timestamps();
        });

        // Cron Jobs
        Schema::create('cron_jobs', function (Blueprint $table) {
            $table->id();
            $table->foreignId('hosting_account_id')->constrained('hosting_accounts')->cascadeOnDelete();
            $table->string('minute')->default('*');
            $table->string('hour')->default('*');
            $table->string('day_of_month')->default('*');
            $table->string('month')->default('*');
            $table->string('day_of_week')->default('*');
            $table->text('command');
            $table->text('description')->nullable();
            $table->boolean('is_active')->default(true);
            $table->timestamp('last_run_at')->nullable();
            $table->integer('last_exit_code')->nullable();
            $table->timestamps();
        });

        // SSL Certificates
        Schema::create('ssl_certificates', function (Blueprint $table) {
            $table->id();
            $table->foreignId('hosting_account_id')->constrained('hosting_accounts')->cascadeOnDelete();
            $table->string('domain')->index();
            $table->enum('provider', ['lets_encrypt', 'custom', 'self_signed'])->default('lets_encrypt');
            $table->text('certificate');
            $table->text('private_key'); // encrypted
            $table->text('ca_bundle')->nullable();
            $table->timestamp('issued_at')->nullable();
            $table->timestamp('expires_at')->nullable();
            $table->boolean('auto_renew')->default(true);
            $table->enum('status', ['active', 'expired', 'renewing', 'failed'])->default('active');
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('ssl_certificates');
        Schema::dropIfExists('cron_jobs');
        Schema::dropIfExists('email_accounts');
        Schema::dropIfExists('database_grants');
        Schema::dropIfExists('database_users');
        Schema::dropIfExists('databases');
        Schema::dropIfExists('dns_records');
        Schema::dropIfExists('dns_zones');
        Schema::dropIfExists('account_domains');
    }
};

