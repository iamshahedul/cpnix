<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        // Dedicated SFTP Accounts
        Schema::create('sftp_accounts', function (Blueprint $table) {
            $table->id();
            $table->foreignId('hosting_account_id')->constrained('hosting_accounts')->cascadeOnDelete();
            $table->string('username')->unique();
            $table->string('home_directory'); // e.g. /home/usr/public_html
            $table->text('public_key')->nullable();
            $table->boolean('password_auth_allowed')->default(true);
            $table->boolean('is_active')->default(true);
            $table->timestamps();
        });

        // Email Aliases & Forwarders
        Schema::create('email_aliases', function (Blueprint $table) {
            $table->id();
            $table->foreignId('hosting_account_id')->constrained('hosting_accounts')->cascadeOnDelete();
            $table->string('source_email')->unique();
            $table->string('destination_email');
            $table->boolean('is_active')->default(true);
            $table->timestamps();
        });

        // Firewall Rules (nftables / ufw)
        Schema::create('firewall_rules', function (Blueprint $table) {
            $table->id();
            $table->foreignId('server_id')->constrained('servers')->cascadeOnDelete();
            $table->integer('port');
            $table->enum('protocol', ['tcp', 'udp', 'both'])->default('tcp');
            $table->enum('action', ['allow', 'deny', 'reject'])->default('allow');
            $table->string('source_ip')->default('0.0.0.0/0');
            $table->string('description')->nullable();
            $table->boolean('is_active')->default(true);
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('firewall_rules');
        Schema::dropIfExists('email_aliases');
        Schema::dropIfExists('sftp_accounts');
    }
};
