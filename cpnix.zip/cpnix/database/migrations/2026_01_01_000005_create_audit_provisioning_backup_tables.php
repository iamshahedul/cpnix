<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        // Backups
        Schema::create('backups', function (Blueprint $table) {
            $table->id();
            $table->foreignId('hosting_account_id')->constrained('hosting_accounts')->cascadeOnDelete();
            $table->string('filename')->unique();
            $table->string('storage_path');
            $table->bigInteger('size_bytes')->default(0);
            $table->string('checksum_sha256', 64)->nullable();
            $table->enum('status', ['PENDING', 'PROCESSING', 'COMPLETED', 'FAILED', 'VERIFIED'])->default('PENDING')->index();
            $table->enum('type', ['full', 'homedir_only', 'databases_only'])->default('full');
            $table->json('manifest')->nullable();
            $table->text('error_details')->nullable();
            $table->timestamp('completed_at')->nullable();
            $table->timestamp('verified_at')->nullable();
            $table->timestamps();
        });

        // Provisioning Orchestration & Durable Steps
        Schema::create('provisioning_jobs', function (Blueprint $table) {
            $table->id();
            $table->uuid('uuid')->unique();
            $table->foreignId('hosting_account_id')->constrained('hosting_accounts')->cascadeOnDelete();
            $table->string('action'); // create_account, suspend_account, unsuspend_account, terminate_account, change_package
            $table->enum('status', ['QUEUED', 'RUNNING', 'COMPLETED', 'FAILED', 'ROLLED_BACK'])->default('QUEUED')->index();
            $table->integer('total_steps')->default(0);
            $table->integer('completed_steps')->default(0);
            $table->text('error_message')->nullable();
            $table->json('payload')->nullable();
            $table->timestamp('started_at')->nullable();
            $table->timestamp('completed_at')->nullable();
            $table->timestamps();
        });

        Schema::create('provisioning_steps', function (Blueprint $table) {
            $table->id();
            $table->foreignId('provisioning_job_id')->constrained('provisioning_jobs')->cascadeOnDelete();
            $table->integer('step_number');
            $table->string('name'); // e.g. create_linux_user, configure_fpm_pool, setup_nginx_vhost
            $table->enum('status', ['PENDING', 'RUNNING', 'COMPLETED', 'FAILED', 'SKIPPED', 'COMPENSATED'])->default('PENDING');
            $table->text('input_data')->nullable();
            $table->text('output_data')->nullable();
            $table->text('error_message')->nullable();
            $table->timestamp('started_at')->nullable();
            $table->timestamp('completed_at')->nullable();
            $table->timestamps();
        });

        // Immutable Audit Logs
        Schema::create('audit_logs', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->nullable()->constrained('users')->nullOnDelete();
            $table->string('actor_type')->nullable(); // user, api_token, system
            $table->string('actor_name')->nullable();
            $table->string('action')->index(); // account.created, dns.record_added, server.enrolled
            $table->string('entity_type')->nullable()->index(); // HostingAccount, DnsZone, Server
            $table->unsignedBigInteger('entity_id')->nullable()->index();
            $table->string('ip_address', 45)->nullable();
            $table->text('user_agent')->nullable();
            $table->json('old_values')->nullable();
            $table->json('new_values')->nullable();
            $table->timestamps();
        });

        // Scoped API Tokens
        Schema::create('api_tokens', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained('users')->cascadeOnDelete();
            $table->string('name');
            $table->string('token_hash', 64)->unique();
            $table->json('abilities')->nullable(); // ["accounts:read", "accounts:write"]
            $table->timestamp('last_used_at')->nullable();
            $table->timestamp('expires_at')->nullable();
            $table->timestamps();
        });

        // Resource Usage Snapshots
        Schema::create('usage_snapshots', function (Blueprint $table) {
            $table->id();
            $table->foreignId('hosting_account_id')->constrained('hosting_accounts')->cascadeOnDelete();
            $table->bigInteger('disk_used_bytes')->default(0);
            $table->bigInteger('inode_count')->default(0);
            $table->bigInteger('bandwidth_bytes')->default(0);
            $table->bigInteger('database_size_bytes')->default(0);
            $table->integer('email_count')->default(0);
            $table->timestamp('recorded_at')->index();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('usage_snapshots');
        Schema::dropIfExists('api_tokens');
        Schema::dropIfExists('audit_logs');
        Schema::dropIfExists('provisioning_steps');
        Schema::dropIfExists('provisioning_jobs');
        Schema::dropIfExists('backups');
    }
};

