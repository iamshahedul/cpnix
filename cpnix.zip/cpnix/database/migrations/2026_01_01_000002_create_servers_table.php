<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('servers', function (Blueprint $table) {
            $table->id();
            $table->string('name')->unique();
            $table->string('hostname')->unique();
            $table->string('ip_address', 45)->unique();
            $table->string('ipv6_address', 45)->nullable();
            $table->integer('port')->default(9443);
            $table->enum('status', ['online', 'offline', 'maintenance', 'unreachable'])->default('offline')->index();
            $table->string('os_family')->default('ubuntu'); // ubuntu, rhel, debian
            $table->string('os_version')->nullable();
            $table->string('kernel_version')->nullable();
            $table->string('agent_version')->nullable();
            $table->integer('max_accounts')->default(100);
            $table->json('capabilities')->nullable(); // php_versions, web_servers, dns, etc.
            $table->json('latest_telemetry')->nullable(); // cpu, ram, disk
            $table->timestamp('last_heartbeat_at')->nullable();
            $table->boolean('is_active')->default(true);
            $table->timestamps();
            $table->softDeletes();
        });

        Schema::create('server_credentials', function (Blueprint $table) {
            $table->id();
            $table->foreignId('server_id')->constrained('servers')->cascadeOnDelete();
            $table->text('auth_token'); // HMAC shared secret (encrypted via Laravel Crypt)
            $table->text('client_certificate')->nullable();
            $table->text('client_private_key')->nullable();
            $table->text('ca_certificate')->nullable();
            $table->timestamp('expires_at')->nullable();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('server_credentials');
        Schema::dropIfExists('servers');
    }
};

