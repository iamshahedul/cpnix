<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('resellers', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->unique()->constrained('users')->cascadeOnDelete();
            $table->string('company_name')->nullable();
            $table->bigInteger('disk_quota_mb')->default(50000); // 50 GB
            $table->bigInteger('bandwidth_quota_mb')->default(500000); // 500 GB
            $table->integer('max_accounts')->default(25);
            $table->json('permitted_servers')->nullable(); // array of server_ids
            $table->json('branding')->nullable(); // custom logo, header color
            $table->boolean('is_suspended')->default(false);
            $table->string('suspension_reason')->nullable();
            $table->timestamps();
            $table->softDeletes();
        });

        Schema::create('hosting_packages', function (Blueprint $table) {
            $table->id();
            $table->foreignId('reseller_id')->nullable()->constrained('resellers')->nullOnDelete();
            $table->string('name');
            $table->string('slug')->index();
            $table->text('description')->nullable();
            $table->bigInteger('disk_quota_mb')->default(5000); // 5 GB
            $table->bigInteger('bandwidth_quota_mb')->default(50000); // 50 GB
            $table->integer('max_domains')->default(1);
            $table->integer('max_subdomains')->default(5);
            $table->integer('max_databases')->default(3);
            $table->integer('max_email_accounts')->default(10);
            $table->integer('max_ftp_accounts')->default(1);
            $table->integer('max_cron_jobs')->default(5);
            $table->json('allowed_php_versions')->nullable(); // ["8.1", "8.2", "8.3"]
            $table->boolean('allow_ssh_access')->default(false);
            $table->boolean('allow_custom_dns')->default(true);
            $table->boolean('allow_ssl_management')->default(true);
            $table->integer('backup_retention_days')->default(7);
            $table->boolean('is_active')->default(true);
            $table->timestamps();
            $table->softDeletes();
        });

        Schema::create('hosting_accounts', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained('users')->cascadeOnDelete();
            $table->foreignId('reseller_id')->nullable()->constrained('resellers')->nullOnDelete();
            $table->foreignId('server_id')->constrained('servers')->cascadeOnDelete();
            $table->foreignId('package_id')->constrained('hosting_packages')->restrictOnDelete();
            $table->string('username', 32)->unique();
            $table->integer('uid')->unique();
            $table->integer('gid');
            $table->string('primary_domain')->unique();
            $table->string('home_directory')->default('/home/');
            $table->string('php_version', 10)->default('8.2');
            $table->enum('status', [
                'PENDING',
                'VALIDATING',
                'QUEUED',
                'PROVISIONING',
                'ACTIVE',
                'SUSPENDING',
                'SUSPENDED',
                'RESTORING',
                'TERMINATING',
                'TERMINATED',
                'FAILED',
                'REQUIRES_REPAIR'
            ])->default('PENDING')->index();
            $table->string('suspension_reason')->nullable();
            $table->timestamp('suspended_at')->nullable();
            $table->timestamp('provisioned_at')->nullable();
            $table->bigInteger('disk_used_mb')->default(0);
            $table->bigInteger('bandwidth_used_mb')->default(0);
            $table->json('resource_limits')->nullable(); // cgroup memory, cpu limits
            $table->timestamps();
            $table->softDeletes();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('hosting_accounts');
        Schema::dropIfExists('hosting_packages');
        Schema::dropIfExists('resellers');
    }
};

