@extends('layouts.guest', ['title' => 'Sign In'])

@section('content')
<div class="bg-slate-900 border border-slate-800 rounded-2xl p-8 shadow-2xl shadow-cyan-950/20">
    <div class="flex flex-col items-center mb-8">
        <div class="w-12 h-12 rounded-xl bg-gradient-to-tr from-cyan-500 to-blue-600 flex items-center justify-center font-bold text-xl text-white shadow-lg shadow-cyan-500/25 mb-4">
            CP
        </div>
        <h2 class="text-2xl font-bold tracking-tight text-white">Sign in to CPNix</h2>
        <p class="text-sm text-slate-400 mt-1">Enterprise Linux Hosting Control Panel</p>
    </div>

    @if($errors->any())
        <div class="mb-6 p-4 rounded-lg bg-rose-950/80 border border-rose-800 text-rose-300 text-sm">
            @foreach($errors->all() as $error)
                <div>{{ $error }}</div>
            @endforeach
        </div>
    @endif

    <form method="POST" action="{{ route('login') }}" class="space-y-5">
        @csrf

        <div>
            <label for="email" class="block text-sm font-medium text-slate-300 mb-1.5">Email Address</label>
            <input type="email" id="email" name="email" value="{{ old('email') }}" required autofocus
                class="w-full px-4 py-2.5 rounded-lg bg-slate-950 border border-slate-700 text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-cyan-500 focus:border-transparent transition-all">
        </div>

        <div>
            <div class="flex items-center justify-between mb-1.5">
                <label for="password" class="block text-sm font-medium text-slate-300">Password</label>
            </div>
            <input type="password" id="password" name="password" required
                class="w-full px-4 py-2.5 rounded-lg bg-slate-950 border border-slate-700 text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-cyan-500 focus:border-transparent transition-all">
        </div>

        <div class="flex items-center justify-between text-sm">
            <label class="flex items-center text-slate-400 hover:text-slate-300 cursor-pointer">
                <input type="checkbox" name="remember" class="w-4 h-4 rounded bg-slate-950 border-slate-700 text-cyan-600 focus:ring-cyan-500">
                <span class="ml-2">Remember this device</span>
            </label>
        </div>

        <button type="submit"
            class="w-full py-3 px-4 rounded-lg bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white font-semibold shadow-lg shadow-cyan-600/25 transition-all focus:outline-none focus:ring-2 focus:ring-cyan-500 focus:ring-offset-2 focus:ring-offset-slate-900">
            Sign In
        </button>
    </form>
</div>
@endsection

