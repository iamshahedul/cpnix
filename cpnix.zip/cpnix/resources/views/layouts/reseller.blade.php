<!DOCTYPE html>
<html lang="en" class="h-full bg-slate-900 text-slate-100">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{ $title ?? 'Reseller Portal' }} - CPNix Control Panel</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap');
        body { font-family: 'Plus Jakarta Sans', sans-serif; }
    </style>
</head>
<body class="h-full flex">
    <aside class="w-64 bg-slate-950 border-r border-slate-800 flex flex-col justify-between">
        <div>
            <div class="h-16 flex items-center px-6 border-b border-slate-800">
                <div class="flex items-center space-x-3">
                    <div class="w-8 h-8 rounded bg-gradient-to-tr from-amber-500 to-orange-600 flex items-center justify-center font-bold text-white shadow-lg shadow-amber-500/20">
                        CP
                    </div>
                    <div>
                        <span class="font-bold text-lg tracking-tight text-white">CPNix</span>
                        <span class="text-xs ml-1 px-1.5 py-0.5 rounded bg-amber-950 text-amber-400 font-mono border border-amber-800">Reseller</span>
                    </div>
                </div>
            </div>

            <nav class="p-4 space-y-1">
                <a href="{{ route('reseller.dashboard') }}" class="flex items-center space-x-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors hover:bg-slate-800 hover:text-white {{ request()->routeIs('reseller.dashboard') ? 'bg-amber-600 text-white' : 'text-slate-400' }}">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"/></svg>
                    <span>Overview</span>
                </a>

                <a href="{{ route('reseller.accounts.index') }}" class="flex items-center space-x-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors hover:bg-slate-800 hover:text-white {{ request()->routeIs('reseller.accounts.*') ? 'bg-amber-600 text-white' : 'text-slate-400' }}">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z"/></svg>
                    <span>My Customers</span>
                </a>
            </nav>
        </div>

        <div class="p-4 border-t border-slate-800">
            <div class="flex items-center justify-between">
                <div>
                    <div class="text-sm font-semibold text-white">{{ auth()->user()->name ?? 'Reseller' }}</div>
                    <div class="text-xs text-slate-400">{{ auth()->user()->email }}</div>
                </div>
                <form method="POST" action="{{ route('logout') }}">
                    @csrf
                    <button type="submit" class="p-2 text-slate-400 hover:text-rose-400 transition-colors" title="Logout">
                        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"/></svg>
                    </button>
                </form>
            </div>
        </div>
    </aside>

    <main class="flex-1 flex flex-col overflow-y-auto">
        <header class="h-16 border-b border-slate-800 px-8 flex items-center justify-between bg-slate-900/50 backdrop-blur sticky top-0 z-10">
            <h1 class="text-lg font-semibold text-white">@yield('page_title', 'Reseller Portal')</h1>
        </header>

        <div class="px-8 pt-6">
            @if(session('status'))
                <div class="p-4 rounded-lg bg-emerald-950/80 border border-emerald-800 text-emerald-300 text-sm">
                    {{ session('status') }}
                </div>
            @endif

            @if($errors->any())
                <div class="p-4 rounded-lg bg-rose-950/80 border border-rose-800 text-rose-300 text-sm space-y-1">
                    @foreach($errors->all() as $error)
                        <div>• {{ $error }}</div>
                    @endforeach
                </div>
            @endif
        </div>

        <div class="p-8">
            @yield('content')
        </div>
    </main>
</body>
</html>

