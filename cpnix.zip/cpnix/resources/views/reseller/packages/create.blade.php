@extends('layouts.reseller', ['title' => 'Create Package'])

@section('page_title', 'Create Custom Hosting Package')

@section('content')
<div class="max-w-3xl">
    <div class="bg-slate-950 border border-slate-800 rounded-xl p-8 shadow-sm">
        <div class="mb-6 pb-6 border-b border-slate-800">
            <h2 class="text-lg font-bold text-white">Package Limits & Capabilities</h2>
            <p class="text-xs text-slate-400 mt-1">
                Your remaining pool capacity: <span class="text-amber-400 font-mono">{{ $reseller->disk_quota_mb }} MB Disk</span> | <span class="text-amber-400 font-mono">{{ $reseller->max_accounts }} Max Accounts</span>
            </p>
        </div>

        <form method="POST" action="{{ route('reseller.packages.store') }}" class="space-y-6">
            @csrf

            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div class="md:col-span-2">
                    <label class="block text-xs font-medium text-slate-300 mb-1">Package Name</label>
                    <input type="text" name="name" value="{{ old('name') }}" placeholder="Silver Plan" required
                        class="w-full px-4 py-2.5 rounded-lg bg-slate-900 border border-slate-700 text-sm text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-amber-500">
                </div>

                <div>
                    <label class="block text-xs font-medium text-slate-300 mb-1">Disk Quota (MB)</label>
                    <input type="number" name="disk_quota_mb" value="5000" min="100" max="{{ $reseller->disk_quota_mb }}" required
                        class="w-full px-4 py-2.5 rounded-lg bg-slate-900 border border-slate-700 text-sm text-white font-mono focus:outline-none focus:ring-2 focus:ring-amber-500">
                </div>

                <div>
                    <label class="block text-xs font-medium text-slate-300 mb-1">Bandwidth Quota (MB)</label>
                    <input type="number" name="bandwidth_quota_mb" value="50000" min="500" max="{{ $reseller->bandwidth_quota_mb }}" required
                        class="w-full px-4 py-2.5 rounded-lg bg-slate-900 border border-slate-700 text-sm text-white font-mono focus:outline-none focus:ring-2 focus:ring-amber-500">
                </div>

                <div>
                    <label class="block text-xs font-medium text-slate-300 mb-1">Max Domains</label>
                    <input type="number" name="max_domains" value="1" min="1" max="50" required
                        class="w-full px-4 py-2.5 rounded-lg bg-slate-900 border border-slate-700 text-sm text-white font-mono focus:outline-none focus:ring-2 focus:ring-amber-500">
                </div>

                <div>
                    <label class="block text-xs font-medium text-slate-300 mb-1">Max Subdomains</label>
                    <input type="number" name="max_subdomains" value="5" min="0" max="100" required
                        class="w-full px-4 py-2.5 rounded-lg bg-slate-900 border border-slate-700 text-sm text-white font-mono focus:outline-none focus:ring-2 focus:ring-amber-500">
                </div>

                <div>
                    <label class="block text-xs font-medium text-slate-300 mb-1">Max Databases</label>
                    <input type="number" name="max_databases" value="3" min="0" max="100" required
                        class="w-full px-4 py-2.5 rounded-lg bg-slate-900 border border-slate-700 text-sm text-white font-mono focus:outline-none focus:ring-2 focus:ring-amber-500">
                </div>

                <div>
                    <label class="block text-xs font-medium text-slate-300 mb-1">Max Email Accounts</label>
                    <input type="number" name="max_email_accounts" value="10" min="0" max="200" required
                        class="w-full px-4 py-2.5 rounded-lg bg-slate-900 border border-slate-700 text-sm text-white font-mono focus:outline-none focus:ring-2 focus:ring-amber-500">
                </div>

                <div>
                    <label class="block text-xs font-medium text-slate-300 mb-1">Max Cron Jobs</label>
                    <input type="number" name="max_cron_jobs" value="5" min="0" max="20" required
                        class="w-full px-4 py-2.5 rounded-lg bg-slate-900 border border-slate-700 text-sm text-white font-mono focus:outline-none focus:ring-2 focus:ring-amber-500">
                </div>
            </div>

            <div class="pt-6 border-t border-slate-800 flex justify-end space-x-4">
                <a href="{{ route('reseller.packages.index') }}" class="px-5 py-2.5 rounded-lg text-sm text-slate-400 hover:text-white transition-colors">
                    Cancel
                </a>
                <button type="submit" class="px-6 py-2.5 rounded-lg bg-amber-600 hover:bg-amber-500 text-white font-semibold text-sm transition-colors shadow-sm">
                    Create Package
                </button>
            </div>
        </form>
    </div>
</div>
@endsection

