@extends('layouts.reseller', ['title' => 'My Packages'])

@section('page_title', 'Hosting Packages Management')

@section('content')
<div class="space-y-6">
    <div class="flex items-center justify-between">
        <div>
            <h2 class="text-xl font-bold text-white">My Hosting Packages</h2>
            <p class="text-sm text-slate-400">Define resource limits and tier allocations for your customer accounts</p>
        </div>
        <a href="{{ route('reseller.packages.create') }}" class="px-4 py-2 rounded-lg bg-amber-600 hover:bg-amber-500 text-white text-sm font-semibold transition-colors shadow-sm">
            + Create Package
        </a>
    </div>

    <!-- Packages Table -->
    <div class="bg-slate-950 border border-slate-800 rounded-xl overflow-hidden shadow-sm">
        <table class="w-full text-left text-sm text-slate-300">
            <thead class="bg-slate-900 text-xs uppercase text-slate-400 border-b border-slate-800">
                <tr>
                    <th class="px-6 py-3.5">Package Name</th>
                    <th class="px-6 py-3.5">Disk Quota</th>
                    <th class="px-6 py-3.5">Bandwidth</th>
                    <th class="px-6 py-3.5">Domains</th>
                    <th class="px-6 py-3.5">Databases</th>
                    <th class="px-6 py-3.5">Accounts Using</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-slate-800/60 font-mono text-xs">
                @forelse($packages as $pkg)
                    <tr class="hover:bg-slate-900/30">
                        <td class="px-6 py-4 font-sans font-bold text-white text-sm">{{ $pkg->name }}</td>
                        <td class="px-6 py-4 text-slate-300">{{ $pkg->disk_quota_mb }} MB</td>
                        <td class="px-6 py-4 text-slate-300">{{ $pkg->bandwidth_quota_mb }} MB</td>
                        <td class="px-6 py-4 text-slate-400">{{ $pkg->max_domains }}</td>
                        <td class="px-6 py-4 text-slate-400">{{ $pkg->max_databases }}</td>
                        <td class="px-6 py-4 text-amber-400">{{ $pkg->hosting_accounts_count }} accounts</td>
                    </tr>
                @empty
                    <tr>
                        <td colspan="6" class="px-6 py-8 text-center text-slate-500 font-sans">
                            No custom packages created yet. Click "+ Create Package" to add your first tier.
                        </td>
                    </tr>
                @endforelse
            </tbody>
        </table>
    </div>
</div>
@endsection

