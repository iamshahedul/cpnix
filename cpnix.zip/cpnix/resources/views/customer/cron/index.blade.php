@extends('layouts.customer', ['title' => 'Cron Jobs'])

@section('page_title', 'Cron Jobs & Scheduled Tasks')

@section('content')
<div class="space-y-8">
    <!-- Add Cron Job Form -->
    <div class="bg-slate-950 border border-slate-800 rounded-xl p-6 shadow-sm">
        <h3 class="text-base font-semibold text-white mb-1">Create Scheduled Task</h3>
        <p class="text-xs text-slate-400 mb-6">Runs automated commands as your unprivileged Linux account identity</p>

        <form method="POST" action="{{ route('customer.cron.store') }}" class="space-y-4">
            @csrf

            <div class="grid grid-cols-2 md:grid-cols-5 gap-4">
                <div>
                    <label class="block text-xs font-medium text-slate-300 mb-1">Minute (0-59)</label>
                    <input type="text" name="minute" value="*" required
                        class="w-full px-3.5 py-2 rounded-lg bg-slate-900 border border-slate-700 text-sm text-white font-mono text-center focus:outline-none focus:ring-2 focus:ring-emerald-500">
                </div>
                <div>
                    <label class="block text-xs font-medium text-slate-300 mb-1">Hour (0-23)</label>
                    <input type="text" name="hour" value="*" required
                        class="w-full px-3.5 py-2 rounded-lg bg-slate-900 border border-slate-700 text-sm text-white font-mono text-center focus:outline-none focus:ring-2 focus:ring-emerald-500">
                </div>
                <div>
                    <label class="block text-xs font-medium text-slate-300 mb-1">Day of Month (1-31)</label>
                    <input type="text" name="day_of_month" value="*" required
                        class="w-full px-3.5 py-2 rounded-lg bg-slate-900 border border-slate-700 text-sm text-white font-mono text-center focus:outline-none focus:ring-2 focus:ring-emerald-500">
                </div>
                <div>
                    <label class="block text-xs font-medium text-slate-300 mb-1">Month (1-12)</label>
                    <input type="text" name="month" value="*" required
                        class="w-full px-3.5 py-2 rounded-lg bg-slate-900 border border-slate-700 text-sm text-white font-mono text-center focus:outline-none focus:ring-2 focus:ring-emerald-500">
                </div>
                <div>
                    <label class="block text-xs font-medium text-slate-300 mb-1">Day of Week (0-6)</label>
                    <input type="text" name="day_of_week" value="*" required
                        class="w-full px-3.5 py-2 rounded-lg bg-slate-900 border border-slate-700 text-sm text-white font-mono text-center focus:outline-none focus:ring-2 focus:ring-emerald-500">
                </div>
            </div>

            <div>
                <label class="block text-xs font-medium text-slate-300 mb-1">Command to Execute</label>
                <input type="text" name="command" placeholder="/usr/bin/php /home/{{ $account->username }}/public_html/cron.php" required
                    class="w-full px-3.5 py-2 rounded-lg bg-slate-900 border border-slate-700 text-sm text-white font-mono placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-emerald-500">
            </div>

            <div>
                <label class="block text-xs font-medium text-slate-300 mb-1">Description (Optional)</label>
                <input type="text" name="description" placeholder="Daily database cleanup"
                    class="w-full px-3.5 py-2 rounded-lg bg-slate-900 border border-slate-700 text-sm text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-emerald-500">
            </div>

            <div class="pt-2 flex justify-end">
                <button type="submit" class="px-5 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-sm transition-colors shadow-sm">
                    + Add Scheduled Task
                </button>
            </div>
        </form>
    </div>

    <!-- Active Cron Jobs Table -->
    <div class="bg-slate-950 border border-slate-800 rounded-xl overflow-hidden shadow-sm">
        <div class="p-6 border-b border-slate-800">
            <h3 class="text-base font-semibold text-white">Configured Tasks</h3>
        </div>

        <table class="w-full text-left text-sm text-slate-300">
            <thead class="bg-slate-900 text-xs uppercase text-slate-400 border-b border-slate-800 font-mono">
                <tr>
                    <th class="px-6 py-3.5">Schedule</th>
                    <th class="px-6 py-3.5">Command</th>
                    <th class="px-6 py-3.5">Description</th>
                    <th class="px-6 py-3.5">Status</th>
                    <th class="px-6 py-3.5 text-right">Actions</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-slate-800/60 font-mono text-xs">
                @forelse($cronJobs as $cron)
                    <tr class="hover:bg-slate-900/30">
                        <td class="px-6 py-4 font-bold text-cyan-400">{{ $cron->expression }}</td>
                        <td class="px-6 py-4 text-slate-200 break-all">{{ $cron->command }}</td>
                        <td class="px-6 py-4 text-slate-400 font-sans">{{ $cron->description ?? '-' }}</td>
                        <td class="px-6 py-4">
                            @if($cron->is_active)
                                <span class="px-2 py-0.5 rounded text-xs bg-emerald-950 text-emerald-400 border border-emerald-800">Active</span>
                            @else
                                <span class="px-2 py-0.5 rounded text-xs bg-slate-900 text-slate-400 border border-slate-800">Disabled</span>
                            @endif
                        </td>
                        <td class="px-6 py-4 text-right space-x-2 font-sans">
                            <form method="POST" action="{{ route('customer.cron.toggle', $cron) }}" class="inline">
                                @csrf
                                <button type="submit" class="text-xs text-amber-400 hover:text-amber-300">
                                    {{ $cron->is_active ? 'Disable' : 'Enable' }}
                                </button>
                            </form>
                            <span class="text-slate-700">|</span>
                            <form method="POST" action="{{ route('customer.cron.destroy', $cron) }}" onsubmit="return confirm('Delete this scheduled job?');" class="inline">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="text-xs text-rose-400 hover:text-rose-300">Delete</button>
                            </form>
                        </td>
                    </tr>
                @empty
                    <tr>
                        <td colspan="5" class="px-6 py-8 text-center text-slate-500 font-sans">
                            No scheduled cron tasks configured.
                        </td>
                    </tr>
                @endforelse
            </tbody>
        </table>
    </div>
</div>
@endsection

