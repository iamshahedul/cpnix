@extends('layouts.customer', ['title' => 'Access & Error Logs'])

@section('page_title', 'Real-Time Web Server Logs')

@section('content')
<div class="space-y-6">
    <!-- Log Filter Controls -->
    <div class="bg-slate-950 border border-slate-800 rounded-xl p-6 shadow-sm">
        <form method="GET" action="{{ route('customer.logs.index') }}" class="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div class="flex items-center space-x-4">
                <div>
                    <label class="block text-xs font-medium text-slate-400 mb-1">Target Website / Domain</label>
                    <select name="domain" onchange="this.form.submit()" class="px-3.5 py-2 rounded-lg bg-slate-900 border border-slate-700 text-sm text-white font-mono focus:outline-none focus:ring-2 focus:ring-emerald-500">
                        @foreach($domains as $d)
                            <option value="{{ $d->domain }}" {{ $d->domain === $selectedDomain ? 'selected' : '' }}>
                                {{ $d->domain }}
                            </option>
                        @endforeach
                    </select>
                </div>

                <div>
                    <label class="block text-xs font-medium text-slate-400 mb-1">Log Stream</label>
                    <select name="type" onchange="this.form.submit()" class="px-3.5 py-2 rounded-lg bg-slate-900 border border-slate-700 text-sm text-white focus:outline-none focus:ring-2 focus:ring-emerald-500">
                        <option value="access" {{ $logType === 'access' ? 'selected' : '' }}>Access Log (HTTP traffic)</option>
                        <option value="error" {{ $logType === 'error' ? 'selected' : '' }}>Error Log (PHP & Nginx warnings)</option>
                    </select>
                </div>
            </div>

            <div class="flex items-center space-x-2">
                <button type="submit" class="px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold transition-colors">
                    ↻ Refresh Stream
                </button>
            </div>
        </form>
    </div>

    <!-- Terminal Viewer Window -->
    <div class="bg-slate-950 border border-slate-800 rounded-xl overflow-hidden shadow-2xl">
        <div class="px-4 py-2.5 bg-slate-900/80 border-b border-slate-800 flex items-center justify-between">
            <div class="flex items-center space-x-2">
                <span class="w-3 h-3 rounded-full bg-rose-500/80"></span>
                <span class="w-3 h-3 rounded-full bg-amber-500/80"></span>
                <span class="w-3 h-3 rounded-full bg-emerald-500/80"></span>
                <span class="text-xs text-slate-400 font-mono ml-2">/home/{{ $account->username }}/logs/{{ $selectedDomain }}-{{ $logType }}.log</span>
            </div>
            <span class="text-[11px] text-slate-500 font-mono">Last 150 lines (Reverse order)</span>
        </div>

        <div class="p-6 font-mono text-xs text-slate-300 bg-black/60 max-h-[500px] overflow-y-auto space-y-1.5 leading-relaxed selection:bg-cyan-900">
            @forelse($logLines as $line)
                <div class="hover:bg-slate-900/40 px-2 py-0.5 rounded transition-colors break-all">
                    @if(str_contains($line, '[error]') || str_contains($line, ' 500 ') || str_contains($line, ' 502 '))
                        <span class="text-rose-400">{{ $line }}</span>
                    @elseif(str_contains($line, ' 404 ') || str_contains($line, ' 403 '))
                        <span class="text-amber-400">{{ $line }}</span>
                    @else
                        <span class="text-slate-300">{{ $line }}</span>
                    @endif
                </div>
            @empty
                <div class="text-slate-500 italic py-4 text-center">No log records found.</div>
            @endforelse
        </div>
    </div>
</div>
@endsection

