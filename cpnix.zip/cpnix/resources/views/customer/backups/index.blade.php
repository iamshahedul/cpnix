@extends('layouts.customer', ['title' => 'Backups'])

@section('page_title', 'Backups & Disaster Recovery')

@section('content')
<div class="space-y-8">
    <!-- Generate Backup Card -->
    <div class="bg-slate-950 border border-slate-800 rounded-xl p-6 shadow-sm flex items-center justify-between">
        <div>
            <h3 class="text-base font-semibold text-white">Generate Full Account Backup</h3>
            <p class="text-xs text-slate-400 mt-1">Creates an archive of website files, databases, mailboxes, and DNS zone configurations</p>
        </div>

        <form method="POST" action="{{ route('customer.backups.create') }}">
            @csrf
            <button type="submit" class="px-5 py-2.5 rounded-lg bg-rose-600 hover:bg-rose-500 text-white font-semibold text-sm transition-colors shadow-sm">
                + Create Verified Backup
            </button>
        </form>
    </div>

    <!-- Backup Snapshots Table -->
    <div class="bg-slate-950 border border-slate-800 rounded-xl overflow-hidden shadow-sm">
        <div class="p-6 border-b border-slate-800">
            <h3 class="text-base font-semibold text-white">Verified Account Snapshots</h3>
        </div>

        <table class="w-full text-left text-sm text-slate-300">
            <thead class="bg-slate-900 text-xs uppercase text-slate-400 border-b border-slate-800">
                <tr>
                    <th class="px-6 py-3.5">Archive Filename</th>
                    <th class="px-6 py-3.5">Size</th>
                    <th class="px-6 py-3.5">SHA-256 Checksum</th>
                    <th class="px-6 py-3.5">Status</th>
                    <th class="px-6 py-3.5">Completed At</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-slate-800/60 font-mono text-xs">
                @forelse($backups as $b)
                    <tr class="hover:bg-slate-900/30">
                        <td class="px-6 py-4 font-bold text-white">{{ $b->filename }}</td>
                        <td class="px-6 py-4 text-slate-400">{{ number_format($b->size_bytes / 1048576, 2) }} MB</td>
                        <td class="px-6 py-4 text-slate-400">
                            @if($b->checksum_sha256)
                                <span title="{{ $b->checksum_sha256 }}">{{ substr($b->checksum_sha256, 0, 16) }}...</span>
                            @else
                                -
                            @endif
                        </td>
                        <td class="px-6 py-4">
                            @if($b->status === 'VERIFIED')
                                <span class="px-2 py-0.5 rounded text-xs bg-emerald-950 text-emerald-400 border border-emerald-800">Verified</span>
                            @else
                                <span class="px-2 py-0.5 rounded text-xs bg-slate-900 text-slate-400 border border-slate-800">{{ $b->status }}</span>
                            @endif
                        </td>
                        <td class="px-6 py-4 text-slate-500">{{ $b->completed_at ? $b->completed_at->format('Y-m-d H:i:s') : 'Processing' }}</td>
                    </tr>
                @empty
                    <tr>
                        <td colspan="5" class="px-6 py-8 text-center text-slate-500 font-sans">
                            No backup snapshots generated yet.
                        </td>
                    </tr>
                @endforelse
            </tbody>
        </table>
    </div>
</div>
@endsection

