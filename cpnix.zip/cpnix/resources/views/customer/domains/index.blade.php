@extends('layouts.customer', ['title' => 'Domains'])

@section('page_title', 'Domains & Subdomains')

@section('content')
<div class="space-y-8">
    <!-- Add Domain Form -->
    <div class="bg-slate-950 border border-slate-800 rounded-xl p-6 shadow-sm">
        <h3 class="text-base font-semibold text-white mb-1">Add Domain or Subdomain</h3>
        <p class="text-xs text-slate-400 mb-6">Create an additional virtual host attached to this hosting account</p>

        <form method="POST" action="{{ route('customer.domains.store') }}" class="grid grid-cols-1 md:grid-cols-4 gap-4">
            @csrf
            <div>
                <label class="block text-xs font-medium text-slate-300 mb-1">Domain Name</label>
                <input type="text" name="domain" placeholder="blog.example.com" required
                    class="w-full px-3.5 py-2 rounded-lg bg-slate-900 border border-slate-700 text-sm text-white placeholder-slate-500 font-mono focus:outline-none focus:ring-2 focus:ring-emerald-500">
            </div>

            <div>
                <label class="block text-xs font-medium text-slate-300 mb-1">Document Root (Relative to home)</label>
                <input type="text" name="folder" value="public_html" required
                    class="w-full px-3.5 py-2 rounded-lg bg-slate-900 border border-slate-700 text-sm text-white placeholder-slate-500 font-mono focus:outline-none focus:ring-2 focus:ring-emerald-500">
            </div>

            <div>
                <label class="block text-xs font-medium text-slate-300 mb-1">PHP Version</label>
                <select name="php_version" class="w-full px-3.5 py-2 rounded-lg bg-slate-900 border border-slate-700 text-sm text-white font-mono focus:outline-none focus:ring-2 focus:ring-emerald-500">
                    <option value="8.2" selected>PHP 8.2</option>
                    <option value="8.3">PHP 8.3</option>
                    <option value="8.1">PHP 8.1</option>
                    <option value="7.4">PHP 7.4</option>
                </select>
            </div>

            <div class="flex items-end">
                <button type="submit" class="w-full px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-sm transition-colors shadow-sm">
                    + Add Domain
                </button>
            </div>
        </form>
    </div>

    <!-- Domains Table -->
    <div class="bg-slate-950 border border-slate-800 rounded-xl overflow-hidden shadow-sm">
        <div class="p-6 border-b border-slate-800">
            <h3 class="text-base font-semibold text-white">Active Virtual Hosts</h3>
        </div>

        <table class="w-full text-left text-sm text-slate-300">
            <thead class="bg-slate-900 text-xs uppercase text-slate-400 border-b border-slate-800">
                <tr>
                    <th class="px-6 py-3.5">Domain</th>
                    <th class="px-6 py-3.5">Document Root</th>
                    <th class="px-6 py-3.5">PHP</th>
                    <th class="px-6 py-3.5">SSL Status</th>
                    <th class="px-6 py-3.5 text-right">Actions</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-slate-800/60 font-mono text-xs">
                @foreach($domains as $dom)
                    <tr class="hover:bg-slate-900/30">
                        <td class="px-6 py-4 font-sans text-sm font-medium text-white flex items-center space-x-2">
                            <span>{{ $dom->domain }}</span>
                            @if($dom->is_primary)
                                <span class="px-1.5 py-0.5 rounded text-[10px] bg-slate-800 text-cyan-400 border border-slate-700 font-mono">Primary</span>
                            @endif
                        </td>
                        <td class="px-6 py-4 text-slate-400">{{ $dom->document_root }}</td>
                        <td class="px-6 py-4 text-slate-300">PHP {{ $dom->php_version ?? $account->php_version }}</td>
                        <td class="px-6 py-4">
                            @if($dom->ssl_enabled)
                                <span class="px-2 py-0.5 rounded text-xs bg-emerald-950 text-emerald-400 border border-emerald-800">SSL Active</span>
                            @else
                                <span class="px-2 py-0.5 rounded text-xs bg-slate-900 text-slate-400 border border-slate-800">No SSL</span>
                            @endif
                        </td>
                        <td class="px-6 py-4 text-right">
                            <a href="http://{{ $dom->domain }}" target="_blank" class="text-emerald-400 hover:underline">Visit ↗</a>
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>
</div>
@endsection

