@extends('layouts.customer', ['title' => 'Email Accounts'])

@section('page_title', 'Virtual Email Accounts (Postfix & Dovecot)')

@section('content')
<div class="space-y-8">
    <!-- Create Mailbox -->
    <div class="bg-slate-950 border border-slate-800 rounded-xl p-6 shadow-sm">
        <h3 class="text-base font-semibold text-white mb-1">Create Mailbox</h3>
        <p class="text-xs text-slate-400 mb-6">Create virtual mail accounts stored in Maildir format</p>

        <form method="POST" action="{{ route('customer.email.store') }}" class="grid grid-cols-1 md:grid-cols-4 gap-4">
            @csrf
            <div>
                <label class="block text-xs font-medium text-slate-300 mb-1">Username / Local Part</label>
                <input type="text" name="local_part" placeholder="info" required
                    class="w-full px-3.5 py-2 rounded-lg bg-slate-900 border border-slate-700 text-sm text-white placeholder-slate-500 font-mono focus:outline-none focus:ring-2 focus:ring-emerald-500">
            </div>

            <div>
                <label class="block text-xs font-medium text-slate-300 mb-1">Domain</label>
                <select name="domain" required class="w-full px-3.5 py-2 rounded-lg bg-slate-900 border border-slate-700 text-sm text-white font-mono focus:outline-none focus:ring-2 focus:ring-emerald-500">
                    @foreach($domains as $d)
                        <option value="{{ $d->domain }}">{{ $d->domain }}</option>
                    @endforeach
                </select>
            </div>

            <div>
                <label class="block text-xs font-medium text-slate-300 mb-1">Mailbox Password</label>
                <input type="password" name="password" required
                    class="w-full px-3.5 py-2 rounded-lg bg-slate-900 border border-slate-700 text-sm text-white focus:outline-none focus:ring-2 focus:ring-emerald-500">
            </div>

            <div class="flex items-end">
                <input type="hidden" name="quota_mb" value="1000">
                <button type="submit" class="w-full py-2 px-4 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-sm transition-colors shadow-sm">
                    + Create Mailbox
                </button>
            </div>
        </form>
    </div>

    <!-- Mailboxes Table -->
    <div class="bg-slate-950 border border-slate-800 rounded-xl overflow-hidden shadow-sm">
        <div class="p-6 border-b border-slate-800">
            <h3 class="text-base font-semibold text-white">Configured Email Accounts</h3>
        </div>

        <table class="w-full text-left text-sm text-slate-300">
            <thead class="bg-slate-900 text-xs uppercase text-slate-400 border-b border-slate-800">
                <tr>
                    <th class="px-6 py-3.5">Email Address</th>
                    <th class="px-6 py-3.5">Quota Limit</th>
                    <th class="px-6 py-3.5">Usage</th>
                    <th class="px-6 py-3.5">Status</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-slate-800/60 font-mono text-xs">
                @forelse($emailAccounts as $mail)
                    <tr class="hover:bg-slate-900/30">
                        <td class="px-6 py-4 font-bold text-white">{{ $mail->email }}</td>
                        <td class="px-6 py-4 text-slate-400">{{ $mail->quota_mb }} MB</td>
                        <td class="px-6 py-4 text-slate-400">{{ $mail->used_mb }} MB</td>
                        <td class="px-6 py-4">
                            <span class="px-2 py-0.5 rounded text-xs bg-emerald-950 text-emerald-400 border border-emerald-800">Active</span>
                        </td>
                    </tr>
                @empty
                    <tr>
                        <td colspan="4" class="px-6 py-8 text-center text-slate-500 font-sans">
                            No email mailboxes configured yet.
                        </td>
                    </tr>
                @endforelse
            </tbody>
        </table>
    </div>
</div>
@endsection

