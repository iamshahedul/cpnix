@extends('layouts.customer', ['title' => 'PHP Configuration'])

@section('page_title', 'PHP Runtime & Extensions')

@section('content')
<div class="space-y-8 max-w-4xl">
    <!-- Version Selector Card -->
    <div class="bg-slate-950 border border-slate-800 rounded-xl p-6 shadow-sm">
        <h3 class="text-base font-semibold text-white mb-1">PHP Version Selection</h3>
        <p class="text-xs text-slate-400 mb-6">Each hosting account executes in a dedicated, isolated PHP-FPM process pool</p>

        <form method="POST" action="{{ route('customer.php.version') }}" class="flex items-center space-x-4">
            @csrf
            <div class="flex-1">
                <select name="php_version" class="w-full px-4 py-2.5 rounded-lg bg-slate-900 border border-slate-700 text-sm text-white font-mono focus:outline-none focus:ring-2 focus:ring-emerald-500">
                    @foreach($allowedVersions as $ver)
                        <option value="{{ $ver }}" {{ $account->php_version === $ver ? 'selected' : '' }}>
                            PHP {{ $ver }} {{ $account->php_version === $ver ? '(Current Active Version)' : '' }}
                        </option>
                    @endforeach
                </select>
            </div>

            <button type="submit" class="px-6 py-2.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-sm transition-colors shadow-sm">
                Apply Version
            </button>
        </form>
    </div>

    <!-- Directives Configuration Form -->
    <div class="bg-slate-950 border border-slate-800 rounded-xl p-6 shadow-sm">
        <h3 class="text-base font-semibold text-white mb-1">Account PHP Directives (php.ini)</h3>
        <p class="text-xs text-slate-400 mb-6">Safely tune resource thresholds without altering global server configuration</p>

        <form method="POST" action="{{ route('customer.php.directives') }}" class="space-y-6">
            @csrf

            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <label class="block text-xs font-medium text-slate-300 mb-1">memory_limit</label>
                    <select name="memory_limit" class="w-full px-3.5 py-2 rounded-lg bg-slate-900 border border-slate-700 text-sm text-white font-mono focus:outline-none focus:ring-2 focus:ring-emerald-500">
                        <option value="128M" {{ ($settings['memory_limit'] ?? '') === '128M' ? 'selected' : '' }}>128 MB</option>
                        <option value="256M" {{ ($settings['memory_limit'] ?? '256M') === '256M' ? 'selected' : '' }}>256 MB (Default)</option>
                        <option value="512M" {{ ($settings['memory_limit'] ?? '') === '512M' ? 'selected' : '' }}>512 MB</option>
                        <option value="1024M" {{ ($settings['memory_limit'] ?? '') === '1024M' ? 'selected' : '' }}>1024 MB</option>
                    </select>
                </div>

                <div>
                    <label class="block text-xs font-medium text-slate-300 mb-1">max_execution_time</label>
                    <select name="max_execution_time" class="w-full px-3.5 py-2 rounded-lg bg-slate-900 border border-slate-700 text-sm text-white font-mono focus:outline-none focus:ring-2 focus:ring-emerald-500">
                        <option value="30" {{ ($settings['max_execution_time'] ?? '') === '30' ? 'selected' : '' }}>30 Seconds</option>
                        <option value="60" {{ ($settings['max_execution_time'] ?? '') === '60' ? 'selected' : '' }}>60 Seconds</option>
                        <option value="120" {{ ($settings['max_execution_time'] ?? '120') === '120' ? 'selected' : '' }}>120 Seconds (Default)</option>
                        <option value="300" {{ ($settings['max_execution_time'] ?? '') === '300' ? 'selected' : '' }}>300 Seconds</option>
                    </select>
                </div>

                <div>
                    <label class="block text-xs font-medium text-slate-300 mb-1">upload_max_filesize & post_max_size</label>
                    <select name="upload_max_filesize" class="w-full px-3.5 py-2 rounded-lg bg-slate-900 border border-slate-700 text-sm text-white font-mono focus:outline-none focus:ring-2 focus:ring-emerald-500">
                        <option value="16M" {{ ($settings['upload_max_filesize'] ?? '') === '16M' ? 'selected' : '' }}>16 MB</option>
                        <option value="32M" {{ ($settings['upload_max_filesize'] ?? '') === '32M' ? 'selected' : '' }}>32 MB</option>
                        <option value="64M" {{ ($settings['upload_max_filesize'] ?? '64M') === '64M' ? 'selected' : '' }}>64 MB (Default)</option>
                        <option value="128M" {{ ($settings['upload_max_filesize'] ?? '') === '128M' ? 'selected' : '' }}>128 MB</option>
                    </select>
                </div>

                <div>
                    <label class="block text-xs font-medium text-slate-300 mb-1">display_errors</label>
                    <select name="display_errors" class="w-full px-3.5 py-2 rounded-lg bg-slate-900 border border-slate-700 text-sm text-white font-mono focus:outline-none focus:ring-2 focus:ring-emerald-500">
                        <option value="Off" {{ ($settings['display_errors'] ?? 'Off') === 'Off' ? 'selected' : '' }}>Off (Secure Production)</option>
                        <option value="On" {{ ($settings['display_errors'] ?? '') === 'On' ? 'selected' : '' }}>On (Debugging)</option>
                    </select>
                </div>
            </div>

            <div class="pt-4 border-t border-slate-800 flex justify-end">
                <button type="submit" class="px-5 py-2.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-white font-semibold text-sm transition-colors">
                    Save Directives
                </button>
            </div>
        </form>
    </div>
</div>
@endsection

