@extends('layouts.customer', ['title' => 'SFTP Accounts'])

@section('page_title', 'SFTP Accounts & Chrooted Access')

@section('content')
<div class="space-y-8">
    <!-- Create SFTP User Form -->
    <div class="bg-slate-950 border border-slate-800 rounded-xl p-6 shadow-sm">
        <h3 class="text-base font-semibold text-white mb-1">Create SFTP Account</h3>
        <p class="text-xs text-slate-400 mb-6">Each sub-user is chrooted and strictly confined to their assigned directory path</p>

        <form method="POST" action="{{ route('customer.sftp.store') }}" class="space-y-4">
            @csrf

            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                    <label class="block text-xs font-medium text-slate-300 mb-1">Username Suffix</label>
                    <div class="flex items-center">
                        <span class="px-3 py-2 rounded-l-lg bg-slate-900 border border-r-0 border-slate-700 text-sm font-mono text-slate-400">
                            {{ $account->username }}_
                        </span>
                        <input type="text" name="username_suffix" placeholder="dev" required
                            class="flex-1 px-3.5 py-2 rounded-r-lg bg-slate-950 border border-slate-700 text-sm text-white font-mono focus:outline-none focus:ring-2 focus:ring-emerald-500">
                    </div>
                </div>

                <div>
                    <label class="block text-xs font-medium text-slate-300 mb-1">Restricted Directory (Relative)</label>
                    <input type="text" name="relative_dir" value="public_html" required
                        class="w-full px-3.5 py-2 rounded-lg bg-slate-900 border border-slate-700 text-sm text-white font-mono focus:outline-none focus:ring-2 focus:ring-emerald-500">
                </div>

                <div>
                    <label class="block text-xs font-medium text-slate-300 mb-1">SFTP Password</label>
                    <input type="password" name="password" placeholder="Leave empty if using SSH Public Key"
                        class="w-full px-3.5 py-2 rounded-lg bg-slate-900 border border-slate-700 text-sm text-white focus:outline-none focus:ring-2 focus:ring-emerald-500">
                </div>

                <div>
                    <label class="block text-xs font-medium text-slate-300 mb-1">SSH Public Key (Optional)</label>
                    <input type="text" name="public_key" placeholder="ssh-ed25519 AAAAC3NzaC1lZDI1NTE5..."
                        class="w-full px-3.5 py-2 rounded-lg bg-slate-900 border border-slate-700 text-sm text-white font-mono focus:outline-none focus:ring-2 focus:ring-emerald-500">
                </div>
            </div>

            <div class="pt-2 flex justify-end">
                <button type="submit" class="px-5 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-sm transition-colors shadow-sm">
                    + Create SFTP User
                </button>
            </div>
        </form>
    </div>

    <!-- Active SFTP Users Table -->
    <div class="bg-slate-950 border border-slate-800 rounded-xl overflow-hidden shadow-sm">
        <div class="p-6 border-b border-slate-800">
            <h3 class="text-base font-semibold text-white">Active SFTP Users</h3>
        </div>

        <table class="w-full text-left text-sm text-slate-300">
            <thead class="bg-slate-900 text-xs uppercase text-slate-400 border-b border-slate-800 font-mono">
                <tr>
                    <th class="px-6 py-3.5">Username</th>
                    <th class="px-6 py-3.5">Chroot Directory</th>
                    <th class="px-6 py-3.5">Authentication</th>
                    <th class="px-6 py-3.5">Status</th>
                    <th class="px-6 py-3.5 text-right">Actions</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-slate-800/60 font-mono text-xs">
                @forelse($sftpAccounts as $sftp)
                    <tr class="hover:bg-slate-900/30">
                        <td class="px-6 py-4 font-bold text-white">{{ $sftp->username }}</td>
                        <td class="px-6 py-4 text-slate-400">{{ $sftp->home_directory }}</td>
                        <td class="px-6 py-4 text-slate-300">
                            {{ $sftp->public_key ? 'SSH Key' : 'Password' }}
                        </td>
                        <td class="px-6 py-4">
                            <span class="px-2 py-0.5 rounded text-xs bg-emerald-950 text-emerald-400 border border-emerald-800">Active</span>
                        </td>
                        <td class="px-6 py-4 text-right font-sans">
                            <form method="POST" action="{{ route('customer.sftp.destroy', $sftp) }}" onsubmit="return confirm('Delete this SFTP account?');" class="inline">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="text-xs text-rose-400 hover:text-rose-300">Delete</button>
                            </form>
                        </td>
                    </tr>
                @empty
                    <tr>
                        <td colspan="5" class="px-6 py-8 text-center text-slate-500 font-sans">
                            No dedicated SFTP sub-accounts configured yet.
                        </td>
                    </tr>
                @endforelse
            </tbody>
        </table>
    </div>
</div>
@endsection

