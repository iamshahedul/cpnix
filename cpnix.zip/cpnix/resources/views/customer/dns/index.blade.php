@extends('layouts.customer', ['title' => 'DNS Zone Editor'])

@section('page_title', 'Authoritative DNS Zone Editor')

@section('content')
<div class="space-y-8">
    <!-- Zone Selector & Overview -->
    <div class="bg-slate-950 border border-slate-800 rounded-xl p-6 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
            <div class="flex items-center space-x-3">
                <h2 class="text-xl font-bold text-white">{{ $currentZone->name }}</h2>
                <span class="px-2 py-0.5 rounded text-xs font-mono bg-cyan-950 text-cyan-400 border border-cyan-800">
                    Serial: {{ $currentZone->serial }}
                </span>
            </div>
            <p class="text-xs text-slate-400 mt-1">
                Primary NS: {{ $currentZone->primary_ns }} | TTL: {{ $currentZone->ttl }}s | Admin: {{ $currentZone->admin_email }}
            </p>
        </div>

        @if($zones->count() > 1)
            <form method="GET" action="{{ route('customer.dns.index') }}" class="flex items-center space-x-2">
                <label class="text-xs text-slate-400">Switch Zone:</label>
                <select name="zone_id" onchange="this.form.submit()" class="px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-700 text-xs text-white font-mono focus:outline-none focus:ring-2 focus:ring-emerald-500">
                    @foreach($zones as $z)
                        <option value="{{ $z->id }}" {{ $z->id == $currentZone->id ? 'selected' : '' }}>{{ $z->name }}</option>
                    @endforeach
                </select>
            </form>
        @endif
    </div>

    <!-- Add Record Form -->
    <div class="bg-slate-950 border border-slate-800 rounded-xl p-6 shadow-sm">
        <h3 class="text-base font-semibold text-white mb-1">Add DNS Record</h3>
        <p class="text-xs text-slate-400 mb-6">Create authoritative resource records for domain routing and service verification</p>

        <form method="POST" action="{{ route('customer.dns.record.store') }}" class="grid grid-cols-1 md:grid-cols-6 gap-4">
            @csrf
            <input type="hidden" name="dns_zone_id" value="{{ $currentZone->id }}">

            <div>
                <label class="block text-xs font-medium text-slate-300 mb-1">Type</label>
                <select name="type" id="record_type" onchange="togglePriority(this.value)" class="w-full px-3 py-2 rounded-lg bg-slate-900 border border-slate-700 text-sm text-white font-mono focus:outline-none focus:ring-2 focus:ring-emerald-500">
                    <option value="A" selected>A (IPv4)</option>
                    <option value="AAAA">AAAA (IPv6)</option>
                    <option value="CNAME">CNAME (Alias)</option>
                    <option value="MX">MX (Mail Server)</option>
                    <option value="TXT">TXT (Verification/SPF)</option>
                    <option value="SRV">SRV (Service)</option>
                    <option value="CAA">CAA (Cert Authority)</option>
                </select>
            </div>

            <div>
                <label class="block text-xs font-medium text-slate-300 mb-1">Name / Host</label>
                <input type="text" name="name" value="@" placeholder="@ or subdomain" required
                    class="w-full px-3 py-2 rounded-lg bg-slate-900 border border-slate-700 text-sm text-white font-mono placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-emerald-500">
            </div>

            <div class="md:col-span-2">
                <label class="block text-xs font-medium text-slate-300 mb-1">Value / Content</label>
                <input type="text" name="content" placeholder="192.0.2.1 or mail.example.com." required
                    class="w-full px-3 py-2 rounded-lg bg-slate-900 border border-slate-700 text-sm text-white font-mono placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-emerald-500">
            </div>

            <div>
                <label class="block text-xs font-medium text-slate-300 mb-1">TTL (Seconds)</label>
                <input type="number" name="ttl" value="3600" min="60" max="86400" required
                    class="w-full px-3 py-2 rounded-lg bg-slate-900 border border-slate-700 text-sm text-white font-mono focus:outline-none focus:ring-2 focus:ring-emerald-500">
            </div>

            <div id="priority_wrapper" class="hidden">
                <label class="block text-xs font-medium text-slate-300 mb-1">Priority</label>
                <input type="number" name="priority" id="record_priority" value="10" min="0" max="65535"
                    class="w-full px-3 py-2 rounded-lg bg-slate-900 border border-slate-700 text-sm text-white font-mono focus:outline-none focus:ring-2 focus:ring-emerald-500">
            </div>

            <div class="flex items-end">
                <button type="submit" class="w-full py-2 px-4 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-sm transition-colors shadow-sm">
                    + Add Record
                </button>
            </div>
        </form>
    </div>

    <!-- Active Records Table -->
    <div class="bg-slate-950 border border-slate-800 rounded-xl overflow-hidden shadow-sm">
        <div class="p-6 border-b border-slate-800">
            <h3 class="text-base font-semibold text-white">Zone Resource Records</h3>
        </div>

        <table class="w-full text-left text-sm text-slate-300">
            <thead class="bg-slate-900 text-xs uppercase text-slate-400 border-b border-slate-800 font-mono">
                <tr>
                    <th class="px-6 py-3.5">Name</th>
                    <th class="px-6 py-3.5">Type</th>
                    <th class="px-6 py-3.5">Content</th>
                    <th class="px-6 py-3.5">TTL</th>
                    <th class="px-6 py-3.5">Priority</th>
                    <th class="px-6 py-3.5 text-right">Actions</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-slate-800/60 font-mono text-xs">
                @foreach($currentZone->records as $r)
                    <tr class="hover:bg-slate-900/30">
                        <td class="px-6 py-4 font-bold text-white">{{ $r->name }}</td>
                        <td class="px-6 py-4">
                            <span class="px-2 py-0.5 rounded text-[10px] bg-slate-900 text-cyan-400 border border-slate-800">{{ $r->type }}</span>
                        </td>
                        <td class="px-6 py-4 text-slate-200 break-all">{{ $r->content }}</td>
                        <td class="px-6 py-4 text-slate-400">{{ $r->ttl }}</td>
                        <td class="px-6 py-4 text-slate-400">{{ $r->priority !== null ? $r->priority : '-' }}</td>
                        <td class="px-6 py-4 text-right">
                            <form method="POST" action="{{ route('customer.dns.record.destroy', $r) }}" onsubmit="return confirm('Delete this DNS record?');" class="inline">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="text-xs text-rose-400 hover:text-rose-300 font-sans">Delete</button>
                            </form>
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>
</div>

<script>
function togglePriority(type) {
    const wrapper = document.getElementById('priority_wrapper');
    if (type === 'MX' || type === 'SRV') {
        wrapper.classList.remove('hidden');
    } else {
        wrapper.classList.add('hidden');
    }
}
</script>
@endsection

