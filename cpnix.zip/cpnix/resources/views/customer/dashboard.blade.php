@extends('layouts.customer', ['title' => 'Dashboard'])

@section('page_title', 'Account Overview: ' . $account->primary_domain)

@section('content')
<div class="space-y-8">
    <!-- Account Card -->
    <div class="bg-slate-950 border border-slate-800 rounded-xl p-6 shadow-sm">
        <div class="flex flex-col md:flex-row md:items-center justify-between pb-6 border-b border-slate-800 gap-4">
            <div>
                <div class="flex items-center space-x-3">
                    <h2 class="text-2xl font-bold text-white">{{ $account->primary_domain }}</h2>
                    <span class="px-2.5 py-0.5 rounded text-xs font-semibold bg-emerald-950 text-emerald-400 border border-emerald-800">
                        {{ $account->status }}
                    </span>
                </div>
                <div class="text-xs text-slate-400 font-mono mt-1">
                    IP: {{ $account->server->ip_address }} | Server: {{ $account->server->name }} | PHP {{ $account->php_version }}
                </div>
            </div>

            <div class="flex items-center space-x-3">
                <a href="http://{{ $account->primary_domain }}" target="_blank" rel="noopener noreferrer" class="px-4 py-2 rounded-lg bg-slate-900 border border-slate-700 hover:bg-slate-800 text-xs font-semibold text-white transition-colors flex items-center space-x-1.5">
                    <span>Visit Website</span>
                    <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"/></svg>
                </a>
                <a href="{{ route('customer.files.index') }}" class="px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-xs font-semibold text-white shadow-sm transition-colors">
                    File Manager
                </a>
            </div>
        </div>

        <!-- Quota Progress Bars -->
        <div class="grid grid-cols-1 md:grid-cols-2 gap-6 pt-6">
            <div>
                <div class="flex items-center justify-between text-xs text-slate-400 mb-1.5">
                    <span>Disk Space Usage</span>
                    <span class="font-mono text-slate-200">{{ $diskUsedMb }} MB / {{ $diskLimitMb }} MB ({{ $diskPercent }}%)</span>
                </div>
                <div class="w-full bg-slate-900 rounded-full h-2 overflow-hidden border border-slate-800">
                    <div class="bg-gradient-to-r from-emerald-500 to-teal-400 h-2 rounded-full" style="width: {{ $diskPercent }}%"></div>
                </div>
            </div>

            <div>
                <div class="flex items-center justify-between text-xs text-slate-400 mb-1.5">
                    <span>Bandwidth Usage</span>
                    <span class="font-mono text-slate-200">{{ $account->bandwidth_used_mb }} MB / {{ $account->package->bandwidth_quota_mb }} MB</span>
                </div>
                <div class="w-full bg-slate-900 rounded-full h-2 overflow-hidden border border-slate-800">
                    <div class="bg-gradient-to-r from-cyan-500 to-blue-500 h-2 rounded-full" style="width: 5%"></div>
                </div>
            </div>
        </div>
    </div>

    <!-- Quick Management Tiles -->
    <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
        <!-- Domains -->
        <a href="{{ route('customer.domains.index') }}" class="p-6 rounded-xl bg-slate-950 border border-slate-800 hover:border-slate-700 hover:bg-slate-900/40 transition-all group">
            <div class="flex items-center space-x-3 mb-3">
                <div class="p-2.5 rounded-lg bg-slate-900 text-cyan-400 group-hover:bg-cyan-950 group-hover:text-cyan-300 transition-colors">
                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 12a9 9 0 01-9 9m9-9a9 9 0 00-9-9m9 9H3m9 9a9 9 0 01-9-9m9 9c1.657 0 3-4.03 3-9s-1.343-9-3-9m0 18c-1.657 0-3-4.03-3-9s1.343-9 3-9m-9 9a9 9 0 019-9"/></svg>
                </div>
                <div>
                    <h3 class="font-semibold text-white group-hover:text-cyan-400 transition-colors">Domains & Subdomains</h3>
                    <p class="text-xs text-slate-500">{{ $account->domains_count }} configured</p>
                </div>
            </div>
            <p class="text-xs text-slate-400">Configure virtual hosts, document roots, and DNS zone records.</p>
        </a>

        <!-- Databases -->
        <a href="{{ route('customer.databases.index') }}" class="p-6 rounded-xl bg-slate-950 border border-slate-800 hover:border-slate-700 hover:bg-slate-900/40 transition-all group">
            <div class="flex items-center space-x-3 mb-3">
                <div class="p-2.5 rounded-lg bg-slate-900 text-emerald-400 group-hover:bg-emerald-950 group-hover:text-emerald-300 transition-colors">
                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 7v10c0 2.21 3.582 4 8 4s8-1.79 8-4V7M4 7c0 2.21 3.582 4 8 4s8-1.79 8-4M4 7c0-2.21 3.582-4 8-4s8 1.79 8 4m0 5c0 2.21-3.582 4-8 4s-8-1.79-8-4"/></svg>
                </div>
                <div>
                    <h3 class="font-semibold text-white group-hover:text-emerald-400 transition-colors">MariaDB Databases</h3>
                    <p class="text-xs text-slate-500">{{ $account->databases_count }} / {{ $account->package->max_databases }} active</p>
                </div>
            </div>
            <p class="text-xs text-slate-400">Create relational databases, database users, and least-privilege credentials.</p>
        </a>

        <!-- Email Accounts -->
        <a href="{{ route('customer.email.index') }}" class="p-6 rounded-xl bg-slate-950 border border-slate-800 hover:border-slate-700 hover:bg-slate-900/40 transition-all group">
            <div class="flex items-center space-x-3 mb-3">
                <div class="p-2.5 rounded-lg bg-slate-900 text-blue-400 group-hover:bg-blue-950 group-hover:text-blue-300 transition-colors">
                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"/></svg>
                </div>
                <div>
                    <h3 class="font-semibold text-white group-hover:text-blue-400 transition-colors">Email Mailboxes</h3>
                    <p class="text-xs text-slate-500">{{ $account->email_accounts_count }} / {{ $account->package->max_email_accounts }} mailboxes</p>
                </div>
            </div>
            <p class="text-xs text-slate-400">Manage virtual mailboxes, IMAP/POP3 authentication, and mailbox storage quotas.</p>
        </a>

        <!-- File Manager -->
        <a href="{{ route('customer.files.index') }}" class="p-6 rounded-xl bg-slate-950 border border-slate-800 hover:border-slate-700 hover:bg-slate-900/40 transition-all group">
            <div class="flex items-center space-x-3 mb-3">
                <div class="p-2.5 rounded-lg bg-slate-900 text-amber-400 group-hover:bg-amber-950 group-hover:text-amber-300 transition-colors">
                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 7v10a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-6l-2-2H5a2 2 0 00-2 2z"/></svg>
                </div>
                <div>
                    <h3 class="font-semibold text-white group-hover:text-amber-400 transition-colors">File Manager</h3>
                    <p class="text-xs text-slate-500">public_html</p>
                </div>
            </div>
            <p class="text-xs text-slate-400">Safely upload, edit, rename, and manage your website files and assets.</p>
        </a>

        <!-- SSL Certificates -->
        <a href="{{ route('customer.ssl.index') }}" class="p-6 rounded-xl bg-slate-950 border border-slate-800 hover:border-slate-700 hover:bg-slate-900/40 transition-all group">
            <div class="flex items-center space-x-3 mb-3">
                <div class="p-2.5 rounded-lg bg-slate-900 text-violet-400 group-hover:bg-violet-950 group-hover:text-violet-300 transition-colors">
                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"/></svg>
                </div>
                <div>
                    <h3 class="font-semibold text-white group-hover:text-violet-400 transition-colors">SSL / TLS</h3>
                    <p class="text-xs text-slate-500">{{ $account->ssl_certificates_count }} active certificates</p>
                </div>
            </div>
            <p class="text-xs text-slate-400">Issue automated Let's Encrypt certificates with HTTP-01 domain challenge.</p>
        </a>

        <!-- Backups -->
        <a href="{{ route('customer.backups.index') }}" class="p-6 rounded-xl bg-slate-950 border border-slate-800 hover:border-slate-700 hover:bg-slate-900/40 transition-all group">
            <div class="flex items-center space-x-3 mb-3">
                <div class="p-2.5 rounded-lg bg-slate-900 text-rose-400 group-hover:bg-rose-950 group-hover:text-rose-300 transition-colors">
                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7H5a2 2 0 00-2 2v9a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-3m-1 4l-3 3m0 0l-3-3m3 3V4"/></svg>
                </div>
                <div>
                    <h3 class="font-semibold text-white group-hover:text-rose-400 transition-colors">Backups & Recovery</h3>
                    <p class="text-xs text-slate-500">Verified snapshots</p>
                </div>
            </div>
            <p class="text-xs text-slate-400">Generate and download verified tarball archives with SHA-256 integrity checks.</p>
        </a>
    </div>
</div>
@endsection

