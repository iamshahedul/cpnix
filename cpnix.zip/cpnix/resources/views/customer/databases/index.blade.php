@extends('layouts.customer', ['title' => 'Databases'])

@section('page_title', 'MariaDB Databases & Users')

@section('content')
<div class="space-y-8">
    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
        <!-- Create Database -->
        <div class="bg-slate-950 border border-slate-800 rounded-xl p-6 shadow-sm">
            <h3 class="text-base font-semibold text-white mb-1">Create Database</h3>
            <p class="text-xs text-slate-400 mb-6">Database names are prefixed with your account username</p>

            <form method="POST" action="{{ route('customer.databases.store') }}" class="space-y-4">
                @csrf
                <div>
                    <label class="block text-xs font-medium text-slate-300 mb-1">Database Suffix</label>
                    <div class="flex items-center">
                        <span class="px-3 py-2 rounded-l-lg bg-slate-900 border border-r-0 border-slate-700 text-sm font-mono text-slate-400">
                            {{ $account->username }}_
                        </span>
                        <input type="text" name="database_name" placeholder="blog" required
                            class="flex-1 px-3.5 py-2 rounded-r-lg bg-slate-950 border border-slate-700 text-sm text-white font-mono focus:outline-none focus:ring-2 focus:ring-emerald-500">
                    </div>
                </div>

                <button type="submit" class="w-full py-2 px-4 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-sm font-semibold transition-colors">
                    Create Database
                </button>
            </form>
        </div>

        <!-- Create User & Assign -->
        <div class="bg-slate-950 border border-slate-800 rounded-xl p-6 shadow-sm">
            <h3 class="text-base font-semibold text-white mb-1">Create Database User</h3>
            <p class="text-xs text-slate-400 mb-6">Create credentials scoped to a specific database</p>

            <form method="POST" action="{{ route('customer.databases.store_user') }}" class="space-y-4">
                @csrf
                <div>
                    <label class="block text-xs font-medium text-slate-300 mb-1">Username Suffix</label>
                    <div class="flex items-center">
                        <span class="px-3 py-2 rounded-l-lg bg-slate-900 border border-r-0 border-slate-700 text-sm font-mono text-slate-400">
                            {{ $account->username }}_
                        </span>
                        <input type="text" name="username" placeholder="dbuser" required
                            class="flex-1 px-3.5 py-2 rounded-r-lg bg-slate-950 border border-slate-700 text-sm text-white font-mono focus:outline-none focus:ring-2 focus:ring-emerald-500">
                    </div>
                </div>

                <div>
                    <label class="block text-xs font-medium text-slate-300 mb-1">Password</label>
                    <input type="password" name="password" required
                        class="w-full px-3.5 py-2 rounded-lg bg-slate-950 border border-slate-700 text-sm text-white focus:outline-none focus:ring-2 focus:ring-emerald-500">
                </div>

                <div>
                    <label class="block text-xs font-medium text-slate-300 mb-1">Assign to Database</label>
                    <select name="database_id" required class="w-full px-3.5 py-2 rounded-lg bg-slate-950 border border-slate-700 text-sm text-white font-mono focus:outline-none focus:ring-2 focus:ring-emerald-500">
                        <option value="">Select database...</option>
                        @foreach($databases as $db)
                            <option value="{{ $db->id }}">{{ $db->name }}</option>
                        @endforeach
                    </select>
                </div>

                <button type="submit" class="w-full py-2 px-4 rounded-lg bg-slate-800 hover:bg-slate-700 text-white text-sm font-semibold transition-colors">
                    Create & Grant User
                </button>
            </form>
        </div>
    </div>

    <!-- Active Databases List -->
    <div class="bg-slate-950 border border-slate-800 rounded-xl overflow-hidden shadow-sm">
        <div class="p-6 border-b border-slate-800">
            <h3 class="text-base font-semibold text-white">Active Relational Databases</h3>
        </div>

        <table class="w-full text-left text-sm text-slate-300">
            <thead class="bg-slate-900 text-xs uppercase text-slate-400 border-b border-slate-800">
                <tr>
                    <th class="px-6 py-3.5">Database Name</th>
                    <th class="px-6 py-3.5">Assigned Users</th>
                    <th class="px-6 py-3.5">Charset / Collation</th>
                    <th class="px-6 py-3.5">Size</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-slate-800/60 font-mono text-xs">
                @forelse($databases as $db)
                    <tr class="hover:bg-slate-900/30">
                        <td class="px-6 py-4 font-bold text-white">{{ $db->name }}</td>
                        <td class="px-6 py-4">
                            @forelse($db->users as $u)
                                <span class="px-2 py-0.5 rounded bg-slate-900 text-cyan-400 border border-slate-800 mr-1">{{ $u->username }}</span>
                            @empty
                                <span class="text-slate-500 italic">No users granted</span>
                            @endforelse
                        </td>
                        <td class="px-6 py-4 text-slate-400">{{ $db->charset }} ({{ $db->collation }})</td>
                        <td class="px-6 py-4 text-slate-400">{{ number_format($db->size_bytes / 1024, 1) }} KB</td>
                    </tr>
                @empty
                    <tr>
                        <td colspan="4" class="px-6 py-8 text-center text-slate-500 font-sans">
                            No databases created yet.
                        </td>
                    </tr>
                @endforelse
            </tbody>
        </table>
    </div>
</div>
@endsection

