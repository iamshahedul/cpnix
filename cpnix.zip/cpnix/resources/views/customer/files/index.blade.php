@extends('layouts.customer', ['title' => 'File Manager'])

@section('page_title', 'File Manager')

@section('content')
<div class="space-y-6">
    <div class="flex items-center justify-between bg-slate-950 p-4 rounded-xl border border-slate-800">
        <div class="flex items-center space-x-2 text-sm font-mono text-slate-300">
            <span class="text-slate-500">Path:</span>
            <span class="text-emerald-400 font-bold">/home/{{ $account->username }}/{{ $relativeDir }}</span>
        </div>
        <div class="text-xs text-slate-400">
            Enforcing strict canonical boundary
        </div>
    </div>

    <!-- File Browser Table -->
    <div class="bg-slate-950 border border-slate-800 rounded-xl overflow-hidden shadow-sm">
        <table class="w-full text-left text-sm text-slate-300">
            <thead class="bg-slate-900 text-xs uppercase text-slate-400 border-b border-slate-800">
                <tr>
                    <th class="px-6 py-3.5">Name</th>
                    <th class="px-6 py-3.5">Size</th>
                    <th class="px-6 py-3.5">Permissions</th>
                    <th class="px-6 py-3.5">Last Modified</th>
                    <th class="px-6 py-3.5 text-right">Actions</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-slate-800/60 font-mono text-xs">
                @forelse($items as $item)
                    <tr class="hover:bg-slate-900/30">
                        <td class="px-6 py-3.5 flex items-center space-x-3">
                            @if($item['is_dir'])
                                <svg class="w-4 h-4 text-amber-400" fill="currentColor" viewBox="0 0 20 20"><path d="M2 6a2 2 0 012-2h5l2 2h5a2 2 0 012 2v6a2 2 0 01-2 2H4a2 2 0 01-2-2V6z"/></svg>
                                <span class="font-bold text-white">{{ $item['name'] }}</span>
                            @else
                                <svg class="w-4 h-4 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 21h10a2 2 0 002-2V9.414a1 1 0 00-.293-.707l-5.414-5.414A1 1 0 0012.586 3H7a2 2 0 00-2 2v14a2 2 0 002 2z"/></svg>
                                <span class="text-slate-200">{{ $item['name'] }}</span>
                            @endif
                        </td>
                        <td class="px-6 py-3.5 text-slate-400">{{ $item['is_dir'] ? '-' : number_format($item['size'] / 1024, 1) . ' KB' }}</td>
                        <td class="px-6 py-3.5 text-slate-400">{{ $item['permissions'] }}</td>
                        <td class="px-6 py-3.5 text-slate-500">{{ date('Y-m-d H:i', $item['modified_at']) }}</td>
                        <td class="px-6 py-3.5 text-right">
                            @if(!$item['is_dir'])
                                <a href="{{ route('customer.files.edit', ['file' => trim($relativeDir . '/' . $item['name'], '/')]) }}" class="text-xs text-cyan-400 hover:underline">Edit</a>
                            @endif
                        </td>
                    </tr>
                @empty
                    <tr>
                        <td colspan="5" class="px-6 py-8 text-center text-slate-500 font-sans">
                            Directory is empty or managed remotely on the node agent.
                        </td>
                    </tr>
                @endforelse
            </tbody>
        </table>
    </div>
</div>
@endsection

