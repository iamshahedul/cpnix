@extends('layouts.customer', ['title' => 'SSL / TLS'])

@section('page_title', 'SSL / TLS Certificates (ACME Let\'s Encrypt)')

@section('content')
<div class="space-y-8">
    <!-- Request SSL Form -->
    <div class="bg-slate-950 border border-slate-800 rounded-xl p-6 shadow-sm">
        <h3 class="text-base font-semibold text-white mb-1">Issue Free Let's Encrypt Certificate</h3>
        <p class="text-xs text-slate-400 mb-6">Automatically verifies domain ownership via HTTP-01 challenge and configures Nginx</p>

        <form method="POST" action="{{ route('customer.ssl.request') }}" class="flex items-end space-x-4">
            @csrf
            <div class="flex-1">
                <label class="block text-xs font-medium text-slate-300 mb-1">Select Domain</label>
                <select name="domain" required class="w-full px-3.5 py-2 rounded-lg bg-slate-900 border border-slate-700 text-sm text-white font-mono focus:outline-none focus:ring-2 focus:ring-violet-500">
                    @foreach($domains as $d)
                        <option value="{{ $d->domain }}">{{ $d->domain }}</option>
                    @endforeach
                </select>
            </div>

            <button type="submit" class="px-6 py-2 rounded-lg bg-violet-600 hover:bg-violet-500 text-white font-semibold text-sm transition-colors shadow-sm">
                Request & Install SSL
            </button>
        </form>
    </div>

    <!-- Active Certificates Table -->
    <div class="bg-slate-950 border border-slate-800 rounded-xl overflow-hidden shadow-sm">
        <div class="p-6 border-b border-slate-800">
            <h3 class="text-base font-semibold text-white">Installed Certificates</h3>
        </div>

        <table class="w-full text-left text-sm text-slate-300">
            <thead class="bg-slate-900 text-xs uppercase text-slate-400 border-b border-slate-800">
                <tr>
                    <th class="px-6 py-3.5">Domain</th>
                    <th class="px-6 py-3.5">Provider</th>
                    <th class="px-6 py-3.5">Issued At</th>
                    <th class="px-6 py-3.5">Expires At</th>
                    <th class="px-6 py-3.5">Auto Renew</th>
                    <th class="px-6 py-3.5">Status</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-slate-800/60 font-mono text-xs">
                @forelse($certificates as $cert)
                    <tr class="hover:bg-slate-900/30">
                        <td class="px-6 py-4 font-bold text-white">{{ $cert->domain }}</td>
                        <td class="px-6 py-4 uppercase text-slate-400">{{ str_replace('_', ' ', $cert->provider) }}</td>
                        <td class="px-6 py-4 text-slate-400">{{ $cert->issued_at ? $cert->issued_at->format('Y-m-d') : '-' }}</td>
                        <td class="px-6 py-4 text-slate-400">{{ $cert->expires_at ? $cert->expires_at->format('Y-m-d') : '-' }}</td>
                        <td class="px-6 py-4 text-emerald-400">{{ $cert->auto_renew ? 'Enabled' : 'Disabled' }}</td>
                        <td class="px-6 py-4">
                            <span class="px-2 py-0.5 rounded text-xs bg-emerald-950 text-emerald-400 border border-emerald-800">{{ ucfirst($cert->status) }}</span>
                        </td>
                    </tr>
                @empty
                    <tr>
                        <td colspan="6" class="px-6 py-8 text-center text-slate-500 font-sans">
                            No SSL certificates installed yet.
                        </td>
                    </tr>
                @endforelse
            </tbody>
        </table>
    </div>
</div>
@endsection

