@extends('layouts.admin', ['title' => 'Service Administration'])

@section('page_title', 'System Services Administration')

@section('content')
<div class="space-y-8">
    <!-- Server Selector -->
    <div class="bg-slate-950 border border-slate-800 rounded-xl p-6 shadow-sm flex items-center justify-between">
        <div>
            <h2 class="text-xl font-bold text-white">Target Node: {{ $currentServer?->name ?? 'Default Node' }}</h2>
            <p class="text-xs text-slate-400 mt-1">IP: {{ $currentServer?->ip_address }} | Hostname: {{ $currentServer?->hostname }}</p>
        </div>

        @if($servers->count() > 1)
            <form method="GET" action="{{ route('admin.services.index') }}" class="flex items-center space-x-2">
                <label class="text-xs text-slate-400">Node:</label>
                <select name="server_id" onchange="this.form.submit()" class="px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-700 text-xs text-white focus:outline-none focus:ring-2 focus:ring-cyan-500">
                    @foreach($servers as $s)
                        <option value="{{ $s->id }}" {{ $s->id == $currentServer?->id ? 'selected' : '' }}>{{ $s->name }}</option>
                    @endforeach
                </select>
            </form>
        @endif
    </div>

    <!-- Services Table -->
    <div class="bg-slate-950 border border-slate-800 rounded-xl overflow-hidden shadow-sm">
        <div class="p-6 border-b border-slate-800">
            <h3 class="text-base font-semibold text-white">Managed Linux Host Services</h3>
            <p class="text-xs text-slate-400 mt-0.5">Configuration validation executes automatically prior to reload</p>
        </div>

        <table class="w-full text-left text-sm text-slate-300">
            <thead class="bg-slate-900 text-xs uppercase text-slate-400 border-b border-slate-800">
                <tr>
                    <th class="px-6 py-3.5">Service Name</th>
                    <th class="px-6 py-3.5">Category</th>
                    <th class="px-6 py-3.5">Systemd Unit</th>
                    <th class="px-6 py-3.5">Status</th>
                    <th class="px-6 py-3.5 text-right">Operations</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-slate-800/60 font-mono text-xs">
                @foreach($services as $svc)
                    <tr class="hover:bg-slate-900/30">
                        <td class="px-6 py-4 font-sans text-sm font-semibold text-white">
                            {{ $svc['display'] }}
                        </td>
                        <td class="px-6 py-4 font-sans text-slate-400">{{ $svc['category'] }}</td>
                        <td class="px-6 py-4 text-cyan-400">{{ $svc['name'] }}.service</td>
                        <td class="px-6 py-4">
                            <span class="px-2 py-0.5 rounded text-xs bg-emerald-950 text-emerald-400 border border-emerald-800">Active (Running)</span>
                        </td>
                        <td class="px-6 py-4 text-right space-x-2 font-sans">
                            @if($svc['name'] !== 'cpnix-agent')
                                <form method="POST" action="{{ route('admin.services.operate', $currentServer) }}" class="inline">
                                    @csrf
                                    <input type="hidden" name="service" value="{{ $svc['name'] }}">
                                    <input type="hidden" name="action" value="reload">
                                    <button type="submit" class="text-xs text-cyan-400 hover:text-cyan-300 font-medium">Reload</button>
                                </form>
                                <span class="text-slate-700">|</span>
                                <form method="POST" action="{{ route('admin.services.operate', $currentServer) }}" onsubmit="return confirm('Restart {{ $svc['name'] }}?');" class="inline">
                                    @csrf
                                    <input type="hidden" name="service" value="{{ $svc['name'] }}">
                                    <input type="hidden" name="action" value="restart">
                                    <button type="submit" class="text-xs text-amber-400 hover:text-amber-300 font-medium">Restart</button>
                                </form>
                            @else
                                <span class="text-slate-500 italic">Self-Managed</span>
                            @endif
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>
</div>
@endsection

