@extends('layouts.admin', ['title' => 'Dashboard'])

@section('page_title', 'System Administrator Overview')

@section('content')
<div class="space-y-8">
    <!-- Top Stats Row -->
    <div class="grid grid-cols-1 md:grid-cols-4 gap-6">
        <!-- Servers -->
        <div class="p-6 rounded-xl bg-slate-950 border border-slate-800 shadow-sm">
            <div class="flex items-center justify-between text-slate-400 mb-2">
                <span class="text-xs font-semibold uppercase tracking-wider">Nodes / Servers</span>
                <span class="p-2 rounded-lg bg-slate-900 text-cyan-400">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 12h14M5 12a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v4a2 2 0 01-2 2M5 12a2 2 0 00-2 2v4a2 2 0 002 2h14a2 2 0 002-2v-4a2 2 0 00-2-2m-2-4h.01M17 16h.01"/></svg>
                </span>
            </div>
            <div class="text-3xl font-bold text-white">{{ $totalServers }}</div>
            <div class="mt-2 text-xs text-slate-400 flex items-center space-x-2">
                <span class="text-emerald-400 font-medium">{{ $onlineServers }} Online</span>
                <span>•</span>
                <span class="text-slate-500">{{ $offlineServers }} Inactive</span>
            </div>
        </div>

        <!-- Hosting Accounts -->
        <div class="p-6 rounded-xl bg-slate-950 border border-slate-800 shadow-sm">
            <div class="flex items-center justify-between text-slate-400 mb-2">
                <span class="text-xs font-semibold uppercase tracking-wider">Hosting Accounts</span>
                <span class="p-2 rounded-lg bg-slate-900 text-blue-400">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"/></svg>
                </span>
            </div>
            <div class="text-3xl font-bold text-white">{{ $totalAccounts }}</div>
            <div class="mt-2 text-xs text-slate-400 flex items-center space-x-2">
                <span class="text-emerald-400 font-medium">{{ $activeAccounts }} Active</span>
                <span>•</span>
                <span class="text-amber-400">{{ $suspendedAccounts }} Suspended</span>
            </div>
        </div>

        <!-- Resellers -->
        <div class="p-6 rounded-xl bg-slate-950 border border-slate-800 shadow-sm">
            <div class="flex items-center justify-between text-slate-400 mb-2">
                <span class="text-xs font-semibold uppercase tracking-wider">Active Resellers</span>
                <span class="p-2 rounded-lg bg-slate-900 text-amber-400">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"/></svg>
                </span>
            </div>
            <div class="text-3xl font-bold text-white">{{ $totalResellers }}</div>
            <div class="mt-2 text-xs text-slate-400">
                Delegated Tenant Pools
            </div>
        </div>

        <!-- Health & Status -->
        <div class="p-6 rounded-xl bg-slate-950 border border-slate-800 shadow-sm">
            <div class="flex items-center justify-between text-slate-400 mb-2">
                <span class="text-xs font-semibold uppercase tracking-wider">System State</span>
                <span class="p-2 rounded-lg bg-slate-900 text-emerald-400">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
                </span>
            </div>
            <div class="text-xl font-bold text-emerald-400">Operational</div>
            <div class="mt-2 text-xs text-slate-400">
                Failures: <span class="{{ $failedAccounts > 0 ? 'text-rose-400 font-bold' : 'text-slate-400' }}">{{ $failedAccounts }}</span>
            </div>
        </div>
    </div>

    <!-- Servers Status Table -->
    <div class="bg-slate-950 border border-slate-800 rounded-xl overflow-hidden shadow-sm">
        <div class="p-6 border-b border-slate-800 flex items-center justify-between">
            <div>
                <h3 class="text-base font-semibold text-white">Managed Infrastructure Nodes</h3>
                <p class="text-xs text-slate-400 mt-0.5">Real-time health from cpnix-agent daemons</p>
            </div>
            <a href="{{ route('admin.servers.create') }}" class="px-4 py-2 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white text-sm font-semibold transition-colors">
                + Register Server
            </a>
        </div>

        <div class="overflow-x-auto">
            <table class="w-full text-left text-sm text-slate-300">
                <thead class="bg-slate-900 text-xs uppercase text-slate-400 border-b border-slate-800">
                    <tr>
                        <th class="px-6 py-3.5">Server / Hostname</th>
                        <th class="px-6 py-3.5">IP Address</th>
                        <th class="px-6 py-3.5">Distribution</th>
                        <th class="px-6 py-3.5">Accounts</th>
                        <th class="px-6 py-3.5">Status</th>
                        <th class="px-6 py-3.5 text-right">Actions</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-800/60">
                    @forelse($servers as $server)
                        <tr class="hover:bg-slate-900/40 transition-colors">
                            <td class="px-6 py-4">
                                <div class="font-medium text-white">{{ $server->name }}</div>
                                <div class="text-xs text-slate-500 font-mono">{{ $server->hostname }}</div>
                            </td>
                            <td class="px-6 py-4 font-mono text-xs">{{ $server->ip_address }}</td>
                            <td class="px-6 py-4 capitalize text-slate-400">{{ $server->os_family }}</td>
                            <td class="px-6 py-4 text-slate-400">{{ $server->hostingAccounts->count() }} / {{ $server->max_accounts }}</td>
                            <td class="px-6 py-4">
                                @if($server->status === 'online')
                                    <span class="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-emerald-950 text-emerald-400 border border-emerald-800">
                                        Online
                                    </span>
                                @else
                                    <span class="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-rose-950 text-rose-400 border border-rose-800">
                                        {{ ucfirst($server->status) }}
                                    </span>
                                @endif
                            </td>
                            <td class="px-6 py-4 text-right">
                                <form method="POST" action="{{ route('admin.servers.test', $server) }}" class="inline-block">
                                    @csrf
                                    <button type="submit" class="text-xs text-cyan-400 hover:text-cyan-300 font-medium">Test Connection</button>
                                </form>
                                <span class="mx-2 text-slate-700">|</span>
                                <a href="{{ route('admin.servers.show', $server) }}" class="text-xs text-slate-400 hover:text-white font-medium">Details</a>
                            </td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="6" class="px-6 py-8 text-center text-slate-500">
                                No servers registered yet. Click "+ Register Server" to enroll your first Linux hosting node.
                            </td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>

    <!-- Recent Audit Logs -->
    <div class="bg-slate-950 border border-slate-800 rounded-xl overflow-hidden shadow-sm">
        <div class="p-6 border-b border-slate-800">
            <h3 class="text-base font-semibold text-white">Recent Security Audit Logs</h3>
            <p class="text-xs text-slate-400 mt-0.5">Immutable record of administrative and tenant mutations</p>
        </div>

        <div class="divide-y divide-slate-800/60 font-mono text-xs">
            @forelse($recentAuditLogs as $log)
                <div class="p-4 flex items-center justify-between hover:bg-slate-900/30">
                    <div class="flex items-center space-x-3">
                        <span class="px-2 py-0.5 rounded bg-slate-900 text-cyan-400 border border-slate-800">{{ $log->action }}</span>
                        <span class="text-slate-400">Actor: <span class="text-slate-300">{{ $log->actor_name }}</span></span>
                        @if($log->entity_type)
                            <span class="text-slate-500">Target: {{ $log->entity_type }} #{{ $log->entity_id }}</span>
                        @endif
                    </div>
                    <div class="text-slate-500">{{ $log->created_at->diffForHumans() }} ({{ $log->ip_address }})</div>
                </div>
            @empty
                <div class="p-6 text-center text-slate-500">No audit logs recorded yet.</div>
            @endforelse
        </div>
    </div>
</div>
@endsection

