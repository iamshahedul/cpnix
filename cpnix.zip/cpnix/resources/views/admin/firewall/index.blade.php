@extends('layouts.admin', ['title' => 'Firewall & Security'])

@section('page_title', 'Perimeter Firewall & Port Filtering')

@section('content')
<div class="space-y-8">
    <!-- Server Selector -->
    <div class="bg-slate-950 border border-slate-800 rounded-xl p-6 shadow-sm flex items-center justify-between">
        <div>
            <h2 class="text-xl font-bold text-white">Node Firewall: {{ $currentServer?->name ?? 'Default Node' }}</h2>
            <p class="text-xs text-slate-400 mt-1">IP: {{ $currentServer?->ip_address }} | nftables / ufw backend integration</p>
        </div>

        @if($servers->count() > 1)
            <form method="GET" action="{{ route('admin.firewall.index') }}" class="flex items-center space-x-2">
                <label class="text-xs text-slate-400">Node:</label>
                <select name="server_id" onchange="this.form.submit()" class="px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-700 text-xs text-white focus:outline-none focus:ring-2 focus:ring-cyan-500">
                    @foreach($servers as $s)
                        <option value="{{ $s->id }}" {{ $s->id == $currentServer?->id ? 'selected' : '' }}>{{ $s->name }}</option>
                    @endforeach
                </select>
            </form>
        @endif
    </div>

    <!-- Add Rule Form -->
    @if($currentServer)
    <div class="bg-slate-950 border border-slate-800 rounded-xl p-6 shadow-sm">
        <h3 class="text-base font-semibold text-white mb-1">Add Firewall Rule</h3>
        <p class="text-xs text-slate-400 mb-6">Filter incoming network traffic by port, protocol, and CIDR subnet</p>

        <form method="POST" action="{{ route('admin.firewall.store', $currentServer) }}" class="grid grid-cols-1 md:grid-cols-5 gap-4">
            @csrf

            <div>
                <label class="block text-xs font-medium text-slate-300 mb-1">Port (1-65535)</label>
                <input type="number" name="port" placeholder="3306" min="1" max="65535" required
                    class="w-full px-3.5 py-2 rounded-lg bg-slate-900 border border-slate-700 text-sm text-white font-mono focus:outline-none focus:ring-2 focus:ring-cyan-500">
            </div>

            <div>
                <label class="block text-xs font-medium text-slate-300 mb-1">Protocol</label>
                <select name="protocol" class="w-full px-3.5 py-2 rounded-lg bg-slate-900 border border-slate-700 text-sm text-white font-mono focus:outline-none focus:ring-2 focus:ring-cyan-500">
                    <option value="tcp" selected>TCP</option>
                    <option value="udp">UDP</option>
                    <option value="both">Both (TCP & UDP)</option>
                </select>
            </div>

            <div>
                <label class="block text-xs font-medium text-slate-300 mb-1">Action</label>
                <select name="action" class="w-full px-3.5 py-2 rounded-lg bg-slate-900 border border-slate-700 text-sm text-white font-mono focus:outline-none focus:ring-2 focus:ring-cyan-500">
                    <option value="allow" selected>ALLOW</option>
                    <option value="deny">DENY (Drop)</option>
                    <option value="reject">REJECT (RST)</option>
                </select>
            </div>

            <div>
                <label class="block text-xs font-medium text-slate-300 mb-1">Source IP / CIDR</label>
                <input type="text" name="source_ip" value="0.0.0.0/0" required
                    class="w-full px-3.5 py-2 rounded-lg bg-slate-900 border border-slate-700 text-sm text-white font-mono focus:outline-none focus:ring-2 focus:ring-cyan-500">
            </div>

            <div class="flex items-end">
                <button type="submit" class="w-full py-2 px-4 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white font-semibold text-sm transition-colors shadow-sm">
                    + Add Rule
                </button>
            </div>
        </form>
    </div>
    @endif

    <!-- Rules Table -->
    <div class="bg-slate-950 border border-slate-800 rounded-xl overflow-hidden shadow-sm">
        <div class="p-6 border-b border-slate-800">
            <h3 class="text-base font-semibold text-white">Active Firewall Inbound Policies</h3>
        </div>

        <table class="w-full text-left text-sm text-slate-300">
            <thead class="bg-slate-900 text-xs uppercase text-slate-400 border-b border-slate-800 font-mono">
                <tr>
                    <th class="px-6 py-3.5">Port</th>
                    <th class="px-6 py-3.5">Protocol</th>
                    <th class="px-6 py-3.5">Action</th>
                    <th class="px-6 py-3.5">Source IP / CIDR</th>
                    <th class="px-6 py-3.5">Description</th>
                    <th class="px-6 py-3.5 text-right">Actions</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-slate-800/60 font-mono text-xs">
                @forelse($rules as $r)
                    <tr class="hover:bg-slate-900/30">
                        <td class="px-6 py-4 font-bold text-white">{{ $r->port }}</td>
                        <td class="px-6 py-4 uppercase text-slate-300">{{ $r->protocol }}</td>
                        <td class="px-6 py-4">
                            @if($r->action === 'allow')
                                <span class="px-2 py-0.5 rounded text-[11px] font-bold bg-emerald-950 text-emerald-400 border border-emerald-800">ALLOW</span>
                            @else
                                <span class="px-2 py-0.5 rounded text-[11px] font-bold bg-rose-950 text-rose-400 border border-rose-800">{{ strtoupper($r->action) }}</span>
                            @endif
                        </td>
                        <td class="px-6 py-4 text-slate-300">{{ $r->source_ip }}</td>
                        <td class="px-6 py-4 text-slate-400 font-sans">{{ $r->description ?? '-' }}</td>
                        <td class="px-6 py-4 text-right font-sans">
                            <form method="POST" action="{{ route('admin.firewall.destroy', $r) }}" onsubmit="return confirm('Remove rule for port {{ $r->port }}?');" class="inline">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="text-xs text-rose-400 hover:text-rose-300">Delete</button>
                            </form>
                        </td>
                    </tr>
                @empty
                    <tr>
                        <td colspan="6" class="px-6 py-8 text-center text-slate-500 font-sans">
                            No firewall rules defined.
                        </td>
                    </tr>
                @endforelse
            </tbody>
        </table>
    </div>
</div>
@endsection

