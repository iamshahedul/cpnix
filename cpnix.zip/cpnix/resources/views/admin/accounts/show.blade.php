@extends('layouts.admin', ['title' => $account->primary_domain])

@section('page_title', 'Account: ' . $account->primary_domain)

@section('content')
<div class="space-y-8">
    <!-- Account Overview Card -->
    <div class="bg-slate-950 border border-slate-800 rounded-xl p-6 shadow-sm">
        <div class="flex items-center justify-between pb-6 border-b border-slate-800">
            <div>
                <div class="flex items-center space-x-3">
                    <h2 class="text-2xl font-bold text-white">{{ $account->primary_domain }}</h2>
                    @if($account->status === 'ACTIVE')
                        <span class="px-2.5 py-0.5 rounded text-xs font-semibold bg-emerald-950 text-emerald-400 border border-emerald-800">Active</span>
                    @elseif($account->status === 'SUSPENDED')
                        <span class="px-2.5 py-0.5 rounded text-xs font-semibold bg-amber-950 text-amber-400 border border-amber-800">Suspended</span>
                    @else
                        <span class="px-2.5 py-0.5 rounded text-xs font-semibold bg-rose-950 text-rose-400 border border-rose-800">{{ $account->status }}</span>
                    @endif
                </div>
                <div class="text-xs text-slate-400 font-mono mt-1">
                    Username: <span class="text-slate-200">{{ $account->username }}</span> | UID: {{ $account->uid }} | GID: {{ $account->gid }} | Home: {{ $account->home_directory }}
                </div>
            </div>

            <div class="flex items-center space-x-3">
                @if($account->status === 'ACTIVE')
                    <form method="POST" action="{{ route('admin.accounts.suspend', $account) }}" onsubmit="return confirm('Suspend this account?');">
                        @csrf
                        <input type="hidden" name="reason" value="Suspended by administrator">
                        <button type="submit" class="px-4 py-2 rounded-lg bg-amber-950/80 border border-amber-800 text-amber-400 hover:bg-amber-900 text-xs font-semibold transition-colors">
                            Suspend Account
                        </button>
                    </form>
                @elseif($account->status === 'SUSPENDED')
                    <form method="POST" action="{{ route('admin.accounts.unsuspend', $account) }}">
                        @csrf
                        <button type="submit" class="px-4 py-2 rounded-lg bg-emerald-950/80 border border-emerald-800 text-emerald-400 hover:bg-emerald-900 text-xs font-semibold transition-colors">
                            Unsuspend Account
                        </button>
                    </form>
                @endif
            </div>
        </div>

        <div class="grid grid-cols-2 md:grid-cols-4 gap-6 pt-6 text-sm">
            <div>
                <span class="text-xs text-slate-500 uppercase tracking-wider block">Server Node</span>
                <span class="font-medium text-slate-200">{{ $account->server->name }} ({{ $account->server->ip_address }})</span>
            </div>
            <div>
                <span class="text-xs text-slate-500 uppercase tracking-wider block">Hosting Package</span>
                <span class="font-medium text-slate-200">{{ $account->package->name }}</span>
            </div>
            <div>
                <span class="text-xs text-slate-500 uppercase tracking-wider block">PHP Runtime</span>
                <span class="font-mono text-slate-200">PHP {{ $account->php_version }}</span>
            </div>
            <div>
                <span class="text-xs text-slate-500 uppercase tracking-wider block">Owner</span>
                <span class="font-medium text-slate-200">{{ $account->user->email }}</span>
            </div>
        </div>
    </div>

    <!-- Provisioning Execution History -->
    <div class="bg-slate-950 border border-slate-800 rounded-xl overflow-hidden shadow-sm">
        <div class="p-6 border-b border-slate-800">
            <h3 class="text-base font-semibold text-white">Durable Provisioning State Machine</h3>
            <p class="text-xs text-slate-400 mt-0.5">Execution logs and verified node operations</p>
        </div>

        <div class="p-6 space-y-4 font-mono text-xs">
            @forelse($account->provisioningJobs as $job)
                <div class="p-4 rounded-lg bg-slate-900/60 border border-slate-800 space-y-3">
                    <div class="flex items-center justify-between text-slate-400">
                        <span>Job UUID: <span class="text-cyan-400">{{ $job->uuid }}</span></span>
                        <span class="px-2 py-0.5 rounded text-xs {{ $job->status === 'COMPLETED' ? 'bg-emerald-950 text-emerald-400' : 'bg-rose-950 text-rose-400' }}">
                            {{ $job->status }} ({{ $job->completed_steps }}/{{ $job->total_steps }} steps)
                        </span>
                    </div>

                    <div class="space-y-2 pt-2 border-t border-slate-800/80">
                        @foreach($job->steps as $step)
                            <div class="flex items-center justify-between text-slate-300">
                                <div class="flex items-center space-x-2">
                                    <span class="w-4 h-4 rounded-full flex items-center justify-center text-[10px] {{ $step->status === 'COMPLETED' ? 'bg-emerald-500 text-slate-950' : 'bg-rose-500 text-white' }}">
                                        {{ $step->status === 'COMPLETED' ? '✓' : '✗' }}
                                    </span>
                                    <span>Step {{ $step->step_number }}: {{ $step->name }}</span>
                                </div>
                                <span class="text-slate-500">{{ $step->completed_at ? $step->completed_at->format('H:i:s') : 'Pending' }}</span>
                            </div>
                        @endforeach
                    </div>
                </div>
            @empty
                <div class="text-slate-500">No provisioning execution records logged.</div>
            @endforelse
        </div>
    </div>
</div>
@endsection

