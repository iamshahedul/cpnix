@extends('layouts.admin', ['title' => 'Hosting Accounts'])

@section('page_title', 'Hosting Accounts')

@section('content')
<div class="space-y-6">
    <div class="flex items-center justify-between">
        <div>
            <h2 class="text-xl font-bold text-white">Hosting Accounts</h2>
            <p class="text-sm text-slate-400">Manage multi-tenant Linux user accounts, domains, and quotas</p>
        </div>
        <a href="{{ route('admin.accounts.create') }}" class="px-4 py-2 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white text-sm font-semibold transition-colors">
            + Create Account
        </a>
    </div>

    <!-- Filters & Search -->
    <form method="GET" action="{{ route('admin.accounts.index') }}" class="flex items-center space-x-4 bg-slate-950 p-4 rounded-xl border border-slate-800">
        <div class="flex-1">
            <input type="text" name="search" value="{{ request('search') }}" placeholder="Search by domain or username..."
                class="w-full px-4 py-2 rounded-lg bg-slate-900 border border-slate-700 text-sm text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-cyan-500">
        </div>
        <div>
            <select name="status" class="px-4 py-2 rounded-lg bg-slate-900 border border-slate-700 text-sm text-white focus:outline-none focus:ring-2 focus:ring-cyan-500">
                <option value="">All Statuses</option>
                <option value="ACTIVE" {{ request('status') === 'ACTIVE' ? 'selected' : '' }}>Active</option>
                <option value="SUSPENDED" {{ request('status') === 'SUSPENDED' ? 'selected' : '' }}>Suspended</option>
                <option value="FAILED" {{ request('status') === 'FAILED' ? 'selected' : '' }}>Failed</option>
            </select>
        </div>
        <button type="submit" class="px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-white text-sm font-medium transition-colors">
            Filter
        </button>
    </form>

    <!-- Table -->
    <div class="bg-slate-950 border border-slate-800 rounded-xl overflow-hidden shadow-sm">
        <table class="w-full text-left text-sm text-slate-300">
            <thead class="bg-slate-900 text-xs uppercase text-slate-400 border-b border-slate-800">
                <tr>
                    <th class="px-6 py-3.5">Domain</th>
                    <th class="px-6 py-3.5">Username (UID)</th>
                    <th class="px-6 py-3.5">Server</th>
                    <th class="px-6 py-3.5">Package</th>
                    <th class="px-6 py-3.5">PHP</th>
                    <th class="px-6 py-3.5">Status</th>
                    <th class="px-6 py-3.5 text-right">Actions</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-slate-800/60">
                @forelse($accounts as $acc)
                    <tr class="hover:bg-slate-900/40 transition-colors">
                        <td class="px-6 py-4">
                            <a href="{{ route('admin.accounts.show', $acc) }}" class="font-medium text-cyan-400 hover:underline">
                                {{ $acc->primary_domain }}
                            </a>
                        </td>
                        <td class="px-6 py-4 font-mono text-xs">
                            {{ $acc->username }} <span class="text-slate-500">({{ $acc->uid }})</span>
                        </td>
                        <td class="px-6 py-4 text-slate-400">{{ $acc->server->name ?? 'Unassigned' }}</td>
                        <td class="px-6 py-4 text-slate-400">{{ $acc->package->name ?? 'None' }}</td>
                        <td class="px-6 py-4 font-mono text-xs">{{ $acc->php_version }}</td>
                        <td class="px-6 py-4">
                            @if($acc->status === 'ACTIVE')
                                <span class="px-2 py-0.5 rounded text-xs font-medium bg-emerald-950 text-emerald-400 border border-emerald-800">Active</span>
                            @elseif($acc->status === 'SUSPENDED')
                                <span class="px-2 py-0.5 rounded text-xs font-medium bg-amber-950 text-amber-400 border border-amber-800">Suspended</span>
                            @elseif($acc->status === 'PROVISIONING')
                                <span class="px-2 py-0.5 rounded text-xs font-medium bg-cyan-950 text-cyan-400 border border-cyan-800 animate-pulse">Provisioning</span>
                            @else
                                <span class="px-2 py-0.5 rounded text-xs font-medium bg-rose-950 text-rose-400 border border-rose-800">{{ $acc->status }}</span>
                            @endif
                        </td>
                        <td class="px-6 py-4 text-right space-x-2">
                            <a href="{{ route('admin.accounts.show', $acc) }}" class="text-xs text-slate-400 hover:text-white font-medium">Manage</a>
                        </td>
                    </tr>
                @empty
                    <tr>
                        <td colspan="7" class="px-6 py-8 text-center text-slate-500">
                            No hosting accounts match the criteria.
                        </td>
                    </tr>
                @endforelse
            </tbody>
        </table>

        @if($accounts->hasPages())
            <div class="p-4 border-t border-slate-800">
                {{ $accounts->links() }}
            </div>
        @endif
    </div>
</div>
@endsection

