@extends('layouts.admin', ['title' => 'Create Hosting Account'])

@section('page_title', 'Create New Hosting Account')

@section('content')
<div class="max-w-3xl">
    <div class="bg-slate-950 border border-slate-800 rounded-xl p-8 shadow-sm">
        <div class="mb-6 pb-6 border-b border-slate-800">
            <h2 class="text-lg font-bold text-white">Account Specification</h2>
            <p class="text-sm text-slate-400">Provisions an isolated Linux identity, PHP-FPM pool, and Nginx virtual host</p>
        </div>

        <form method="POST" action="{{ route('admin.accounts.store') }}" class="space-y-6">
            @csrf

            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <!-- Primary Domain -->
                <div>
                    <label class="block text-sm font-medium text-slate-300 mb-1.5">Primary Domain</label>
                    <input type="text" name="domain" value="{{ old('domain') }}" placeholder="example.com" required
                        class="w-full px-4 py-2.5 rounded-lg bg-slate-900 border border-slate-700 text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-cyan-500 font-mono text-sm">
                </div>

                <!-- Username -->
                <div>
                    <label class="block text-sm font-medium text-slate-300 mb-1.5">Linux Username</label>
                    <input type="text" name="username" value="{{ old('username') }}" placeholder="usr_example" required
                        class="w-full px-4 py-2.5 rounded-lg bg-slate-900 border border-slate-700 text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-cyan-500 font-mono text-sm">
                    <p class="text-xs text-slate-500 mt-1">3-16 alphanumeric characters. Unique system UID will be assigned.</p>
                </div>

                <!-- Owner Email -->
                <div>
                    <label class="block text-sm font-medium text-slate-300 mb-1.5">Customer / Owner Email</label>
                    <input type="email" name="owner_email" value="{{ old('owner_email') }}" placeholder="client@example.com" required
                        class="w-full px-4 py-2.5 rounded-lg bg-slate-900 border border-slate-700 text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-cyan-500 text-sm">
                </div>

                <!-- Password -->
                <div>
                    <label class="block text-sm font-medium text-slate-300 mb-1.5">Account Password</label>
                    <input type="password" name="password" required
                        class="w-full px-4 py-2.5 rounded-lg bg-slate-900 border border-slate-700 text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-cyan-500 text-sm">
                </div>

                <!-- Target Server -->
                <div>
                    <label class="block text-sm font-medium text-slate-300 mb-1.5">Destination Server Node</label>
                    <select name="server_id" required class="w-full px-4 py-2.5 rounded-lg bg-slate-900 border border-slate-700 text-white focus:outline-none focus:ring-2 focus:ring-cyan-500 text-sm">
                        <option value="">Select a server...</option>
                        @foreach($servers as $srv)
                            <option value="{{ $srv->id }}" {{ old('server_id') == $srv->id ? 'selected' : '' }}>
                                {{ $srv->name }} ({{ $srv->ip_address }} - {{ $srv->hostingAccounts()->count() }}/{{ $srv->max_accounts }})
                            </option>
                        @endforeach
                    </select>
                </div>

                <!-- Package -->
                <div>
                    <label class="block text-sm font-medium text-slate-300 mb-1.5">Hosting Package</label>
                    <select name="package_id" required class="w-full px-4 py-2.5 rounded-lg bg-slate-900 border border-slate-700 text-white focus:outline-none focus:ring-2 focus:ring-cyan-500 text-sm">
                        <option value="">Select a package...</option>
                        @foreach($packages as $pkg)
                            <option value="{{ $pkg->id }}" {{ old('package_id') == $pkg->id ? 'selected' : '' }}>
                                {{ $pkg->name }} (Disk: {{ $pkg->disk_quota_mb }}MB)
                            </option>
                        @endforeach
                    </select>
                </div>

                <!-- PHP Version -->
                <div>
                    <label class="block text-sm font-medium text-slate-300 mb-1.5">PHP Version</label>
                    <select name="php_version" required class="w-full px-4 py-2.5 rounded-lg bg-slate-900 border border-slate-700 text-white focus:outline-none focus:ring-2 focus:ring-cyan-500 text-sm font-mono">
                        <option value="8.2" selected>PHP 8.2 (Recommended)</option>
                        <option value="8.3">PHP 8.3 (Latest)</option>
                        <option value="8.1">PHP 8.1</option>
                        <option value="8.0">PHP 8.0</option>
                        <option value="7.4">PHP 7.4 (Legacy)</option>
                    </select>
                </div>

                <!-- Reseller Assignment -->
                <div>
                    <label class="block text-sm font-medium text-slate-300 mb-1.5">Reseller Owner (Optional)</label>
                    <select name="reseller_id" class="w-full px-4 py-2.5 rounded-lg bg-slate-900 border border-slate-700 text-white focus:outline-none focus:ring-2 focus:ring-cyan-500 text-sm">
                        <option value="">Direct Administrator Account</option>
                        @foreach($resellers as $res)
                            <option value="{{ $res->id }}" {{ old('reseller_id') == $res->id ? 'selected' : '' }}>
                                {{ $res->company_name ?? $res->user->name }} ({{ $res->user->email }})
                            </option>
                        @endforeach
                    </select>
                </div>
            </div>

            <div class="pt-6 border-t border-slate-800 flex items-center justify-end space-x-4">
                <a href="{{ route('admin.accounts.index') }}" class="px-5 py-2.5 rounded-lg text-sm font-medium text-slate-400 hover:text-white transition-colors">
                    Cancel
                </a>
                <button type="submit" class="px-6 py-2.5 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white font-semibold text-sm shadow-lg shadow-cyan-600/20 transition-all">
                    Provision Account
                </button>
            </div>
        </form>
    </div>
</div>
@endsection

