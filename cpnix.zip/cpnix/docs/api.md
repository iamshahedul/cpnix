# CPNix REST API Reference

## 1. Authentication & Protocols

The CPNix Control Plane provides a versioned REST API (`/api/v1`) for external integrations, billing platforms (such as WHMCS or custom billing portals), and automated server orchestration.

### 1.1 Bearer Token Authentication
Requests must include an Authorization header with a valid API token:
```http
Authorization: Bearer cpnix_sec_9f82d1c7a4e6...
```
Tokens are generated in the Administrator or Reseller dashboard and carry explicit permission scopes:
- `accounts:read`, `accounts:write`
- `packages:read`, `packages:write`
- `servers:read`, `servers:write`
- `dns:read`, `dns:write`
- `backups:read`, `backups:write`

### 1.2 Rate Limiting
API requests are limited to **120 requests per minute** per API token. Exceeding limits returns HTTP `429 Too Many Requests` with `Retry-After` header.

### 1.3 Standard Response Format
All responses adhere to a consistent JSON schema:
```json
{
  "success": true,
  "data": { ... },
  "message": "Operation completed successfully.",
  "meta": {
    "timestamp": "2026-11-08T12:00:00Z",
    "request_id": "req_01h92k84js9"
  }
}
```

Error responses:
```json
{
  "success": false,
  "error": {
    "code": "RESOURCE_QUOTA_EXCEEDED",
    "message": "Disk quota allocation exceeds maximum allowable reseller limit.",
    "details": {
      "allocated_mb": 50000,
      "max_mb": 40000
    }
  },
  "meta": {
    "timestamp": "2026-11-08T12:00:00Z",
    "request_id": "req_01h92k84js9"
  }
}
```

---

## 2. Core Endpoints

### 2.1 Accounts API

#### `GET /api/v1/accounts`
List hosting accounts with pagination and filtering.

**Query Parameters:**
- `page` (integer, default: 1)
- `per_page` (integer, default: 25, max: 100)
- `status` (string, optional: `active`, `suspended`, `pending`, `terminated`)
- `search` (string, optional: domain or username)

#### `POST /api/v1/accounts`
Create and provision a new hosting account.

**Request Body:**
```json
{
  "domain": "example.com",
  "username": "exampleusr",
  "password": "SecurePassword123!#",
  "package_id": 1,
  "server_id": 1,
  "owner_email": "owner@example.com",
  "php_version": "8.2"
}
```

**Response (202 Accepted):**
```json
{
  "success": true,
  "data": {
    "id": 14,
    "username": "exampleusr",
    "domain": "example.com",
    "status": "QUEUED",
    "job_id": "job_01h87b41k9"
  },
  "message": "Hosting account queued for provisioning."
}
```

#### `GET /api/v1/accounts/{id}/status`
Query the real-time provisioning progress or operational status of an account.

#### `POST /api/v1/accounts/{id}/suspend`
Suspend an account immediately, disabling web vhost, PHP pool, and mailboxes.

#### `POST /api/v1/accounts/{id}/unsuspend`
Unsuspend an account, restoring web vhost, PHP pool, and mailboxes.

#### `DELETE /api/v1/accounts/{id}`
Schedule or perform account termination and data purge.

---

### 2.2 Packages API

#### `GET /api/v1/packages`
List available hosting packages with disk, bandwidth, and resource quotas.

#### `POST /api/v1/packages`
Create a new hosting package.

---

### 2.3 Servers API

#### `GET /api/v1/servers`
List registered infrastructure nodes and current telemetry status.

#### `POST /api/v1/servers`
Enroll a new server node into the CPNix cluster.

#### `GET /api/v1/servers/{id}/health`
Retrieve real-time node health (CPU, RAM, Disk, Services status).

---

### 2.4 DNS API

#### `GET /api/v1/dns/zones`
List DNS zones.

#### `POST /api/v1/dns/zones`
Create an authoritative DNS zone.

#### `POST /api/v1/dns/zones/{zone_id}/records`
Create or update a DNS record (`A`, `AAAA`, `CNAME`, `MX`, `TXT`, etc.).

---

### 2.5 Backups API

#### `POST /api/v1/accounts/{id}/backups`
Initiate on-demand verified account backup.

#### `GET /api/v1/accounts/{id}/backups`
List account backup snapshots with checksums and verification status.

