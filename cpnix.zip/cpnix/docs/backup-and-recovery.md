# CPNix Backup & Disaster Recovery Architecture

## 1. Principles of Reliable Backup

A backup in CPNix is not considered valid merely because a command exited with code 0. Every backup operation must satisfy the following pipeline:
1. **Quiescence**: Safe temporary snapshotting or database flushing (`mysqldump --single-transaction --quick`).
2. **Deterministic Archiving**: Streaming archive creation using standard tarball formats with zstandard (`.tar.zst`) or gzip (`.tar.gz`).
3. **Checksum Verification**: Calculation and storage of SHA-256 hash immediately upon archive completion.
4. **Integrity Testing**: Unpack testing against test archive structure verifying header validity and content listing.
5. **Separation of Concerns**: Storing backups on separate storage mounts, local storage partitions, or external S3/SFTP targets. Storing backups solely inside the user's home directory is explicitly prohibited.

---

## 2. Backup Archive Specification

CPNix generates structured account archives with deterministic layout:

```
cpnix-backup-{username}-{YYYYMMDD-HHmmss}.tar.gz
├── cpnix-manifest.json        # Schema version, account limits, packages, domains, metadata
├── home/                      # User files (public_html, custom files; excludes tmp & cache)
│   ├── public_html/
│   └── ...
├── databases/                 # Logical SQL dumps per database
│   ├── {username}_db1.sql.gz
│   └── {username}_db2.sql.gz
├── mail/                      # Dovecot Maildir virtual accounts and mailboxes
│   └── example.com/
│       ├── info/
│       └── contact/
├── dns/                       # DNS Zone exports (PowerDNS BIND-compatible zone format)
│   └── example.com.zone
├── ssl/                       # Issued certificates and private keys (encrypted)
│   └── example.com.crt
└── cron/                      # Account cron schedules
    └── crontab.txt
```

### 2.1 Manifest Schema (`cpnix-manifest.json`)
```json
{
  "version": "1.0",
  "created_at": "2026-11-08T12:00:00Z",
  "generator": "CPNix v1.0.0",
  "account": {
    "username": "exampleusr",
    "primary_domain": "example.com",
    "email": "owner@example.com",
    "package": "Gold",
    "php_version": "8.2",
    "uid": 10042,
    "gid": 10042
  },
  "domains": [
    { "domain": "example.com", "document_root": "public_html", "is_subdomain": false },
    { "domain": "blog.example.com", "document_root": "public_html/blog", "is_subdomain": true }
  ],
  "databases": ["exampleusr_wp", "exampleusr_app"],
  "database_users": ["exampleusr_wpuser", "exampleusr_appuser"],
  "checksums": {
    "databases/exampleusr_wp.sql.gz": "sha256:e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
    "home.tar.gz": "sha256:d4735e3a265e16eee03f59718b9b5d03019c07d8b6c51f90da3a666eec13ab35"
  }
}
```

---

## 3. Account Restoration Workflow

Restoration employs a non-destructive preview followed by an atomic transactional execution:

```
[User initiates restore]
           |
           v
[Step 1: Manifest & Archive Integrity Verification]
- Check SHA-256 signature of archive against recorded hash
- Validate cpnix-manifest.json format and schema version
           |
           v
[Step 2: Dry-Run Conflict Detection]
- Verify target Linux user existence (or allocate new UID if migrating)
- Inspect existing databases and domains; report conflicts
           |
           v
[Step 3: Account Restoration State Machine]
- Stop user's PHP-FPM pool temporarily to prevent concurrent mutations
- Extract `home/` directory preserving account UID/GID ownership
- Drop & Re-import MariaDB databases inside transactional context
- Restore email Maildirs with correct permissions (`0700`, owned by vmail/user)
- Re-install Nginx vhost & PHP-FPM configurations
- Re-import DNS records
- Start PHP-FPM pool and reload Nginx
           |
           v
[Step 4: Verification & Health Check]
- Verify HTTP response code on primary domain
- Verify MariaDB connection test using restored user
- Mark restore task COMPLETED in audit log
```

---

## 4. Disaster Recovery (Full Server Loss)

In the event of complete physical or hypervisor node failure:
1. Deploy fresh supported OS on replacement server.
2. Run automated CPNix installer (`scripts/install.sh --node-only`).
3. Restore Control Plane database backup or enroll replacement node in multi-node cluster.
4. Stream account archives from remote backup repository (SFTP / S3-compatible object storage).
5. Execute batch recovery orchestrator:
   ```bash
   php artisan cpnix:restore-node --node-id=2 --archive-dir=/mnt/remote-backups/node2
   ```
6. The orchestrator recreates UIDs, groups, configurations, databases, DNS zones, and sites sequentially, logging full progress to the administrator console.

