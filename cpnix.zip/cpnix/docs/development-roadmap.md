# CPNix Development Roadmap & Implementation Plan

## Phase Overview

| Phase | Title | Core Deliverables | Status |
| :--- | :--- | :--- | :--- |
| **Phase 1** | Foundation & Architecture | Architecture docs, threat model, Laravel domain models, migrations, RBAC policies, UI design tokens, seeders. | **Complete / In Progress** |
| **Phase 2** | Privileged Node Agent | Go `cpnix-agent`, mTLS/HMAC authentication, Debian & RHEL adapters, systemd service, safe command execution. | **Implemented** |
| **Phase 3** | Core Hosting Provisioning | Account lifecycle, Linux isolation, Nginx virtual hosts, multi-version PHP-FPM pools, state machine, job queue. | **Implemented** |
| **Phase 4** | Database, DNS & SSL | MariaDB/MySQL adapter, PowerDNS/BIND zone manager, ACME Let's Encrypt automation, SSL renewal scheduler. | **Implemented** |
| **Phase 5** | Reseller System | Reseller dashboard, hierarchical quotas, package assignments, tenant boundary isolation tests. | **Implemented** |
| **Phase 6** | Customer Management Tools | File manager, PHP version selector, email accounts (Dovecot/Postfix), SFTP manager, Cron manager, Backup manager. | **Implemented** |
| **Phase 7** | Administrator Operations | Multi-server node manager, system health monitoring, audit logging, service restart/reload safety checks. | **Implemented** |
| **Phase 8** | Production Readiness | Comprehensive test suite, automated installer, upgrade/rollback scripts, license audit, compatibility matrix. | **Implemented** |

---

## Detailed Task Breakdown

### Phase 1: Foundation
- [x] Comprehensive architectural, security, deployment, and API specifications.
- [x] Database migrations covering 18+ normalized entities (`users`, `servers`, `hosting_accounts`, `packages`, `domains`, `dns_zones`, `dns_records`, `databases`, `email_accounts`, `cron_jobs`, `backups`, `provisioning_jobs`, `audit_logs`).
- [x] Eloquent models with relations, type casting, and audit log integration.
- [x] RBAC policies (`Administrator`, `Reseller`, `Customer`).
- [x] Professional Blade templates + Tailwind CSS styling.

### Phase 2: Node Agent (`cpnix-agent` in Go)
- [x] HTTP/2 REST API with mTLS and HMAC-SHA256 signature verification.
- [x] OS Detection & abstract interface (`SystemAdapter`).
- [x] Debian/Ubuntu package & service adapter.
- [x] RHEL/Alma/Rocky package & service adapter.
- [x] Bounded process execution runner rejecting dynamic shell commands.
- [x] Health check and resource metrics endpoint (CPU, RAM, Disk, Inodes, Load).

### Phase 3: Core Hosting Provisioning
- [x] Multi-step provisioning workflow: Validation -> Reservation -> User/Group creation -> Home directory setup -> PHP-FPM pool generation -> Nginx vhost -> DNS registration -> Activation.
- [x] Idempotency tokens and step-level recovery.
- [x] Compensation/Rollback logic for failed provisioning attempts.
- [x] Real-time provisioning log streaming.

### Phase 4: Database, DNS, SSL
- [x] MariaDB root client for customer database & user provisioning with strict privileges.
- [x] DNS Zone & Record management with syntax validation.
- [x] ACME HTTP-01 challenge issuance with automatic webroot provisioning.

### Phase 5 & 6: Reseller & Customer Experience
- [x] Reseller quota limits (Disk, Bandwidth, Max Accounts).
- [x] Customer File Manager with path traversal prevention and size validation.
- [x] Customer Email Account manager with mailbox quota and password hashing.
- [x] Customer Cron Job manager with schedule validation.

### Phase 7 & 8: Administration, Testing & Packaging
- [x] Multi-node server enrollment and connectivity testing.
- [x] Full automated test suite (Unit, Feature, Isolation, Security, Agent).
- [x] Shell installer script with OS detection and prerequisite checks.
- [x] Upgrade and rollback automation.

