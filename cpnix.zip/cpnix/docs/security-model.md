# CPNix Security Model & Boundary Specification

## 1. Security Philosophy

CPNix operates under the principle of **Defense-in-Depth** and **Least Privilege**. Hosting control panels represent high-value targets due to multi-tenant isolation challenges and the concentration of administrative power. 

CPNix categorically rejects common architectural mistakes found in legacy panels:
- Never run web applications under the `root` account.
- Never construct shell commands via string concatenation.
- Never trust client-submitted identifiers (IDs, paths, user accounts) without server-side validation against authenticated session ownership.
- Never use `chmod 777` as an operational fix.
- Never disable Linux security mechanisms (SELinux, AppArmor, or nftables) to circumvent permission boundaries.

---

## 2. Security Boundaries

```
+-------------------------------------------------------------------------------+
| UNTRUSTED EXTERNAL ZONE                                                       |
| - Web Visitors & HTTP/HTTPS requests                                         |
| - SSH/SFTP inbound connections                                                |
| - Inbound SMTP, IMAP, POP3                                                    |
+---------------------------------------+---------------------------------------+
                                        |
+---------------------------------------v---------------------------------------+
| PERIMETER FILTERING (nftables / ufw)                                          |
| - Rate limiting on port 22/2222, 443, 8443 (CPNix Control Plane)              |
| - Drop invalid TCP packets, SYN flood mitigations                            |
+---------------------------------------+---------------------------------------+
                                        |
+---------------------------------------v---------------------------------------+
| CONTROL PLANE APPLICATION LAYER (Non-privileged: user cpnix)                  |
| - PHP-FPM process isolated with no sudo rights                                |
| - Strict CSRF, CSP, HSTS, secure session cookies (SameSite=Strict, HttpOnly)  |
| - Parameterized SQL queries (PDO/Eloquent) preventing SQL Injection           |
| - Blade contextual HTML escaping preventing Cross-Site Scripting (XSS)        |
| - Role-Based Access Control (RBAC) & Tenant Scope Policies                     |
+---------------------------------------+---------------------------------------+
                                        | mTLS / HMAC signed API requests
+---------------------------------------v---------------------------------------+
| PRIVILEGED AGENT LAYER (cpnix-agent: isolated daemon)                         |
| - Mutual TLS (mTLS) with client certificate verification                      |
| - Request replay protection via timestamp validation (window: 60s) and nonces |
| - Typed JSON RPC interface rejecting arbitrary shell strings                  |
| - Fixed-path binary execution using `exec.Command(path, args...)`             |
| - Input validation: POSIX-compliant usernames, RFC domain sanitization       |
+---------------------------------------+---------------------------------------+
                                        |
+---------------------------------------v---------------------------------------+
| HOST OS KERNEL & ISOLATION BOUNDARIES                                         |
| - Unique system UID / GID per hosting account (UID >= 10000)                  |
| - Home directory permissions: 0750 (Owner: user, Group: cpnix-web)            |
| - Separate PHP-FPM pool per customer, running as customer UID:GID             |
| - cgroups v2 resource capping (CPU, RAM, swap, IO)                            |
| - Filesystem project / user quotas (ext4 / XFS)                               |
| - MariaDB privilege grants strictly restricted to `dbname`.* for user@localhost|
+-------------------------------------------------------------------------------+
```

---

## 3. Communication Security: Control Plane to Node Agent

The Control Plane communicates with remote or local nodes over a dedicated, hardened HTTPS endpoint (default port: `9443`).

### 3.1 Mutual TLS (mTLS) & Token Signing
1. **Enrollment**: During server registration, an enrollment keypair and Certificate Signing Request (CSR) are generated. The Control Plane CA signs the node agent certificate.
2. **Payload Signature**: Every request body is hashed and signed using an HMAC-SHA256 signature passed in the `X-CPNix-Signature` header:
   ```
   Signature = HMAC_SHA256(SecretKey, Method + "\n" + RequestURI + "\n" + Timestamp + "\n" + Nonce + "\n" + RequestBody)
   ```
3. **Replay Defense**: Requests with a timestamp older than 60 seconds or with an already seen nonce are rejected immediately with HTTP 401.

---

## 4. Linux Account Isolation

### 4.1 System Accounts
- Customer usernames are validated against the strict pattern: `^[a-z][a-z0-9_]{2,15}$`.
- Reserved system names (`root`, `bin`, `daemon`, `sys`, `adm`, `www-data`, `nginx`, `apache`, `mysql`, `cpnix`) are prohibited.
- Home directory structure:
  ```
  /home/{username}/
  ├── public_html/          (Mode 0755, owned by {username}:{username})
  ├── logs/                 (Mode 0750, owned by {username}:{username})
  ├── tmp/                  (Mode 0700, owned by {username}:{username})
  ├── mail/                 (Mode 0700, owned by {username}:{username})
  └── .ssl/                 (Mode 0700, owned by {username}:{username})
  ```
- Top-level `/home/{username}` mode is set to `0750` with group `cpnix-web` (or `www-data`), permitting the web server to traverse into `public_html/` without granting read or browse access to other hosting users.

### 4.2 PHP-FPM Pool Isolation
- No global shared PHP-FPM pool.
- Each account receives an isolated pool file `/etc/php/{version}/fpm/pool.d/{username}.conf`.
- Pool executes as:
  ```ini
  [account_{username}]
  user = {username}
  group = {username}
  listen = /run/php/php-fpm-{username}.sock
  listen.owner = {username}
  listen.group = cpnix-web
  listen.mode = 0660
  pm = ondemand
  pm.max_children = 10
  pm.process_idle_timeout = 60s
  php_admin_value[open_basedir] = /home/{username}:/tmp:/usr/share/php
  php_admin_value[upload_tmp_dir] = /home/{username}/tmp
  php_admin_value[session.save_path] = /home/{username}/tmp
  php_admin_value[disable_functions] = exec,passthru,shell_exec,system,proc_open,popen,curl_multi_exec,parse_ini_file,show_source
  ```

---

## 5. Web Application Security

### 5.1 Authentication & Session Integrity
- Password hashing: Argon2id (memory: 65536 KiB, time: 4 iterations, threads: 1) or Bcrypt with cost factor 12.
- Session tokens: 64-byte cryptographically secure random tokens rotated on privilege escalation, login, and password changes.
- Multi-Factor Authentication: Time-based One-Time Passwords (TOTP - RFC 6238) with encrypted secret storage and single-use emergency backup recovery codes.
- Rate limiting: IP-based and username-based progressive throttling on authentication endpoints.

### 5.2 Access Control & IDOR Prevention
- Laravel Policy classes enforce tenant boundaries for every domain, database, mailbox, and file access.
- Cross-tenant requests (e.g., Customer A modifying Domain owned by Customer B, or Reseller A accessing accounts belonging to Reseller B) are blocked with HTTP 403 and logged as security audit events.

### 5.3 Safe Filesystem Operations
The customer File Manager enforces:
- Canonical root path locking: Realpath of all requested paths must strictly begin with `/home/{username}/`.
- Prevention of symlink traversal: Symlinks resolving outside the user's home directory are rejected.
- Upload inspection: Uploaded files are subject to MIME verification, extension validation, and strict file size limits configured per package.

