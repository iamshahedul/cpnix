# CPNix Dependency License Inventory & Third-Party Notices

## 1. Compliance Statement

CPNix is distributed as open-source software under the Apache License 2.0. All bundled dependencies, libraries, and external infrastructure integrations have been audited to ensure compliance with commercial and self-hosted redistribution requirements. CPNix contains zero proprietary code or copyrighted assets from cPanel, WHM, Plesk, DirectAdmin, or any other commercial control panel.

---

## 2. Infrastructure & System Dependencies

| Component | Upstream Project | License | Commercial Use Permitted? | Copyleft / Obligations |
| :--- | :--- | :--- | :--- | :--- |
| **Linux Kernel** | Linux Foundation | GPL v2 | Yes (Separate runtime boundary) | Kernel modifications not required. |
| **systemd** | systemd project | LGPL v2.1+ | Yes | Interfaced via standard D-Bus / CLI. |
| **Nginx** | F5 / Nginx Org | 2-clause BSD-like | Yes | Permissive license with attribution notice. |
| **Apache HTTP Server**| Apache Software Foundation | Apache 2.0 | Yes | Standard Apache 2.0 terms. |
| **PHP Runtime** | The PHP Group | PHP License v3.01 | Yes | Permissive open-source license. |
| **MariaDB Server** | MariaDB Foundation | GPL v2 | Yes (Interfaced via PDO client) | Interfaced over network client protocol. |
| **Redis** | Redis Ltd / Linux Foundation (Valkey) | BSD 3-Clause / BSD 3-Clause | Yes | Permissive network caching layer. |
| **PowerDNS** | PowerDNS.COM BV | GPL v2 | Yes (Interfaced via MySQL schema) | Interfaced via database backend. |
| **Postfix** | Wietse Venema | IBM Public License 1.0 / Eclipse Public License 2.0 | Yes | Interfaced via system configuration. |
| **Dovecot** | Dovecot Oy / Open-Xchange | MIT / LGPL 2.1 | Yes | Permissive / LGPL runtime. |
| **OpenSSL** | OpenSSL Project | Apache 2.0 | Yes | Standard Apache 2.0 terms. |

---

## 3. Application & Software Libraries

| Library | Ecosystem | License | Purpose |
| :--- | :--- | :--- | :--- |
| **Laravel Framework** | PHP / Composer | MIT License | Control Plane web framework & ORM. |
| **Tailwind CSS** | Node / NPM | MIT License | Utility-first styling framework. |
| **Heroicons / Tabler Icons**| Frontend Assets | MIT License | Original, permissive open-source vector icon set. |
| **Go Standard Library** | Go Runtime | BSD 3-Clause | Native Node Agent daemon runtime. |
| **crypto/tls** | Go Standard Library | BSD 3-Clause | Mutual TLS client/server enforcement. |

---

## 4. Verification and Attributions

All third-party trademarks (`cPanel`, `WHM`, `Plesk`, `DirectAdmin`, `Ubuntu`, `AlmaLinux`, `Rocky Linux`, `Nginx`, `MariaDB`, `PowerDNS`) are the registered trademarks of their respective owners. CPNix makes no claim of endorsement or affiliation with these entities.

