# CPNix Troubleshooting Guide

## 1. Node Agent Communication Issues

### Problem: Agent reports "unreachable" or "connection refused"
**Diagnosis:**
```bash
systemctl status cpnix-agent
journalctl -u cpnix-agent -n 50 --no-pager
```

**Common Causes & Remediation:**
1. **Firewall Blocking Port 9443**:
   - Ubuntu: `ufw allow 9443/tcp`
   - RHEL/Alma/Rocky: `firewall-cmd --permanent --add-port=9443/tcp && firewall-cmd --reload`
2. **IP Whitelisting**:
   Check `/etc/cpnix/agent.conf` and confirm that the Control Plane server IP address is listed in `allowed_ips` or that the daemon is listening on `0.0.0.0`.
3. **mTLS Certificate Expiration**:
   Verify validity of `/etc/cpnix/certs/agent.crt`:
   ```bash
   openssl x509 -in /etc/cpnix/certs/agent.crt -noout -dates
   ```

### Problem: HTTP 401 Unauthorized "invalid cryptographic HMAC signature"
**Diagnosis:**
1. Check clock drift between the Control Plane and Node Agent:
   ```bash
   timedatectl status
   ```
   Synchronize with NTP via `chrony` or `systemd-timesyncd`. The maximum allowed clock drift is 60 seconds.
2. Verify that the shared HMAC secret in the Control Plane database (`server_credentials` table) matches `/etc/cpnix/agent.conf`.

---

## 2. Web Server & PHP-FPM Errors

### Problem: Hosted site returns 502 Bad Gateway
**Diagnosis:**
1. Check if the account-specific PHP-FPM pool is running:
   ```bash
   ls -la /run/php/php-fpm-cpnix-{username}.sock
   ```
2. Verify pool syntax:
   ```bash
   # Debian / Ubuntu:
   php-fpm8.2 -t
   # RHEL / Alma:
   /opt/remi/php82/root/usr/sbin/php-fpm -t
   ```
3. Check socket permissions: The socket must be owned by `{username}:cpnix-web` with mode `0660`.

### Problem: Nginx reload fails after vhost creation
**Diagnosis:**
Run configuration test manually:
```bash
nginx -t
```
Inspect the newly generated file in `/etc/nginx/sites-available/{domain}.conf` or `/etc/nginx/conf.d/{domain}.conf`. The CPNix web adapter automatically catches syntax errors before reloading, so the running server will remain uninterrupted.

---

## 3. Account Provisioning Failures

### Problem: Account stuck in `REQUIRES_REPAIR`
**Cause:**
A step in the provisioning state machine failed (e.g. disk quota exhaustion, UID conflict, or unreachable database service), and automated compensation could not completely purge allocated resources.

**Remediation:**
1. Inspect the provisioning step logs in the Administrator panel:
   `https://panel.example.com/admin/accounts/{id}`
2. Check underlying host user:
   ```bash
   id {username}
   ls -ld /home/{username}
   ```
3. If necessary, execute manual repair:
   ```bash
   php artisan cpnix:repair-account --account-id={id}
   ```

