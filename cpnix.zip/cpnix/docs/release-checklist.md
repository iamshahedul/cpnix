# CPNix Release & Deployment Checklist

## Pre-Release Verification

- [ ] **Automated Test Suite**:
  - Run `python3 scripts/test-runner.py` and confirm 100% pass rate.
  - Run `cd node-agent && go test -v ./...`.
  - Run PHPUnit / Pest tests: `php artisan test`.
- [ ] **Security Review**:
  - Verify no hardcoded secrets or private keys in Git repository.
  - Verify `.env.example` contains placeholders only.
  - Confirm CSRF protection active on all state-altering web endpoints.
  - Confirm all database queries use PDO parameterized bindings.
  - Check file manager path confinement against symlink traversal attacks.
- [ ] **Multi-Tenant Isolation**:
  - Verify customer cannot access another customer's files, databases, or logs.
  - Verify reseller cannot allocate resources exceeding their parent quota.
  - Test account suspension properly stops PHP pool and locks Linux user.
- [ ] **Operating System Compatibility**:
  - Tested on Ubuntu 22.04 LTS.
  - Tested on Ubuntu 24.04 LTS.
  - Tested on AlmaLinux 9.x.
  - Tested on Rocky Linux 9.x.
  - Tested on Debian 12.
- [ ] **Licensing & Dependencies**:
  - Audit `composer.lock` and `package.json` for copyleft restrictions.
  - Confirm all included code is Apache 2.0 compliant.
  - Verify trademark disclaimers in place.

---

## Production Deployment Steps

1. Tag release in Git: `git tag -a v1.0.0 -m "CPNix Version 1.0.0 Release"`.
2. Generate SHA-256 release checksums for `scripts/install.sh` and precompiled `cpnix-agent` binary.
3. Publish release notes highlighting major features and backward compatibility notes.
4. Execute smoke tests on clean disposable test server using `scripts/install.sh`.

