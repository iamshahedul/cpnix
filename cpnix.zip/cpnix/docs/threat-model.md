# CPNix Threat Model

## 1. System Scope & Assets

CPNix manages critical multi-tenant hosting resources on Linux infrastructure. Assets requiring protection include:
- **System Integrity**: Linux kernel, host root filesystem, system daemons (`systemd`, `sshd`).
- **Customer Confidentiality**: Private keys, database contents, website source code, email messages.
- **Tenant Isolation**: Separation between tenant A and tenant B on a shared physical or virtual node.
- **Administrative Credentials**: Control plane database credentials, node agent private keys, user passwords, API tokens.
- **Operational Availability**: Service uptime (Nginx, PHP-FPM, MariaDB, Postfix, PowerDNS) against denial of service or resource exhaustion.

---

## 2. STRIDE Threat Analysis

| Category | Threat Scenario | Mitigating Control in CPNix |
| :--- | :--- | :--- |
| **Spoofing** | Attacker spoofs node agent to intercept account provisioning secrets. | Mutual TLS with Control-Plane Certificate Authority verification. Node enrollment handshake requires one-time cryptographically secure verification token. |
| **Spoofing** | Malicious actor attempts credential stuffing or brute force against user login. | Progressive rate limiting, Argon2id password hashing, mandatory/optional TOTP 2FA, IP reputation throttling. |
| **Tampering** | Customer modifies Nginx vhost template or injects arbitrary directives into configuration. | Control Plane generates strict, validated configuration files from parameterized templates. Web server adapter runs `nginx -t` validation before reloading. Faulty syntax is rolled back without applying. |
| **Tampering** | Command injection via crafted username, domain name, or database name. | All inputs validated against strict regex allowlists. Node Agent executes commands using fixed binary paths (`exec.Command(path, args...)`) without shell string interpretation (`sh -c`). |
| **Repudiation** | User deletes a website, database, or mailbox and claims system failure. | Immutable, structured audit log (`audit_logs` table) capturing actor ID, IP address, user agent, target entity, timestamp, before/after state diff. |
| **Information Disclosure** | Customer reads another customer's configuration files (e.g. `wp-config.php`). | Strict Linux filesystem permissions (`0750` on `/home/{user}`), separate UID/GID per user, PHP `open_basedir` enforcement, disabled `symlinks_if_owner_matches`. |
| **Information Disclosure** | Secrets leaked in stack traces or log files. | Global exception handler sanitizes sensitive parameters (`password`, `token`, `secret`, `key`, `credential`). Production debug mode disabled. |
| **Denial of Service** | Malicious tenant spawns 1,000 PHP processes or exhausts system RAM/Disk. | Systemd cgroup v2 slices (`cpu.max`, `memory.max`), PHP-FPM `pm.max_children` throttling, Linux XFS/ext4 project quotas, process count `nproc` limits via `pam_limits`. |
| **Elevation of Privilege** | Attacker compromises web PHP-FPM process and attempts root privilege escalation. | Web application runs as unprivileged `cpnix` user. Node Agent runs as separate system daemon with restricted capabilities. Agent API exposes only typed, parameterized domain operations. |

---

## 3. Attack Surface Breakdown

### 3.1 Control Plane Web Interface (Ports 80 / 443 / 8443)
- **Vulnerabilities Considered**: OWASP Top 10 (SQLi, XSS, CSRF, SSRF, Broken Access Control, Insecure Deserialization).
- **Controls**: Laravel Eloquent PDO parameterized queries; Blade automatic escaping; CSRF tokens on all state-altering requests; restrictive CSP headers; strict URL validation preventing private IP SSRF.

### 3.2 Node Agent API (Port 9443)
- **Vulnerabilities Considered**: Remote Code Execution (RCE), Unauthorized Command Dispatch, Replay Attacks.
- **Controls**: Mutual TLS client authentication, HMAC-SHA256 request payload verification, nonces with 60-second sliding expiration windows, no generic shell execution endpoint.

### 3.3 Customer SFTP & File Manager
- **Vulnerabilities Considered**: Path traversal (`../../etc/shadow`), symlink bypass, arbitrary file write.
- **Controls**: Chrooted SFTP environment using OpenSSH `internal-sftp` pointing to `/home/{username}`. Web File Manager enforces `realpath()` containment validation before performing any read, write, rename, or delete operation.

### 3.4 Shared Database Server (MariaDB / MySQL)
- **Vulnerabilities Considered**: Cross-database access, privilege escalation via `GRANT OPTION` or `LOAD DATA INFILE`.
- **Controls**: Customers receive database credentials scoped strictly to their own database (`GRANT ALL ON dbname.* TO user@localhost`). The administrative `root` database account is never shared or exposed to tenants.

