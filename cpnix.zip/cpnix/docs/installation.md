# CPNix Installation & Setup Guide

## 1. System Requirements

### 1.1 Supported Operating Systems
- **Ubuntu Server**: 22.04 LTS (Jammy Jellyfish), 24.04 LTS (Noble Numbat)
- **AlmaLinux / Rocky Linux**: 8.x, 9.x
- **Debian**: 11 (Bullseye), 12 (Bookworm)

### 1.2 Minimum Hardware
- **CPU**: 2 Cores (64-bit x86_64 or aarch64)
- **RAM**: 2 GB (4 GB recommended for production with Redis & MariaDB)
- **Storage**: 20 GB free disk space (SSD/NVMe recommended with XFS or ext4 filesystem supporting quotas)
- **Networking**: Static public IPv4 address, optional IPv6 subnet, configured FQDN (e.g. `panel.yourdomain.com`)

---

## 2. Fast-Track Automated Installation

CPNix provides an idempotent, self-verifying installation script for fresh, clean operating system installations.

```bash
# 1. Elevate to root on target server
sudo -i

# 2. Download and verify CPNix installer
curl -sSL https://raw.githubusercontent.com/cpnix/cpnix/main/scripts/install.sh -o /tmp/cpnix-install.sh
chmod 700 /tmp/cpnix-install.sh

# 3. Run preflight check
/tmp/cpnix-install.sh --preflight

# 4. Execute installation
/tmp/cpnix-install.sh --domain panel.example.com --admin-email admin@example.com
```

---

## 3. Step-by-Step Architecture Deployment

### Step 3.1: Package Repository & Base Dependencies
The installer automatically detects the OS distribution family:
- **Debian/Ubuntu**: Configures Ondřej Surý PHP PPA, official Nginx repository, MariaDB official repo, installs `curl`, `git`, `redis-server`, `ufw`, `openssl`, `pwgen`, `acl`.
- **RHEL/Alma/Rocky**: Enables EPEL and Remi repositories, installs `nginx`, `mariadb-server`, `redis`, `firewalld`, `policycoreutils-python-utils`.

### Step 3.2: PHP Runtime Configuration
CPNix installs modern PHP 8.2 or 8.3 CLI and FPM runtimes along with required extensions:
`php-cli`, `php-fpm`, `php-mysql`, `php-pgsql`, `php-sqlite3`, `php-redis`, `php-bcmath`, `php-mbstring`, `php-xml`, `php-curl`, `php-zip`, `php-intl`, `php-gd`.

### Step 3.3: Control Plane Database Setup
Creates a dedicated MariaDB database and user with least privilege:
```sql
CREATE DATABASE cpnix_control CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER 'cpnix_user'@'localhost' IDENTIFIED BY 'STRONG_GENERATED_PASSWORD';
GRANT ALL PRIVILEGES ON cpnix_control.* TO 'cpnix_user'@'localhost';
FLUSH PRIVILEGES;
```

### Step 3.4: Application Deployment
1. Clones CPNix source into `/var/www/cpnix`.
2. Sets secure ownership: `chown -R cpnix:cpnix /var/www/cpnix`.
3. Sets restrictive permissions: `chmod -R 750 /var/www/cpnix`, `chmod -R 775 /var/www/cpnix/storage /var/www/cpnix/bootstrap/cache`.
4. Copies `.env.example` to `.env` and generates encryption keys (`php artisan key:generate`).
5. Executes database migrations and initial system seeds:
   ```bash
   php artisan migrate --force
   php artisan db:seed --class=InitialSystemSeeder --force
   ```

### Step 3.5: Privileged Node Agent (`cpnix-agent`)
1. Installs pre-compiled binary to `/usr/local/bin/cpnix-agent`.
2. Generates local mutual TLS keypair and configures `/etc/cpnix/agent.conf`.
3. Installs and enables systemd service:
   ```bash
   cp systemd/cpnix-agent.service /etc/systemd/system/
   systemctl daemon-reload
   systemctl enable --now cpnix-agent
   ```
4. Registers local node with the Control Plane via `php artisan cpnix:register-node --local`.

### Step 3.6: Systemd Background Workers & Schedulers
Enables Laravel asynchronous queue workers and task scheduler:
```ini
# /etc/systemd/system/cpnix-worker.service
[Unit]
Description=CPNix Queue Worker
After=network.target redis.target

[Service]
User=cpnix
Group=cpnix
Restart=always
ExecStart=/usr/bin/php /var/www/cpnix/artisan queue:work redis --sleep=3 --tries=3 --max-time=3600

[Install]
WantedBy=multi-user.target
```

```bash
# Crontab entry for system scheduler
* * * * * cpnix /usr/bin/php /var/www/cpnix/artisan schedule:run >> /dev/null 2>&1
```

---

## 4. Post-Installation Verification

1. Verify system services:
   ```bash
   systemctl status nginx
   systemctl status php8.2-fpm
   systemctl status mariadb
   systemctl status redis
   systemctl status cpnix-agent
   systemctl status cpnix-worker
   ```
2. Run self-diagnostics:
   ```bash
   php /var/www/cpnix/artisan cpnix:health-check
   ```
3. Access web control interface via `https://panel.example.com` or `https://SERVER_IP:8443`.

