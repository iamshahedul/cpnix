# CPNix Operating System & Software Compatibility Matrix

## 1. Operating System Compatibility

| Distribution | Release Version | Kernel | Init System | Architecture | Support Status | Notes |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| **Ubuntu Server** | 22.04 LTS (Jammy) | 5.15+ | systemd v249 | x86_64, aarch64 | **Tier 1 (Fully Supported)** | Default reference distribution. Primary CI target. |
| **Ubuntu Server** | 24.04 LTS (Noble) | 6.8+ | systemd v255 | x86_64, aarch64 | **Tier 1 (Fully Supported)** | AppArmor profiles enabled. Modern cgroups v2. |
| **AlmaLinux** | 9.x | 5.14+ | systemd v252 | x86_64, aarch64 | **Tier 1 (Fully Supported)** | SELinux enforcing mode tested. Remi PHP pools. |
| **Rocky Linux** | 9.x | 5.14+ | systemd v252 | x86_64, aarch64 | **Tier 1 (Fully Supported)** | Fully binary compatible with RHEL 9. |
| **AlmaLinux** | 8.x | 4.18+ | systemd v239 | x86_64 | **Tier 2 (Compatible)** | Legacy glibc; works with standard features. |
| **Debian** | 12 (Bookworm) | 6.1+ | systemd v252 | x86_64, aarch64 | **Tier 1 (Fully Supported)** | Clean debian package integration. |
| **Debian** | 11 (Bullseye) | 5.10+ | systemd v247 | x86_64 | **Tier 2 (Compatible)** | Supported until Debian LTS expiration. |

---

## 2. Infrastructure Services Stack

| Component | Minimum Version | Recommended Version | Tested Versions | Distribution Packages |
| :--- | :--- | :--- | :--- | :--- |
| **Control Plane PHP** | 8.2.0 | 8.2 or 8.3 | 8.2.18, 8.3.6 | `php8.2-fpm`, `php8.3-fpm` |
| **Hosted Account PHP**| 7.4.0 (Legacy) | 8.2 / 8.3 | 7.4, 8.0, 8.1, 8.2, 8.3 | Ondřej PPA (Ubuntu) / Remi (RHEL) |
| **Web Server (Primary)**| Nginx 1.22 | Nginx 1.24+ | 1.22.1, 1.24.0, 1.26.0 | `nginx-full` / `nginx` |
| **Web Server (Optional)**| Apache 2.4.52 | Apache 2.4.58+ | 2.4.52, 2.4.58 | `apache2` / `httpd` |
| **Database Server** | MariaDB 10.6 | MariaDB 10.11 LTS | 10.6, 10.11, 11.2 | `mariadb-server` |
| **Authoritative DNS** | PowerDNS 4.7 | PowerDNS 4.8+ | 4.7.4, 4.8.3, BIND 9.18 | `pdns-server`, `pdns-backend-mysql` |
| **MTA (SMTP)** | Postfix 3.6 | Postfix 3.8+ | 3.6.4, 3.8.1 | `postfix` |
| **MDA (IMAP/POP3)** | Dovecot 2.3.16 | Dovecot 2.3.20+ | 2.3.16, 2.3.21 | `dovecot-imapd`, `dovecot-pop3d` |
| **Node Agent Runtime**| Go 1.21 | Go 1.22+ | 1.21.8, 1.22.2 | Static compiled binary |
| **Caching / Queues** | Redis 6.2 | Redis 7.0+ | 6.2.7, 7.0.15, 7.2.4 | `redis-server` |

---

## 3. Storage & Isolation Mechanisms

| Mechanism | Ubuntu 22.04/24.04 | AlmaLinux / Rocky 9 | Fallback Behavior |
| :--- | :--- | :--- | :--- |
| **Filesystem Quotas** | XFS project quotas / ext4 `usrquota` | XFS project quotas (default) | Fallback to periodic `du` calculation if kernel quota disabled |
| **Process / RAM Limits**| cgroups v2 (`systemd-run --slice`) | cgroups v2 | `pam_limits.conf` (`/etc/security/limits.d/`) |
| **SELinux / AppArmor** | AppArmor default profiles | SELinux Enforcing with CPNix policy | Safe permissive warnings logged, never disabled |
| **Firewall** | `ufw` / `nftables` | `firewalld` / `nftables` | Native `nft` rules directly applied |

