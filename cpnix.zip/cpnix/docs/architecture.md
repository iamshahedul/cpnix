# CPNix Architecture Specification

## 1. Executive Summary

CPNix is an independent, production-grade Linux web hosting control panel and multi-server management platform. It is engineered to replace legacy proprietary control panels (e.g., cPanel/WHM, Plesk, DirectAdmin) with a modern, secure, open-source-based infrastructure plane.

CPNix decouples the centralized control plane (Laravel/PHP/MySQL) from privileged server execution via a dedicated, secure Node Agent (`cpnix-agent` in Go). The web application never runs as `root` and never executes arbitrary remote shell strings. All node interactions occur over mutual TLS (mTLS) or cryptographically signed HMAC payloads utilizing strictly allowlisted, typed RPC endpoints.

---

## 2. System Topology

```
+-----------------------------------------------------------------------------------+
|                                 CPNix Control Plane                               |
|                                                                                   |
|  +-------------------+   +--------------------+   +----------------------------+  |
|  |  Administrator UI |   |    Reseller UI     |   |      Customer UI           |  |
|  +---------+---------+   +---------+----------+   +--------------+-------------+  |
|            |                       |                             |                |
|  +---------v-----------------------v-----------------------------v-------------+  |
|  |               Role-Based Access Control & Policy Middleware                |  |
|  +---------------------------------+-------------------------------------------+  |
|                                    |                                              |
|  +---------------------------------v-------------------------------------------+  |
|  |                       Application Service Layer                             |  |
|  |  (ProvisioningOrchestrator, QuotaService, DnsService, DatabaseService, etc.)|  |
|  +---------------------------------+-------------------------------------------+  |
|            |                                              |                       |
|  +---------v----------+                         +---------v--------------------+  |
|  |  PostgreSQL/MariaDB|                         |   Redis Queue (Asynchronous) |  |
|  |  State Management  |                         |   Idempotent Provisioning    |  |
|  +--------------------+                         +---------+--------------------+  |
+-----------------------------------------------------------|-----------------------+
                                                            |
                  Mutual TLS (mTLS) / HMAC-SHA256           |
                  Strict Schema REST / RPC                  |
                                                            v
+-----------------------------------------------------------------------------------+
|                         Managed Infrastructure Node                               |
|                                                                                   |
|  +-----------------------------------------------------------------------------+  |
|  |             cpnix-agent (Go Service running as isolated daemon)              |  |
|  |                                                                             |  |
|  |  [Security Boundary: Request Validator & Allowlist Dispatcher]              |  |
|  +--------+---------------+-----------------+------------------+---------------+  |
|           |               |                 |                  |                  |
|  +--------v-------+ +-----v---------+ +-----v----------+ +-----v----------+       |
|  | OS Adapter     | | Web Adapter   | | PHP-FPM Adapter| | DB Adapter     |  ...  |
|  | (Debian/RHEL)  | | (Nginx/Apache)| | (Multi-pool)   | | (MariaDB/MySQL)|       |
|  +--------+-------+ +-----+---------+ +-----+----------+ +-----+----------+       |
|           |               |                 |                  |                  |
|  +--------v---------------v-----------------v------------------v---------------+  |
|  |                  Native Linux OS Host Services                              |  |
|  |  - systemd / cgroups v2 / pam_limits                                        |  |
|  |  - Isolated system users (UID >= 10000, GID >= 10000)                       |  |
|  |  - Nginx vhost configurations & reload verification                         |  |
|  |  - PHP-FPM isolated Unix sockets per hosting account                        |  |
|  |  - PowerDNS Authoritative / BIND DNS backend                                |  |
|  |  - Postfix (SMTP) + Dovecot (IMAP/POP3) + Maildir storage                   |  |
|  |  - nftables / ufw / firewalld network filtering                             |  |
|  |  - Local / Remote encrypted backups (gzip / zstd / tar)                     |  |
|  +-----------------------------------------------------------------------------+  |
+-----------------------------------------------------------------------------------+
```

---

## 3. Core Architectural Principles

### 3.1 Strict Privilege Separation
1. The CPNix Control Plane runs as standard unprivileged user `cpnix:cpnix` under PHP-FPM or Octane behind Nginx.
2. The Control Plane has zero direct shell access to managed nodes.
3. Node operations are delegated to `cpnix-agent`, which runs as a systemd service.
4. The agent handles OS user creation (`useradd`), filesystem permissions (`chmod`/`chown`), web server reloads (`systemctl reload nginx`), and database grants through bounded, dedicated Go routines without calling dynamic `sh -c`.

### 3.2 Dual-State Reconciliation
- Control plane database records represent **Desired State**.
- Node agent inspections represent **Observed State**.
- A provisioning job is not marked `ACTIVE` until the agent reports positive verification of all underlying resources:
  - Account UID exists and matches allocation.
  - Home directory exists with restrictive permissions (`0750` or `0711`).
  - PHP-FPM pool is created, syntax-tested, and socket is bound.
  - Nginx configuration syntax passes `nginx -t` before reload.
  - Virtual host responds over loopback.

### 3.3 Idempotency and State Machines
All account provisioning and deprovisioning operations use durable state machines. If a network interruption occurs during account creation:
1. Every step records an `OperationID` and status (`PENDING`, `IN_PROGRESS`, `COMPLETED`, `FAILED`).
2. Retried operations detect existing partial state (e.g., home directory already created) and safely converge without destructive overwrites.
3. Compensation routines roll back cleanly upon terminal validation failure.

---

## 4. Multi-Tenant Role Model

| Role | Scope | Permitted Capabilities |
| :--- | :--- | :--- |
| **Super Administrator** | Global | Full platform control: server enrollment, package management, reseller provisioning, systemd services, IP management, global audit logs. |
| **Reseller** | Delegated Tenant Pool | Manage allocated resource pool (disk, bandwidth, accounts). Create/suspend customer accounts within package boundaries. |
| **Customer** | Account-Scoped | Manage domain names, subdomains, DNS records, MariaDB databases/users, mailboxes, SSL certificates, cron jobs, files. Zero access outside own home directory or database instances. |

---

## 5. Web Server & PHP-FPM Integration

- **Primary Web Server**: Nginx (reverse proxy and static server) routing dynamic requests to PHP-FPM.
- **Secondary Web Server Adapter**: Apache 2.4 with `mpm_event` + `mod_proxy_fcgi` (designed via swappable interface `WebServerAdapterInterface`).
- **PHP Isolation**: Each hosting account executes under its own dedicated Linux user and group.
  - Socket path: `/run/php/php-fpm-cpnix-{account_user}.sock`
  - Ownership: `{account_user}:{web_group}` with mode `0660`.
  - Account home: `/home/{account_user}`.
  - Document root: `/home/{account_user}/public_html`.
  - Process limits enforced via systemd user slice and PHP-FPM pool directives (`pm = ondemand`, `pm.max_children`, `rlimit_files`, `rlimit_core`).

---

## 6. Authoritative DNS & Email

- **DNS**: PowerDNS Authoritative Server with MySQL/MariaDB backend or direct Pipe/API integration.
  - Secondary fallback: BIND9 zone file generation with syntax testing via `named-checkzone` prior to reload.
- **Mail Stack**:
  - Outgoing: Postfix with SASL authentication against virtual mailboxes.
  - Incoming: Dovecot IMAP/POP3 with Maildir format `/home/{account_user}/mail/{domain}/{mailbox}`.
  - DKIM/SPF/DMARC: OpenDKIM integration with automated 2048-bit keypair generation upon domain registration.

---

## 7. Storage, Quotas, and Resource Isolation

- Linux filesystem quotas (XFS project quotas or ext4 user quotas) enforced at kernel level.
- Memory and CPU limits configured via cgroups v2 (`cpu.max`, `memory.high`, `memory.max`) through systemd slice template: `cpnix-user@{username}.slice`.
- Inode and storage metrics collected directly from `statvfs` system calls by `cpnix-agent`.

