# CPNix Production Deployment Guide

## 1. Deployment Topologies

CPNix supports two deployment architectures:

### 1.1 Single-Server Architecture (Standalone / Small Deployments)
The Control Plane (Laravel, MariaDB, Redis) and the Node Agent (`cpnix-agent`) reside on the same physical or virtual machine. Ideal for single dedicated servers, entry-level VPS hosting, or isolated corporate servers.

```
+--------------------------------------------------------------+
| Dedicated / VPS Node                                         |
|                                                              |
|  [Nginx Front-End: Port 8443 (CPNix UI) & 80/443 (Websites)]  |
|                                                              |
|  [CPNix Control Plane (Laravel App - Port 9000 PHP-FPM)]     |
|                               ^                              |
|                               | (Loopback mTLS / Port 9443)  |
|                               v                              |
|  [cpnix-agent Go Daemon] ----> [Host Services: Nginx, PHP,   |
|                                DB, Postfix, Dovecot, DNS]    |
+--------------------------------------------------------------+
```

### 1.2 Multi-Node Cluster Architecture (Hosting Providers / Scale)
The Central Control Plane resides on an isolated management cluster. Individual worker nodes run `cpnix-agent` and host customer workloads.

```
                     +---------------------------------------+
                     |    Central Control Plane Server       |
                     |  - High Availability MariaDB Cluster  |
                     |  - Centralized Redis Queue            |
                     |  - CPNix Administrator & Reseller UI  |
                     +-------------------+-------------------+
                                         |
               +-------------------------+-------------------------+
               | mTLS / REST                                       | mTLS / REST
               v                                                   v
+-------------------------------+                 +-------------------------------+
| Web / Shared Node 01          |                 | Web / Shared Node 02          |
| - cpnix-agent                 |                 | - cpnix-agent                 |
| - Nginx + PHP 7.4-8.3 Pools   |                 | - Nginx + PHP 7.4-8.3 Pools   |
| - Local MariaDB / PowerDNS    |                 | - Local MariaDB / PowerDNS    |
+-------------------------------+                 +-------------------------------+
```

---

## 2. Production Hardening Checklist

1. **TLS / SSL Termination**:
   - Issue automated Let's Encrypt certificates or install valid commercial certificates for the panel domain.
   - Enforce TLS 1.2 and TLS 1.3 only; disable weak ciphers.
   - Enforce HTTP Strict Transport Security (HSTS) with `max-age=31536000; includeSubDomains`.

2. **Firewall Rules (nftables / ufw)**:
   - Allow ports 80, 443 (HTTP/HTTPS for hosted sites).
   - Allow port 8443 (CPNix Control Plane, restrict to admin IP if multi-node).
   - Allow port 9443 (`cpnix-agent` API, strictly restricted to Control Plane IPs).
   - Allow ports 25, 465, 587 (SMTP/SMTPS/Submission) and 993, 995 (IMAPS/POP3S).
   - Allow port 53 (TCP/UDP for Authoritative DNS).
   - Rate limit SSH (port 22 or custom port).

3. **PHP Security Settings for Control Plane**:
   ```ini
   expose_php = Off
   display_errors = Off
   log_errors = On
   error_reporting = E_ALL & ~E_DEPRECATED & ~E_STRICT
   memory_limit = 256M
   max_execution_time = 60
   session.cookie_secure = 1
   session.cookie_httponly = 1
   session.cookie_samesite = Strict
   ```

4. **Database Hardening**:
   - Run `mysql_secure_installation`.
   - Disable remote root login (`skip-name-resolve`, bind to `127.0.0.1` unless clustered).
   - Restrict customer database privileges: prohibit `FILE`, `SUPER`, `PROCESS`, `SHUTDOWN`, `GRANT OPTION`.

---

## 3. Zero-Downtime Application Releases

For Control Plane updates:
1. Maintain release symlinks:
   ```
   /var/www/cpnix/
   ├── current -> releases/20261108_v1.0.0
   ├── releases/
   │   ├── 20261108_v1.0.0/
   │   └── 20261101_v0.9.8/
   └── shared/
       ├── .env
       └── storage/
   ```
2. Execute migrations: `php artisan migrate --force`.
3. Clear and precompile cache: `php artisan config:cache && php artisan route:cache && php artisan view:cache`.
4. Gracefully restart queue workers: `php artisan queue:restart`.
5. Atomic symlink switch: `ln -sfn releases/NEW_RELEASE /var/www/cpnix/current`.

