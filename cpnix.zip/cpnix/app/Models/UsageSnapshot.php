<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class UsageSnapshot extends Model
{
    use HasFactory;

    public $timestamps = false;

    protected $fillable = [
        'hosting_account_id',
        'disk_used_bytes',
        'inode_count',
        'bandwidth_bytes',
        'database_size_bytes',
        'email_count',
        'recorded_at',
    ];

    protected $casts = [
        'disk_used_bytes' => 'integer',
        'inode_count' => 'integer',
        'bandwidth_bytes' => 'integer',
        'database_size_bytes' => 'integer',
        'email_count' => 'integer',
        'recorded_at' => 'datetime',
    ];

    public function hostingAccount()
    {
        return $this->belongsTo(HostingAccount::class);
    }
}

