<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Backup extends Model
{
    use HasFactory;

    protected $fillable = [
        'hosting_account_id',
        'filename',
        'storage_path',
        'size_bytes',
        'checksum_sha256',
        'status',
        'type',
        'manifest',
        'error_details',
        'completed_at',
        'verified_at',
    ];

    protected $casts = [
        'size_bytes' => 'integer',
        'manifest' => 'array',
        'completed_at' => 'datetime',
        'verified_at' => 'datetime',
    ];

    public function hostingAccount()
    {
        return $this->belongsTo(HostingAccount::class);
    }

    public function isVerified(): bool
    {
        return $this->status === 'VERIFIED' && !empty($this->checksum_sha256);
    }
}

