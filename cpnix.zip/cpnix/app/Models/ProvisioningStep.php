<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ProvisioningStep extends Model
{
    use HasFactory;

    protected $fillable = [
        'provisioning_job_id',
        'step_number',
        'name',
        'status',
        'input_data',
        'output_data',
        'error_message',
        'started_at',
        'completed_at',
    ];

    protected $casts = [
        'step_number' => 'integer',
        'started_at' => 'datetime',
        'completed_at' => 'datetime',
    ];

    public function job()
    {
        return $this->belongsTo(ProvisioningJob::class, 'provisioning_job_id');
    }
}

