<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class DatabaseGrant extends Model
{
    use HasFactory;

    protected $fillable = [
        'database_id',
        'database_user_id',
        'privileges',
    ];

    protected $casts = [
        'privileges' => 'array',
    ];

    public function database()
    {
        return $this->belongsTo(Database::class);
    }

    public function databaseUser()
    {
        return $this->belongsTo(DatabaseUser::class);
    }
}

