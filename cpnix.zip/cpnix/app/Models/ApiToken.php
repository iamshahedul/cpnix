<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;

class ApiToken extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id',
        'name',
        'token_hash',
        'abilities',
        'last_used_at',
        'expires_at',
    ];

    protected $casts = [
        'abilities' => 'array',
        'last_used_at' => 'datetime',
        'expires_at' => 'datetime',
    ];

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public static function generate(User $user, string $name, array $abilities = ['*'], ?int $daysValid = 90): array
    {
        $plainTextToken = 'cpnix_' . Str::random(40);
        $tokenHash = hash('sha256', $plainTextToken);

        $token = static::create([
            'user_id' => $user->id,
            'name' => $name,
            'token_hash' => $tokenHash,
            'abilities' => $abilities,
            'expires_at' => $daysValid ? now()->addDays($daysValid) : null,
        ]);

        return [
            'token_model' => $token,
            'plain_text_token' => $plainTextToken,
        ];
    }

    public function can(string $ability): bool
    {
        if (in_array('*', $this->abilities ?? [])) {
            return true;
        }
        return in_array($ability, $this->abilities ?? []);
    }
}

