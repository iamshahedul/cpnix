<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SftpAccount extends Model
{
    use HasFactory;

    protected $fillable = [
        'hosting_account_id',
        'username',
        'home_directory',
        'public_key',
        'password_auth_allowed',
        'is_active',
    ];

    protected $casts = [
        'password_auth_allowed' => 'boolean',
        'is_active' => 'boolean',
    ];

    public function hostingAccount()
    {
        return $this->belongsTo(HostingAccount::class);
    }
}

