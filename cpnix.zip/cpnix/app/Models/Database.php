<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Database extends Model
{
    use HasFactory;

    protected $fillable = [
        'hosting_account_id',
        'name',
        'charset',
        'collation',
        'size_bytes',
    ];

    protected $casts = [
        'size_bytes' => 'integer',
    ];

    public function hostingAccount()
    {
        return $this->belongsTo(HostingAccount::class);
    }

    public function grants()
    {
        return $this->hasMany(DatabaseGrant::class);
    }

    public function users()
    {
        return $this->belongsToMany(DatabaseUser::class, 'database_grants');
    }
}

