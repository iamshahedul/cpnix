<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Reseller extends Model
{
    use HasFactory, SoftDeletes;

    protected $fillable = [
        'user_id',
        'company_name',
        'disk_quota_mb',
        'bandwidth_quota_mb',
        'max_accounts',
        'permitted_servers',
        'branding',
        'is_suspended',
        'suspension_reason',
    ];

    protected $casts = [
        'disk_quota_mb' => 'integer',
        'bandwidth_quota_mb' => 'integer',
        'max_accounts' => 'integer',
        'permitted_servers' => 'array',
        'branding' => 'array',
        'is_suspended' => 'boolean',
    ];

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function packages()
    {
        return $this->hasMany(HostingPackage::class);
    }

    public function hostingAccounts()
    {
        return $this->hasMany(HostingAccount::class);
    }

    public function totalAllocatedDiskMb(): int
    {
        return (int) $this->hostingAccounts()->sum('disk_used_mb');
    }

    public function hasRemainingAccountCapacity(): bool
    {
        return $this->hostingAccounts()->count() < $this->max_accounts;
    }
}

