<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class HostingPackage extends Model
{
    use HasFactory, SoftDeletes;

    protected $fillable = [
        'reseller_id',
        'name',
        'slug',
        'description',
        'disk_quota_mb',
        'bandwidth_quota_mb',
        'max_domains',
        'max_subdomains',
        'max_databases',
        'max_email_accounts',
        'max_ftp_accounts',
        'max_cron_jobs',
        'allowed_php_versions',
        'allow_ssh_access',
        'allow_custom_dns',
        'allow_ssl_management',
        'backup_retention_days',
        'is_active',
    ];

    protected $casts = [
        'disk_quota_mb' => 'integer',
        'bandwidth_quota_mb' => 'integer',
        'max_domains' => 'integer',
        'max_subdomains' => 'integer',
        'max_databases' => 'integer',
        'max_email_accounts' => 'integer',
        'max_ftp_accounts' => 'integer',
        'max_cron_jobs' => 'integer',
        'allowed_php_versions' => 'array',
        'allow_ssh_access' => 'boolean',
        'allow_custom_dns' => 'boolean',
        'allow_ssl_management' => 'boolean',
        'backup_retention_days' => 'integer',
        'is_active' => 'boolean',
    ];

    public function reseller()
    {
        return $this->belongsTo(Reseller::class);
    }

    public function hostingAccounts()
    {
        return $this->hasMany(HostingAccount::class, 'package_id');
    }
}

