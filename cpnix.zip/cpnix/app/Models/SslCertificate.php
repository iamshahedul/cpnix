<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SslCertificate extends Model
{
    use HasFactory;

    protected $fillable = [
        'hosting_account_id',
        'domain',
        'provider',
        'certificate',
        'private_key',
        'ca_bundle',
        'issued_at',
        'expires_at',
        'auto_renew',
        'status',
    ];

    protected $hidden = [
        'private_key',
    ];

    protected $casts = [
        'private_key' => 'encrypted',
        'issued_at' => 'datetime',
        'expires_at' => 'datetime',
        'auto_renew' => 'boolean',
    ];

    public function hostingAccount()
    {
        return $this->belongsTo(HostingAccount::class);
    }

    public function isExpiringSoon(int $daysThreshold = 30): bool
    {
        return $this->expires_at && $this->expires_at->diffInDays(now()) <= $daysThreshold;
    }
}

