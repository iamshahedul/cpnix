<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class AccountDomain extends Model
{
    use HasFactory, SoftDeletes;

    protected $fillable = [
        'hosting_account_id',
        'domain',
        'document_root',
        'is_primary',
        'is_subdomain',
        'php_version',
        'ssl_enabled',
        'force_https',
    ];

    protected $casts = [
        'is_primary' => 'boolean',
        'is_subdomain' => 'boolean',
        'ssl_enabled' => 'boolean',
        'force_https' => 'boolean',
    ];

    public function hostingAccount()
    {
        return $this->belongsTo(HostingAccount::class);
    }
}

