<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ProvisioningJob extends Model
{
    use HasFactory;

    protected $fillable = [
        'uuid',
        'hosting_account_id',
        'action',
        'status',
        'total_steps',
        'completed_steps',
        'error_message',
        'payload',
        'started_at',
        'completed_at',
    ];

    protected $casts = [
        'payload' => 'array',
        'total_steps' => 'integer',
        'completed_steps' => 'integer',
        'started_at' => 'datetime',
        'completed_at' => 'datetime',
    ];

    public function hostingAccount()
    {
        return $this->belongsTo(HostingAccount::class);
    }

    public function steps()
    {
        return $this->hasMany(ProvisioningStep::class)->orderBy('step_number');
    }

    public function progressPercentage(): int
    {
        if ($this->total_steps === 0) {
            return 0;
        }
        return (int) round(($this->completed_steps / $this->total_steps) * 100);
    }
}

