<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class DatabaseUser extends Model
{
    use HasFactory;

    protected $fillable = [
        'hosting_account_id',
        'username',
        'host',
    ];

    public function hostingAccount()
    {
        return $this->belongsTo(HostingAccount::class);
    }

    public function grants()
    {
        return $this->hasMany(DatabaseGrant::class);
    }

    public function databases()
    {
        return $this->belongsToMany(Database::class, 'database_grants');
    }
}

