<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Server extends Model
{
    use HasFactory, SoftDeletes;

    protected $fillable = [
        'name',
        'hostname',
        'ip_address',
        'ipv6_address',
        'port',
        'status',
        'os_family',
        'os_version',
        'kernel_version',
        'agent_version',
        'max_accounts',
        'capabilities',
        'latest_telemetry',
        'last_heartbeat_at',
        'is_active',
    ];

    protected $casts = [
        'capabilities' => 'array',
        'latest_telemetry' => 'array',
        'last_heartbeat_at' => 'datetime',
        'is_active' => 'boolean',
        'port' => 'integer',
        'max_accounts' => 'integer',
    ];

    public function credential()
    {
        return $this->hasOne(ServerCredential::class);
    }

    public function hostingAccounts()
    {
        return $this->hasMany(HostingAccount::class);
    }

    public function isOnline(): bool
    {
        return $this->status === 'online' && 
               $this->last_heartbeat_at && 
               $this->last_heartbeat_at->diffInMinutes(now()) <= 3;
    }

    public function currentAccountsCount(): int
    {
        return $this->hostingAccounts()->count();
    }

    public function hasCapacity(): bool
    {
        return $this->currentAccountsCount() < $this->max_accounts;
    }
}

