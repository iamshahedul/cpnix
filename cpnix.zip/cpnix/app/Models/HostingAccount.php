<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class HostingAccount extends Model
{
    use HasFactory, SoftDeletes;

    protected $fillable = [
        'user_id',
        'reseller_id',
        'server_id',
        'package_id',
        'username',
        'uid',
        'gid',
        'primary_domain',
        'home_directory',
        'php_version',
        'status',
        'suspension_reason',
        'suspended_at',
        'provisioned_at',
        'disk_used_mb',
        'bandwidth_used_mb',
        'resource_limits',
    ];

    protected $casts = [
        'uid' => 'integer',
        'gid' => 'integer',
        'disk_used_mb' => 'integer',
        'bandwidth_used_mb' => 'integer',
        'resource_limits' => 'array',
        'suspended_at' => 'datetime',
        'provisioned_at' => 'datetime',
    ];

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function reseller()
    {
        return $this->belongsTo(Reseller::class);
    }

    public function server()
    {
        return $this->belongsTo(Server::class);
    }

    public function package()
    {
        return $this->belongsTo(HostingPackage::class, 'package_id');
    }

    public function domains()
    {
        return $this->hasMany(AccountDomain::class);
    }

    public function dnsZones()
    {
        return $this->hasMany(DnsZone::class);
    }

    public function databases()
    {
        return $this->hasMany(Database::class);
    }

    public function databaseUsers()
    {
        return $this->hasMany(DatabaseUser::class);
    }

    public function emailAccounts()
    {
        return $this->hasMany(EmailAccount::class);
    }

    public function cronJobs()
    {
        return $this->hasMany(CronJob::class);
    }

    public function sslCertificates()
    {
        return $this->hasMany(SslCertificate::class);
    }

    public function backups()
    {
        return $this->hasMany(Backup::class);
    }

    public function provisioningJobs()
    {
        return $this->hasMany(ProvisioningJob::class);
    }

    public function usageSnapshots()
    {
        return $this->hasMany(UsageSnapshot::class);
    }

    public function isActive(): bool
    {
        return $this->status === 'ACTIVE';
    }

    public function isSuspended(): bool
    {
        return $this->status === 'SUSPENDED';
    }
}

