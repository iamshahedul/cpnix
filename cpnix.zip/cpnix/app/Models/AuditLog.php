<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AuditLog extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id',
        'actor_type',
        'actor_name',
        'action',
        'entity_type',
        'entity_id',
        'ip_address',
        'user_agent',
        'old_values',
        'new_values',
    ];

    protected $casts = [
        'old_values' => 'array',
        'new_values' => 'array',
        'entity_id' => 'integer',
    ];

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public static function record(
        string $action,
        ?string $entityType = null,
        ?int $entityId = null,
        ?array $newValues = null,
        ?array $oldValues = null,
        ?User $actor = null
    ): self {
        $user = $actor ?? auth()->user();

        return static::create([
            'user_id' => $user?->id,
            'actor_type' => $user ? 'user' : 'system',
            'actor_name' => $user ? $user->email : 'System',
            'action' => $action,
            'entity_type' => $entityType,
            'entity_id' => $entityId,
            'ip_address' => request()?->ip() ?? '127.0.0.1',
            'user_agent' => request()?->userAgent() ?? 'CLI/System',
            'old_values' => $oldValues,
            'new_values' => $newValues,
        ]);
    }
}

