<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CronJob extends Model
{
    use HasFactory;

    protected $fillable = [
        'hosting_account_id',
        'minute',
        'hour',
        'day_of_month',
        'month',
        'day_of_week',
        'command',
        'description',
        'is_active',
        'last_run_at',
        'last_exit_code',
    ];

    protected $casts = [
        'is_active' => 'boolean',
        'last_run_at' => 'datetime',
        'last_exit_code' => 'integer',
    ];

    public function hostingAccount()
    {
        return $this->belongsTo(HostingAccount::class);
    }

    public function getExpressionAttribute(): string
    {
        return sprintf(
            '%s %s %s %s %s',
            $this->minute,
            $this->hour,
            $this->day_of_month,
            $this->month,
            $this->day_of_week
        );
    }
}

