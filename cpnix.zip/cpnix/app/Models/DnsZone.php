<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class DnsZone extends Model
{
    use HasFactory;

    protected $fillable = [
        'hosting_account_id',
        'name',
        'primary_ns',
        'admin_email',
        'serial',
        'refresh',
        'retry',
        'expire',
        'ttl',
        'is_active',
    ];

    protected $casts = [
        'serial' => 'integer',
        'refresh' => 'integer',
        'retry' => 'integer',
        'expire' => 'integer',
        'ttl' => 'integer',
        'is_active' => 'boolean',
    ];

    public function hostingAccount()
    {
        return $this->belongsTo(HostingAccount::class);
    }

    public function records()
    {
        return $this->hasMany(DnsRecord::class);
    }

    public function incrementSerial(): void
    {
        $today = date('Ymd');
        $currentPrefix = substr((string)$this->serial, 0, 8);
        if ($currentPrefix === $today) {
            $this->serial++;
        } else {
            $this->serial = (int)($today . '01');
        }
        $this->save();
    }
}

