<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ServerCredential extends Model
{
    protected $fillable = [
        'server_id',
        'auth_token',
        'client_certificate',
        'client_private_key',
        'ca_certificate',
        'expires_at',
    ];

    protected $hidden = [
        'auth_token',
        'client_private_key',
    ];

    protected $casts = [
        'auth_token' => 'encrypted',
        'client_private_key' => 'encrypted',
        'expires_at' => 'datetime',
    ];

    public function server()
    {
        return $this->belongsTo(Server::class);
    }
}

