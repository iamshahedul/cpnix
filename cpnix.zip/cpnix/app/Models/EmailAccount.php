<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class EmailAccount extends Model
{
    use HasFactory;

    protected $fillable = [
        'hosting_account_id',
        'email',
        'local_part',
        'domain',
        'password_hash',
        'quota_mb',
        'used_mb',
        'is_active',
    ];

    protected $hidden = [
        'password_hash',
    ];

    protected $casts = [
        'quota_mb' => 'integer',
        'used_mb' => 'integer',
        'is_active' => 'boolean',
    ];

    public function hostingAccount()
    {
        return $this->belongsTo(HostingAccount::class);
    }
}

