<?php

namespace App\Policies;

use App\Models\HostingPackage;
use App\Models\User;

class HostingPackagePolicy
{
    public function viewAny(User $user): bool
    {
        return $user->isAdmin() || $user->isReseller();
    }

    public function view(User $user, HostingPackage $package): bool
    {
        if ($user->isAdmin()) {
            return true;
        }

        if ($user->isReseller()) {
            return $package->reseller_id === null || ($package->reseller && $package->reseller->user_id === $user->id);
        }

        return false;
    }

    public function create(User $user): bool
    {
        return $user->isAdmin() || $user->isReseller();
    }

    public function update(User $user, HostingPackage $package): bool
    {
        if ($user->isAdmin()) {
            return true;
        }

        if ($user->isReseller()) {
            return $package->reseller && $package->reseller->user_id === $user->id;
        }

        return false;
    }

    public function delete(User $user, HostingPackage $package): bool
    {
        return $this->update($user, $package);
    }
}

