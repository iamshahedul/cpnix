<?php

namespace App\Policies;

use App\Models\HostingAccount;
use App\Models\User;

class HostingAccountPolicy
{
    public function viewAny(User $user): bool
    {
        return $user->isAdmin() || $user->isReseller();
    }

    public function view(User $user, HostingAccount $account): bool
    {
        if ($user->isAdmin()) {
            return true;
        }

        if ($user->isReseller()) {
            return $account->reseller && $account->reseller->user_id === $user->id;
        }

        return $account->user_id === $user->id;
    }

    public function create(User $user): bool
    {
        return $user->isAdmin() || $user->isReseller();
    }

    public function update(User $user, HostingAccount $account): bool
    {
        if ($user->isAdmin()) {
            return true;
        }

        if ($user->isReseller()) {
            return $account->reseller && $account->reseller->user_id === $user->id;
        }

        return $account->user_id === $user->id;
    }

    public function delete(User $user, HostingAccount $account): bool
    {
        if ($user->isAdmin()) {
            return true;
        }

        if ($user->isReseller()) {
            return $account->reseller && $account->reseller->user_id === $user->id;
        }

        return false;
    }

    public function suspend(User $user, HostingAccount $account): bool
    {
        return $this->delete($user, $account);
    }
}

