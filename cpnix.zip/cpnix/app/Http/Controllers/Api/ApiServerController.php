<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Server;
use App\Services\Agent\NodeAgentClient;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class ApiServerController extends Controller
{
    public function index(): JsonResponse
    {
        $servers = Server::withCount('hostingAccounts')->get();

        return response()->json([
            'success' => true,
            'data' => $servers,
        ]);
    }

    public function health(Server $server): JsonResponse
    {
        $agent = new NodeAgentClient($server);
        $metrics = $agent->getMetrics();

        return response()->json([
            'success' => $metrics['success'],
            'data' => $metrics['data'] ?? null,
            'error' => $metrics['error'] ?? null,
        ]);
    }
}

