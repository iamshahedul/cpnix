<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\AuditLog;
use App\Models\HostingAccount;
use App\Models\HostingPackage;
use App\Models\Server;
use App\Models\User;
use App\Services\Provisioning\AccountProvisioner;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;

class ApiAccountController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $accounts = HostingAccount::with(['server:id,name,ip_address', 'package:id,name'])
            ->paginate($request->integer('per_page', 25));

        return response()->json([
            'success' => true,
            'data' => $accounts,
            'meta' => [
                'timestamp' => now()->toIso8601String(),
            ],
        ]);
    }

    public function store(Request $request, AccountProvisioner $provisioner): JsonResponse
    {
        $validated = $request->validate([
            'domain' => ['required', 'string', 'regex:/^([a-z0-9]+(-[a-z0-9]+)*\.)+[a-z]{2,}$/i', 'unique:hosting_accounts,primary_domain'],
            'username' => ['required', 'string', 'alpha_num', 'min:3', 'max:16', 'unique:hosting_accounts,username'],
            'password' => ['required', 'string', 'min:8'],
            'owner_email' => ['required', 'email'],
            'server_id' => ['required', 'exists:servers,id'],
            'package_id' => ['required', 'exists:hosting_packages,id'],
            'php_version' => ['nullable', 'in:7.4,8.0,8.1,8.2,8.3'],
        ]);

        $server = Server::findOrFail($validated['server_id']);
        if (!$server->hasCapacity()) {
            return response()->json([
                'success' => false,
                'error' => [
                    'code' => 'SERVER_CAPACITY_EXCEEDED',
                    'message' => 'The selected server has reached maximum capacity.',
                ],
            ], 422);
        }

        $account = DB::transaction(function () use ($validated, $provisioner) {
            $user = User::firstOrCreate(
                ['email' => $validated['owner_email']],
                [
                    'name' => $validated['username'],
                    'password' => Hash::make($validated['password']),
                    'role' => 'customer',
                ]
            );

            $maxUid = HostingAccount::max('uid') ?? 10000;
            $nextUid = max(10001, $maxUid + 1);

            $account = HostingAccount::create([
                'user_id' => $user->id,
                'server_id' => $validated['server_id'],
                'package_id' => $validated['package_id'],
                'username' => strtolower($validated['username']),
                'uid' => $nextUid,
                'gid' => $nextUid,
                'primary_domain' => strtolower($validated['domain']),
                'home_directory' => '/home/' . strtolower($validated['username']),
                'php_version' => $validated['php_version'] ?? '8.2',
                'status' => 'PENDING',
            ]);

            $account->domains()->create([
                'domain' => strtolower($validated['domain']),
                'document_root' => '/home/' . strtolower($validated['username']) . '/public_html',
                'is_primary' => true,
                'is_subdomain' => false,
                'php_version' => $validated['php_version'] ?? '8.2',
            ]);

            AuditLog::record('api.account_created', 'HostingAccount', $account->id);

            $provisioner->provision($account);
            return $account;
        });

        return response()->json([
            'success' => true,
            'data' => [
                'id' => $account->id,
                'username' => $account->username,
                'domain' => $account->primary_domain,
                'status' => $account->status,
            ],
            'message' => 'Account provisioning initiated.',
        ], 202);
    }

    public function show(HostingAccount $account): JsonResponse
    {
        $account->load(['server', 'package', 'domains', 'databases', 'emailAccounts']);

        return response()->json([
            'success' => true,
            'data' => $account,
        ]);
    }
}

