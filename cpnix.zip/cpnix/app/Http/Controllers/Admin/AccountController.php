<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\AuditLog;
use App\Models\HostingAccount;
use App\Models\HostingPackage;
use App\Models\Reseller;
use App\Models\Server;
use App\Models\User;
use App\Services\Provisioning\AccountProvisioner;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;

class AccountController extends Controller
{
    public function index(Request $request)
    {
        $query = HostingAccount::with(['user', 'server', 'package', 'reseller.user']);

        if ($request->filled('search')) {
            $search = $request->input('search');
            $query->where(function ($q) use ($search) {
                $q->where('username', 'like', "%{$search}%")
                  ->orWhere('primary_domain', 'like', "%{$search}%");
            });
        }

        if ($request->filled('status')) {
            $query->where('status', $request->input('status'));
        }

        $accounts = $query->latest()->paginate(25);
        return view('admin.accounts.index', compact('accounts'));
    }

    public function create()
    {
        $servers = Server::where('is_active', true)->get();
        $packages = HostingPackage::where('is_active', true)->whereNull('reseller_id')->get();
        $resellers = Reseller::with('user')->get();

        return view('admin.accounts.create', compact('servers', 'packages', 'resellers'));
    }

    public function store(Request $request, AccountProvisioner $provisioner)
    {
        $validated = $request->validate([
            'domain' => ['required', 'string', 'regex:/^([a-z0-9]+(-[a-z0-9]+)*\.)+[a-z]{2,}$/i', 'unique:hosting_accounts,primary_domain'],
            'username' => ['required', 'string', 'alpha_num', 'min:3', 'max:16', 'unique:hosting_accounts,username'],
            'password' => ['required', 'string', 'min:8'],
            'owner_email' => ['required', 'email'],
            'server_id' => ['required', 'exists:servers,id'],
            'package_id' => ['required', 'exists:hosting_packages,id'],
            'reseller_id' => ['nullable', 'exists:resellers,id'],
            'php_version' => ['required', 'in:7.4,8.0,8.1,8.2,8.3'],
        ]);

        $server = Server::findOrFail($validated['server_id']);
        if (!$server->hasCapacity()) {
            return back()->withErrors(['server_id' => 'Target server has reached maximum account capacity.'])->withInput();
        }

        return DB::transaction(function () use ($validated, $provisioner) {
            // 1. Create or resolve user
            $user = User::firstOrCreate(
                ['email' => $validated['owner_email']],
                [
                    'name' => $validated['username'],
                    'password' => Hash::make($validated['password']),
                    'role' => 'customer',
                ]
            );

            // 2. Allocate next UID in safe 10000+ range
            $maxUid = HostingAccount::max('uid') ?? 10000;
            $nextUid = max(10001, $maxUid + 1);

            // 3. Create HostingAccount record
            $account = HostingAccount::create([
                'user_id' => $user->id,
                'reseller_id' => $validated['reseller_id'] ?? null,
                'server_id' => $validated['server_id'],
                'package_id' => $validated['package_id'],
                'username' => strtolower($validated['username']),
                'uid' => $nextUid,
                'gid' => $nextUid,
                'primary_domain' => strtolower($validated['domain']),
                'home_directory' => '/home/' . strtolower($validated['username']),
                'php_version' => $validated['php_version'],
                'status' => 'PENDING',
            ]);

            // 4. Create primary AccountDomain record
            $account->domains()->create([
                'domain' => strtolower($validated['domain']),
                'document_root' => '/home/' . strtolower($validated['username']) . '/public_html',
                'is_primary' => true,
                'is_subdomain' => false,
                'php_version' => $validated['php_version'],
            ]);

            AuditLog::record('account.created', 'HostingAccount', $account->id, [
                'username' => $account->username,
                'domain' => $account->primary_domain,
            ]);

            // Dispatch provisioning sequence
            $job = $provisioner->provision($account);

            return redirect()->route('admin.accounts.show', $account)
                ->with('status', 'Account provisioning initiated. Job UUID: ' . $job->uuid);
        });
    }

    public function show(HostingAccount $account)
    {
        $account->load(['user', 'server', 'package', 'domains', 'databases', 'emailAccounts', 'provisioningJobs.steps']);
        return view('admin.accounts.show', compact('account'));
    }

    public function suspend(Request $request, HostingAccount $account, AccountProvisioner $provisioner)
    {
        $request->validate(['reason' => ['required', 'string', 'max:255']]);

        $success = $provisioner->suspend($account, $request->input('reason'));
        if ($success) {
            return back()->with('status', 'Account suspended successfully.');
        }

        return back()->withErrors(['suspend' => 'Failed to suspend account on node.']);
    }

    public function unsuspend(HostingAccount $account, AccountProvisioner $provisioner)
    {
        $success = $provisioner->unsuspend($account);
        if ($success) {
            return back()->with('status', 'Account unsuspended successfully.');
        }

        return back()->withErrors(['unsuspend' => 'Failed to unsuspend account on node.']);
    }
}

