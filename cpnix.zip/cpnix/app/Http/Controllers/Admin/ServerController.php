<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\AuditLog;
use App\Models\Server;
use App\Models\ServerCredential;
use App\Services\Agent\NodeAgentClient;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

class ServerController extends Controller
{
    public function index()
    {
        $servers = Server::withCount('hostingAccounts')->paginate(20);
        return view('admin.servers.index', compact('servers'));
    }

    public function create()
    {
        return view('admin.servers.create');
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'name' => ['required', 'string', 'max:255', 'unique:servers,name'],
            'hostname' => ['required', 'string', 'max:255', 'unique:servers,hostname'],
            'ip_address' => ['required', 'ip', 'unique:servers,ip_address'],
            'port' => ['required', 'integer', 'min:1', 'max:65535'],
            'os_family' => ['required', 'in:ubuntu,rhel,debian'],
            'max_accounts' => ['required', 'integer', 'min:1', 'max:5000'],
        ]);

        $server = Server::create(array_merge($validated, [
            'status' => 'offline',
            'is_active' => true,
        ]));

        // Generate initial shared HMAC secret for node agent
        $authToken = Str::random(48);
        ServerCredential::create([
            'server_id' => $server->id,
            'auth_token' => $authToken,
        ]);

        AuditLog::record('server.enrolled', 'Server', $server->id, ['name' => $server->name]);

        return redirect()->route('admin.servers.show', $server)
            ->with('status', 'Server registered successfully. Deploy cpnix-agent with the generated token.');
    }

    public function show(Server $server)
    {
        $server->load(['hostingAccounts' => fn($q) => $q->take(10), 'credential']);
        return view('admin.servers.show', compact('server'));
    }

    public function testConnection(Server $server)
    {
        $agent = new NodeAgentClient($server);
        $ping = $agent->ping();

        if ($ping['success']) {
            $server->update([
                'status' => 'online',
                'last_heartbeat_at' => now(),
                'latest_telemetry' => $ping['data'] ?? null,
            ]);

            return back()->with('status', 'Node agent connection verified successfully.');
        }

        $server->update(['status' => 'unreachable']);
        return back()->withErrors(['connection' => 'Node agent unreachable: ' . ($ping['error'] ?? 'Unknown error')]);
    }
}

