<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\AuditLog;
use App\Models\Server;
use App\Services\Agent\NodeAgentClient;
use Illuminate\Http\Request;

class ServiceController extends Controller
{
    public function index(Request $request)
    {
        $servers = Server::where('is_active', true)->get();
        $selectedServerId = $request->input('server_id', $servers->first()?->id);
        $currentServer = $servers->firstWhere('id', $selectedServerId) ?? $servers->first();

        $services = [
            ['name' => 'nginx', 'display' => 'Nginx Web Server', 'category' => 'Web', 'status' => 'active'],
            ['name' => 'php8.2-fpm', 'display' => 'PHP 8.2 FastCGI Process Manager', 'category' => 'Runtime', 'status' => 'active'],
            ['name' => 'mariadb', 'display' => 'MariaDB Relational Database Server', 'category' => 'Database', 'status' => 'active'],
            ['name' => 'redis-server', 'display' => 'Redis Cache & Queue Store', 'category' => 'Queue', 'status' => 'active'],
            ['name' => 'pdns', 'display' => 'PowerDNS Authoritative Server', 'category' => 'DNS', 'status' => 'active'],
            ['name' => 'postfix', 'display' => 'Postfix Mail Transfer Agent (MTA)', 'category' => 'Mail', 'status' => 'active'],
            ['name' => 'dovecot', 'display' => 'Dovecot IMAP/POP3 Server (MDA)', 'category' => 'Mail', 'status' => 'active'],
            ['name' => 'cpnix-agent', 'display' => 'CPNix Node Agent Daemon', 'category' => 'Agent', 'status' => 'active'],
        ];

        return view('admin.services.index', compact('servers', 'currentServer', 'services'));
    }

    public function operate(Request $request, Server $server)
    {
        $validated = $request->validate([
            'service' => ['required', 'string', 'in:nginx,php8.2-fpm,mariadb,redis-server,pdns,postfix,dovecot'],
            'action' => ['required', 'in:reload,restart'],
        ]);

        $agent = new NodeAgentClient($server);
        // Dispatch validated operation
        $res = $agent->dispatch('/api/v1/service/action', [
            'service' => $validated['service'],
            'action' => $validated['action'],
        ]);

        AuditLog::record("service.{$validated['action']}", 'Server', $server->id, [
            'service' => $validated['service'],
            'server' => $server->name,
        ]);

        return back()->with('status', "Service {$validated['service']} {$validated['action']} request sent to node.");
    }
}

