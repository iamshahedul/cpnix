<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\AuditLog;
use App\Models\FirewallRule;
use App\Models\Server;
use App\Services\Agent\NodeAgentClient;
use Illuminate\Http\Request;

class FirewallController extends Controller
{
    public function index(Request $request)
    {
        $servers = Server::where('is_active', true)->get();
        $selectedServerId = $request->input('server_id', $servers->first()?->id);
        $currentServer = $servers->firstWhere('id', $selectedServerId) ?? $servers->first();

        $rules = [];
        if ($currentServer) {
            $rules = FirewallRule::where('server_id', $currentServer->id)->latest()->get();

            // Populate standard hosting ports if no rules exist yet
            if ($rules->isEmpty()) {
                $standardRules = [
                    ['port' => 22, 'protocol' => 'tcp', 'action' => 'allow', 'source_ip' => '0.0.0.0/0', 'description' => 'SSH Remote Access'],
                    ['port' => 80, 'protocol' => 'tcp', 'action' => 'allow', 'source_ip' => '0.0.0.0/0', 'description' => 'HTTP Web Traffic'],
                    ['port' => 443, 'protocol' => 'tcp', 'action' => 'allow', 'source_ip' => '0.0.0.0/0', 'description' => 'HTTPS Encrypted Web Traffic'],
                    ['port' => 8443, 'protocol' => 'tcp', 'action' => 'allow', 'source_ip' => '0.0.0.0/0', 'description' => 'CPNix Web Control Plane'],
                    ['port' => 9443, 'protocol' => 'tcp', 'action' => 'allow', 'source_ip' => '127.0.0.1/32', 'description' => 'CPNix Privileged Node Agent'],
                    ['port' => 53, 'protocol' => 'both', 'action' => 'allow', 'source_ip' => '0.0.0.0/0', 'description' => 'DNS Authoritative Resolution'],
                    ['port' => 25, 'protocol' => 'tcp', 'action' => 'allow', 'source_ip' => '0.0.0.0/0', 'description' => 'SMTP Mail Delivery'],
                    ['port' => 587, 'protocol' => 'tcp', 'action' => 'allow', 'source_ip' => '0.0.0.0/0', 'description' => 'SMTP Submission'],
                    ['port' => 993, 'protocol' => 'tcp', 'action' => 'allow', 'source_ip' => '0.0.0.0/0', 'description' => 'IMAPS Secure Mailbox'],
                ];

                foreach ($standardRules as $r) {
                    FirewallRule::create(array_merge($r, ['server_id' => $currentServer->id]));
                }
                $rules = FirewallRule::where('server_id', $currentServer->id)->get();
            }
        }

        return view('admin.firewall.index', compact('servers', 'currentServer', 'rules'));
    }

    public function store(Request $request, Server $server)
    {
        $validated = $request->validate([
            'port' => ['required', 'integer', 'min:1', 'max:65535'],
            'protocol' => ['required', 'in:tcp,udp,both'],
            'action' => ['required', 'in:allow,deny,reject'],
            'source_ip' => ['required', 'string'],
            'description' => ['nullable', 'string', 'max:255'],
        ]);

        $rule = FirewallRule::create(array_merge($validated, [
            'server_id' => $server->id,
            'is_active' => true,
        ]));

        $agent = new NodeAgentClient($server);
        $agent->dispatch('/api/v1/firewall/apply', [
            'port' => $rule->port,
            'protocol' => $rule->protocol,
            'action' => $rule->action,
            'source_ip' => $rule->source_ip,
        ]);

        AuditLog::record('firewall.rule_created', 'FirewallRule', $rule->id, [
            'server' => $server->name,
            'port' => $rule->port,
            'action' => $rule->action,
        ]);

        return back()->with('status', "Firewall rule for port {$rule->port} added successfully.");
    }

    public function destroy(FirewallRule $firewallRule)
    {
        $server = $firewallRule->server;
        $port = $firewallRule->port;
        $firewallRule->delete();

        $agent = new NodeAgentClient($server);
        $agent->dispatch('/api/v1/firewall/delete', ['port' => $port]);

        AuditLog::record('firewall.rule_deleted', 'FirewallRule', null, ['port' => $port]);

        return back()->with('status', "Firewall rule for port {$port} removed.");
    }
}

