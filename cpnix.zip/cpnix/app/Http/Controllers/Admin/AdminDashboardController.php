<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\AuditLog;
use App\Models\HostingAccount;
use App\Models\Reseller;
use App\Models\Server;
use Illuminate\Http\Request;

class AdminDashboardController extends Controller
{
    public function index()
    {
        $servers = Server::all();
        $totalServers = $servers->count();
        $onlineServers = $servers->filter(fn($s) => $s->isOnline())->count();
        $offlineServers = $totalServers - $onlineServers;

        $accounts = HostingAccount::all();
        $totalAccounts = $accounts->count();
        $activeAccounts = $accounts->where('status', 'ACTIVE')->count();
        $suspendedAccounts = $accounts->where('status', 'SUSPENDED')->count();
        $failedAccounts = $accounts->whereIn('status', ['FAILED', 'REQUIRES_REPAIR'])->count();

        $totalResellers = Reseller::count();
        $recentAuditLogs = AuditLog::latest()->take(10)->get();

        return view('admin.dashboard', compact(
            'servers',
            'totalServers',
            'onlineServers',
            'offlineServers',
            'totalAccounts',
            'activeAccounts',
            'suspendedAccounts',
            'failedAccounts',
            'totalResellers',
            'recentAuditLogs'
        ));
    }
}

