<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\AuditLog;
use App\Models\HostingPackage;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

class PackageController extends Controller
{
    public function index()
    {
        $packages = HostingPackage::withCount('hostingAccounts')->paginate(20);
        return view('admin.packages.index', compact('packages'));
    }

    public function create()
    {
        return view('admin.packages.create');
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'name' => ['required', 'string', 'max:255', 'unique:hosting_packages,name'],
            'description' => ['nullable', 'string'],
            'disk_quota_mb' => ['required', 'integer', 'min:100'],
            'bandwidth_quota_mb' => ['required', 'integer', 'min:500'],
            'max_domains' => ['required', 'integer', 'min:1'],
            'max_subdomains' => ['required', 'integer', 'min:0'],
            'max_databases' => ['required', 'integer', 'min:0'],
            'max_email_accounts' => ['required', 'integer', 'min:0'],
            'max_cron_jobs' => ['required', 'integer', 'min:0'],
            'backup_retention_days' => ['required', 'integer', 'min:1', 'max:90'],
        ]);

        $package = HostingPackage::create(array_merge($validated, [
            'slug' => Str::slug($validated['name']),
            'allowed_php_versions' => ['7.4', '8.0', '8.1', '8.2', '8.3'],
            'allow_custom_dns' => true,
            'allow_ssl_management' => true,
            'is_active' => true,
        ]));

        AuditLog::record('package.created', 'HostingPackage', $package->id, ['name' => $package->name]);

        return redirect()->route('admin.packages.index')->with('status', 'Package created successfully.');
    }
}

