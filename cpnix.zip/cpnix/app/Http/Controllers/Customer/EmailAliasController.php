<?php

namespace App\Http\Controllers\Customer;

use App\Http\Controllers\Controller;
use App\Models\AuditLog;
use App\Models\EmailAlias;
use App\Models\HostingAccount;
use App\Services\Agent\NodeAgentClient;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class EmailAliasController extends Controller
{
    public function store(Request $request)
    {
        $account = $this->getAuthenticatedAccount();

        $validated = $request->validate([
            'source_local' => ['required', 'string', 'regex:/^[a-zA-Z0-9_\-\.]+$/'],
            'source_domain' => ['required', 'string'],
            'destination_email' => ['required', 'email'],
        ]);

        $sourceEmail = strtolower($validated['source_local']) . '@' . strtolower($validated['source_domain']);

        if (EmailAlias::where('source_email', $sourceEmail)->exists()) {
            return back()->withErrors(['source_local' => 'An email forwarder for this address already exists.']);
        }

        $alias = EmailAlias::create([
            'hosting_account_id' => $account->id,
            'source_email' => $sourceEmail,
            'destination_email' => strtolower($validated['destination_email']),
            'is_active' => true,
        ]);

        // Sync with Postfix virtual alias database on node
        $agent = new NodeAgentClient($account->server);
        $agent->dispatch('/api/v1/mail/alias/sync', [
            'domain' => $validated['source_domain'],
            'source' => $sourceEmail,
            'destination' => $validated['destination_email'],
        ]);

        AuditLog::record('email_alias.created', 'EmailAlias', $alias->id, [
            'source' => $sourceEmail,
            'destination' => $validated['destination_email'],
        ]);

        return back()->with('status', "Email forwarder {$sourceEmail} -> {$validated['destination_email']} created.");
    }

    public function destroy(EmailAlias $emailAlias)
    {
        $account = $this->getAuthenticatedAccount();
        if ($emailAlias->hosting_account_id !== $account->id) {
            abort(403, 'Unauthorized access to email forwarder.');
        }

        $src = $emailAlias->source_email;
        $emailAlias->delete();

        $agent = new NodeAgentClient($account->server);
        $agent->dispatch('/api/v1/mail/alias/delete', ['source' => $src]);

        AuditLog::record('email_alias.deleted', 'EmailAlias', null, ['source' => $src]);

        return back()->with('status', "Email forwarder for {$src} removed.");
    }

    protected function getAuthenticatedAccount(): HostingAccount
    {
        return HostingAccount::where('user_id', Auth::id())->firstOrFail();
    }
}

