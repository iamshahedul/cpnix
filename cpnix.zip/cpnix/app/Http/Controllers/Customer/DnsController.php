<?php

namespace App\Http\Controllers\Customer;

use App\Http\Controllers\Controller;
use App\Models\AuditLog;
use App\Models\DnsRecord;
use App\Models\DnsZone;
use App\Models\HostingAccount;
use App\Services\Agent\NodeAgentClient;
use App\Services\Dns\PowerDnsManager;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class DnsController extends Controller
{
    public function index(Request $request)
    {
        $account = $this->getAuthenticatedAccount();
        $zones = $account->dnsZones()->with('records')->get();

        // If no zones exist yet, auto-provision default zone for primary domain
        if ($zones->isEmpty()) {
            $zone = $account->dnsZones()->create([
                'name' => $account->primary_domain,
                'primary_ns' => config('cpnix.dns.default_ns1', 'ns1.cpnix.org'),
                'admin_email' => 'hostmaster.' . $account->primary_domain,
                'serial' => (int) (date('Ymd') . '01'),
                'ttl' => 3600,
            ]);

            // Add standard default DNS records
            $defaultRecords = [
                ['name' => '@', 'type' => 'A', 'content' => $account->server->ip_address, 'ttl' => 3600],
                ['name' => 'www', 'type' => 'CNAME', 'content' => $account->primary_domain . '.', 'ttl' => 3600],
                ['name' => 'mail', 'type' => 'A', 'content' => $account->server->ip_address, 'ttl' => 3600],
                ['name' => '@', 'type' => 'MX', 'content' => 'mail.' . $account->primary_domain . '.', 'priority' => 10, 'ttl' => 3600],
                ['name' => '@', 'type' => 'TXT', 'content' => '"v=spf1 a mx ~all"', 'ttl' => 3600],
            ];

            foreach ($defaultRecords as $r) {
                $zone->records()->create($r);
            }

            $zones = $account->dnsZones()->with('records')->get();
        }

        $selectedZoneId = $request->input('zone_id', $zones->first()->id);
        $currentZone = $zones->firstWhere('id', $selectedZoneId) ?? $zones->first();

        return view('customer.dns.index', compact('account', 'zones', 'currentZone'));
    }

    public function storeRecord(Request $request)
    {
        $account = $this->getAuthenticatedAccount();

        $validated = $request->validate([
            'dns_zone_id' => ['required', 'exists:dns_zones,id'],
            'name' => ['required', 'string', 'max:255'],
            'type' => ['required', 'in:A,AAAA,CNAME,MX,TXT,NS,SRV,CAA'],
            'content' => ['required', 'string'],
            'ttl' => ['required', 'integer', 'min:60', 'max:86400'],
            'priority' => ['nullable', 'integer', 'min:0', 'max:65535'],
        ]);

        $zone = $account->dnsZones()->findOrFail($validated['dns_zone_id']);

        // Syntax and RFC validation via PowerDnsManager
        $validation = PowerDnsManager::validateRecord(
            $validated['type'],
            $validated['name'],
            $validated['content'],
            $validated['priority'] ? (int) $validated['priority'] : null
        );

        if (!$validation['valid']) {
            return back()->withErrors(['content' => $validation['error']])->withInput();
        }

        $record = $zone->records()->create([
            'name' => $validated['name'],
            'type' => $validated['type'],
            'content' => $validated['content'],
            'ttl' => $validated['ttl'],
            'priority' => $validated['priority'] ? (int) $validated['priority'] : null,
        ]);

        $zone->incrementSerial();

        // Sync with authoritative DNS agent
        $agent = new NodeAgentClient($account->server);
        $agent->syncDnsZone($zone->name, $zone->records->toArray());

        AuditLog::record('dns.record_created', 'DnsRecord', $record->id, [
            'zone' => $zone->name,
            'name' => $record->name,
            'type' => $record->type,
        ]);

        return back()->with('status', "DNS {$record->type} record added successfully.");
    }

    public function destroyRecord(DnsRecord $record)
    {
        $account = $this->getAuthenticatedAccount();
        $zone = $record->zone;

        if ($zone->hosting_account_id !== $account->id) {
            abort(403, 'Unauthorized access to DNS record.');
        }

        $recordDetails = ['zone' => $zone->name, 'name' => $record->name, 'type' => $record->type];
        $record->delete();
        $zone->incrementSerial();

        $agent = new NodeAgentClient($account->server);
        $agent->syncDnsZone($zone->name, $zone->records->toArray());

        AuditLog::record('dns.record_deleted', 'DnsRecord', null, $recordDetails);

        return back()->with('status', 'DNS record deleted successfully.');
    }

    protected function getAuthenticatedAccount(): HostingAccount
    {
        return HostingAccount::where('user_id', Auth::id())->firstOrFail();
    }
}

