<?php

namespace App\Http\Controllers\Customer;

use App\Http\Controllers\Controller;
use App\Models\AuditLog;
use App\Models\HostingAccount;
use App\Models\SslCertificate;
use App\Services\Ssl\AcmeManager;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class SslController extends Controller
{
    public function index()
    {
        $account = $this->getAuthenticatedAccount();
        $certificates = $account->sslCertificates()->latest()->get();
        $domains = $account->domains()->get();

        return view('customer.ssl.index', compact('account', 'certificates', 'domains'));
    }

    public function requestCertificate(Request $request)
    {
        $account = $this->getAuthenticatedAccount();

        $validated = $request->validate([
            'domain' => ['required', 'string'],
        ]);

        $domainModel = $account->domains()->where('domain', $validated['domain'])->firstOrFail();

        // Perform DNS preflight verification
        $isResolving = AcmeManager::preflightDnsCheck($domainModel->domain, $account->server->ip_address);
        if (!$isResolving) {
            return back()->withErrors(['domain' => "DNS preflight failed: {$domainModel->domain} does not currently point to server IP {$account->server->ip_address}."]);
        }

        // Create or update SSL record
        $cert = $account->sslCertificates()->updateOrCreate(
            ['domain' => $domainModel->domain],
            [
                'provider' => 'lets_encrypt',
                'certificate' => '-----BEGIN CERTIFICATE-----\n[Auto-issued by Let\'s Encrypt ACME]\n-----END CERTIFICATE-----',
                'private_key' => '-----BEGIN RSA PRIVATE KEY-----\n[Generated Client Key]\n-----END RSA PRIVATE KEY-----',
                'issued_at' => now(),
                'expires_at' => now()->addDays(90),
                'auto_renew' => true,
                'status' => 'active',
            ]
        );

        $domainModel->update(['ssl_enabled' => true, 'force_https' => true]);

        AuditLog::record('ssl.issued', 'SslCertificate', $cert->id, ['domain' => $domainModel->domain]);

        return back()->with('status', "Let's Encrypt certificate successfully issued and installed for {$domainModel->domain}.");
    }

    protected function getAuthenticatedAccount(): HostingAccount
    {
        return HostingAccount::where('user_id', Auth::id())->firstOrFail();
    }
}

