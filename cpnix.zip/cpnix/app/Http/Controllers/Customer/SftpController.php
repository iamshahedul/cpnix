<?php

namespace App\Http\Controllers\Customer;

use App\Http\Controllers\Controller;
use App\Models\AuditLog;
use App\Models\HostingAccount;
use App\Models\SftpAccount;
use App\Services\Agent\NodeAgentClient;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class SftpController extends Controller
{
    public function index()
    {
        $account = $this->getAuthenticatedAccount();
        $sftpAccounts = $account->hasMany(SftpAccount::class, 'hosting_account_id')->latest()->get();

        return view('customer.sftp.index', compact('account', 'sftpAccounts'));
    }

    public function store(Request $request)
    {
        $account = $this->getAuthenticatedAccount();

        $validated = $request->validate([
            'username_suffix' => ['required', 'string', 'alpha_num', 'min:2', 'max:16'],
            'relative_dir' => ['required', 'string'],
            'public_key' => ['nullable', 'string'],
            'password' => ['nullable', 'string', 'min:8'],
        ]);

        $fullUsername = strtolower($account->username . '_' . $validated['username_suffix']);

        if (SftpAccount::where('username', $fullUsername)->exists()) {
            return back()->withErrors(['username_suffix' => 'An SFTP account with this username already exists.'])->withInput();
        }

        // Jail directory strictly within account home
        $cleanRelDir = trim($validated['relative_dir'], '/');
        $jailHome = "/home/{$account->username}/{$cleanRelDir}";

        $sftp = SftpAccount::create([
            'hosting_account_id' => $account->id,
            'username' => $fullUsername,
            'home_directory' => $jailHome,
            'public_key' => $validated['public_key'] ?? null,
            'password_auth_allowed' => !empty($validated['password']),
            'is_active' => true,
        ]);

        // Dispatch SFTP user creation to node agent
        $agent = new NodeAgentClient($account->server);
        $agent->dispatch('/api/v1/sftp/create', [
            'username' => $fullUsername,
            'parent_user' => $account->username,
            'jail_dir' => $jailHome,
            'public_key' => $validated['public_key'] ?? null,
            'password' => $validated['password'] ?? null,
        ]);

        AuditLog::record('sftp.created', 'SftpAccount', $sftp->id, [
            'username' => $fullUsername,
            'directory' => $jailHome,
        ]);

        return back()->with('status', "SFTP user {$fullUsername} created successfully.");
    }

    public function destroy(SftpAccount $sftpAccount)
    {
        $account = $this->getAuthenticatedAccount();
        if ($sftpAccount->hosting_account_id !== $account->id) {
            abort(403, 'Unauthorized access to SFTP account.');
        }

        $usr = $sftpAccount->username;
        $sftpAccount->delete();

        $agent = new NodeAgentClient($account->server);
        $agent->dispatch('/api/v1/sftp/delete', ['username' => $usr]);

        AuditLog::record('sftp.deleted', 'SftpAccount', null, ['username' => $usr]);

        return back()->with('status', "SFTP user {$usr} deleted successfully.");
    }

    protected function getAuthenticatedAccount(): HostingAccount
    {
        return HostingAccount::where('user_id', Auth::id())->firstOrFail();
    }
}

