<?php

namespace App\Http\Controllers\Customer;

use App\Http\Controllers\Controller;
use App\Models\HostingAccount;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class CustomerDashboardController extends Controller
{
    public function index(Request $request)
    {
        $user = Auth::user();
        $account = HostingAccount::where('user_id', $user->id)->with(['package', 'server'])->first();

        if (!$account) {
            return view('customer.no_account');
        }

        $account->loadCount(['domains', 'databases', 'emailAccounts', 'cronJobs', 'sslCertificates']);

        $diskUsedMb = $account->disk_used_mb;
        $diskLimitMb = $account->package->disk_quota_mb;
        $diskPercent = $diskLimitMb > 0 ? (int) min(100, round(($diskUsedMb / $diskLimitMb) * 100)) : 0;

        return view('customer.dashboard', compact(
            'account',
            'diskUsedMb',
            'diskLimitMb',
            'diskPercent'
        ));
    }
}

