<?php

namespace App\Http\Controllers\Customer;

use App\Http\Controllers\Controller;
use App\Models\HostingAccount;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class LogViewerController extends Controller
{
    public function index(Request $request)
    {
        $account = $this->getAuthenticatedAccount();
        $domains = $account->domains()->get();

        $selectedDomain = $request->input('domain', $account->primary_domain);
        $logType = $request->input('type', 'access'); // 'access' or 'error'

        $logLines = [];
        $logDir = "/home/{$account->username}/logs";
        $logFile = sprintf("%s/%s-%s.log", $logDir, $selectedDomain, $logType);

        if (file_exists($logFile)) {
            $lines = file($logFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
            if ($lines !== false) {
                $logLines = array_slice($lines, -150); // Get last 150 lines
                $logLines = array_reverse($logLines);
            }
        } else {
            // Simulated / clean initial state notice
            $logLines = [
                sprintf("[%s] Log stream initialized for %s. No entries recorded yet.", date('Y-m-d H:i:s'), $selectedDomain)
            ];
        }

        return view('customer.logs.index', compact('account', 'domains', 'selectedDomain', 'logType', 'logLines'));
    }

    protected function getAuthenticatedAccount(): HostingAccount
    {
        return HostingAccount::where('user_id', Auth::id())->firstOrFail();
    }
}

