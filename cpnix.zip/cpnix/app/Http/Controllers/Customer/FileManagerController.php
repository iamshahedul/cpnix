<?php

namespace App\Http\Controllers\Customer;

use App\Http\Controllers\Controller;
use App\Models\AuditLog;
use App\Models\HostingAccount;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class FileManagerController extends Controller
{
    public function index(Request $request)
    {
        $account = $this->getAuthenticatedAccount();
        $relativeDir = trim($request->input('path', 'public_html'), '/');

        // Check canonical boundary
        $baseHome = "/home/{$account->username}";
        $targetDir = realpath("{$baseHome}/{$relativeDir}");

        // In environments where /home is not mounted locally, evaluate path safely
        if (!$targetDir) {
            $targetDir = "{$baseHome}/{$relativeDir}";
        }

        $items = [];
        if (is_dir($targetDir)) {
            $files = scandir($targetDir);
            foreach ($files as $file) {
                if ($file === '.' || $file === '..') continue;
                $fullPath = "{$targetDir}/{$file}";
                $items[] = [
                    'name' => $file,
                    'is_dir' => is_dir($fullPath),
                    'size' => is_file($fullPath) ? filesize($fullPath) : 0,
                    'modified_at' => filemtime($fullPath),
                    'permissions' => substr(sprintf('%o', fileperms($fullPath)), -4),
                ];
            }
        }

        return view('customer.files.index', compact('account', 'relativeDir', 'items'));
    }

    public function editFile(Request $request)
    {
        $account = $this->getAuthenticatedAccount();
        $filePath = $request->input('file');
        $safePath = $this->validateAndResolvePath($account, $filePath);

        $content = file_exists($safePath) ? file_get_contents($safePath) : '';
        return view('customer.files.editor', compact('account', 'filePath', 'content'));
    }

    public function saveFile(Request $request)
    {
        $account = $this->getAuthenticatedAccount();
        $request->validate([
            'file' => ['required', 'string'],
            'content' => ['nullable', 'string'],
        ]);

        $safePath = $this->validateAndResolvePath($account, $request->input('file'));
        file_put_contents($safePath, $request->input('content', ''));

        AuditLog::record('file.edited', 'HostingAccount', $account->id, ['path' => $request->input('file')]);

        return back()->with('status', 'File saved successfully.');
    }

    protected function validateAndResolvePath(HostingAccount $account, string $relativePath): string
    {
        $baseHome = "/home/{$account->username}";
        $clean = str_replace(['../', '..\\'], '', $relativePath);
        $fullPath = rtrim($baseHome, '/') . '/' . ltrim($clean, '/');

        if (strpos($fullPath, $baseHome) !== 0) {
            abort(403, 'Path traversal attempt detected and blocked.');
        }

        return $fullPath;
    }

    protected function getAuthenticatedAccount(): HostingAccount
    {
        return HostingAccount::where('user_id', Auth::id())->firstOrFail();
    }
}

