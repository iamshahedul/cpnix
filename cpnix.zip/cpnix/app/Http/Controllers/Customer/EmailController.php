<?php

namespace App\Http\Controllers\Customer;

use App\Http\Controllers\Controller;
use App\Models\AuditLog;
use App\Models\EmailAccount;
use App\Models\HostingAccount;
use App\Services\Package\QuotaService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class EmailController extends Controller
{
    public function index()
    {
        $account = $this->getAuthenticatedAccount();
        $emailAccounts = $account->emailAccounts()->latest()->get();
        $domains = $account->domains()->get();

        return view('customer.email.index', compact('account', 'emailAccounts', 'domains'));
    }

    public function store(Request $request, QuotaService $quotaService)
    {
        $account = $this->getAuthenticatedAccount();

        $validated = $request->validate([
            'local_part' => ['required', 'string', 'regex:/^[a-zA-Z0-9_\-\.]+$/', 'max:64'],
            'domain' => ['required', 'string'],
            'password' => ['required', 'string', 'min:8'],
            'quota_mb' => ['required', 'integer', 'min:10', 'max:50000'],
        ]);

        if (!$quotaService->canAddEmailAccount($account)) {
            return back()->withErrors(['local_part' => 'Email accounts limit reached for your hosting package.']);
        }

        $fullEmail = strtolower($validated['local_part']) . '@' . strtolower($validated['domain']);

        if (EmailAccount::where('email', $fullEmail)->exists()) {
            return back()->withErrors(['local_part' => 'This email address already exists.']);
        }

        // Dovecot SHA512-CRYPT or Argon2 password hash
        $passwordHash = '{SHA512-CRYPT}' . crypt($validated['password'], '$6$' . bin2hex(random_bytes(8)));

        $email = $account->emailAccounts()->create([
            'email' => $fullEmail,
            'local_part' => strtolower($validated['local_part']),
            'domain' => strtolower($validated['domain']),
            'password_hash' => $passwordHash,
            'quota_mb' => $validated['quota_mb'],
            'used_mb' => 0,
            'is_active' => true,
        ]);

        AuditLog::record('email.created', 'EmailAccount', $email->id, ['email' => $fullEmail]);

        return back()->with('status', "Mailbox {$fullEmail} created successfully.");
    }

    protected function getAuthenticatedAccount(): HostingAccount
    {
        return HostingAccount::where('user_id', Auth::id())->firstOrFail();
    }
}

