<?php

namespace App\Http\Controllers\Customer;

use App\Http\Controllers\Controller;
use App\Models\AuditLog;
use App\Models\Database;
use App\Models\DatabaseUser;
use App\Models\HostingAccount;
use App\Services\Agent\NodeAgentClient;
use App\Services\Database\MariaDbManager;
use App\Services\Package\QuotaService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class DatabaseController extends Controller
{
    public function index()
    {
        $account = $this->getAuthenticatedAccount();
        $databases = $account->databases()->with('users')->get();
        $dbUsers = $account->databaseUsers()->get();

        return view('customer.databases.index', compact('account', 'databases', 'dbUsers'));
    }

    public function storeDatabase(Request $request, QuotaService $quotaService)
    {
        $account = $this->getAuthenticatedAccount();

        $validated = $request->validate([
            'database_name' => ['required', 'string', 'alpha_dash', 'min:1', 'max:20'],
        ]);

        if (!$quotaService->canAddDatabase($account)) {
            return back()->withErrors(['database_name' => 'Database limit reached for your package.']);
        }

        $fullDbName = MariaDbManager::formatDatabaseName($account->username, $validated['database_name']);

        if (Database::where('name', $fullDbName)->exists()) {
            return back()->withErrors(['database_name' => 'Database name already exists.']);
        }

        $db = $account->databases()->create([
            'name' => $fullDbName,
            'charset' => 'utf8mb4',
            'collation' => 'utf8mb4_unicode_ci',
        ]);

        AuditLog::record('database.created', 'Database', $db->id, ['name' => $fullDbName]);

        return back()->with('status', "Database {$fullDbName} created successfully.");
    }

    public function storeUser(Request $request)
    {
        $account = $this->getAuthenticatedAccount();

        $validated = $request->validate([
            'username' => ['required', 'string', 'alpha_dash', 'min:1', 'max:16'],
            'password' => ['required', 'string', 'min:8'],
            'database_id' => ['required', 'exists:databases,id'],
        ]);

        $fullUser = MariaDbManager::formatDatabaseUser($account->username, $validated['username']);
        $database = $account->databases()->findOrFail($validated['database_id']);

        $dbUser = $account->databaseUsers()->firstOrCreate([
            'username' => $fullUser,
            'host' => 'localhost',
        ]);

        // Grant privileges on actual database via node agent
        $agent = new NodeAgentClient($account->server);
        $agent->createDatabase($database->name, $fullUser, $validated['password']);

        $database->users()->syncWithoutDetaching([$dbUser->id => ['privileges' => json_encode(['ALL'])]]);

        AuditLog::record('database_user.created', 'DatabaseUser', $dbUser->id, [
            'user' => $fullUser,
            'database' => $database->name,
        ]);

        return back()->with('status', "User {$fullUser} created and assigned to {$database->name}.");
    }

    protected function getAuthenticatedAccount(): HostingAccount
    {
        return HostingAccount::where('user_id', Auth::id())->firstOrFail();
    }
}

