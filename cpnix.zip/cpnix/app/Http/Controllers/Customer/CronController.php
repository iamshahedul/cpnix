<?php

namespace App\Http\Controllers\Customer;

use App\Http\Controllers\Controller;
use App\Models\AuditLog;
use App\Models\CronJob;
use App\Models\HostingAccount;
use App\Services\Package\QuotaService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class CronController extends Controller
{
    public function index()
    {
        $account = $this->getAuthenticatedAccount();
        $cronJobs = $account->cronJobs()->latest()->get();

        return view('customer.cron.index', compact('account', 'cronJobs'));
    }

    public function store(Request $request, QuotaService $quotaService)
    {
        $account = $this->getAuthenticatedAccount();

        $validated = $request->validate([
            'minute' => ['required', 'string', 'max:20'],
            'hour' => ['required', 'string', 'max:20'],
            'day_of_month' => ['required', 'string', 'max:20'],
            'month' => ['required', 'string', 'max:20'],
            'day_of_week' => ['required', 'string', 'max:20'],
            'command' => ['required', 'string', 'max:1000'],
            'description' => ['nullable', 'string', 'max:255'],
        ]);

        if (!$quotaService->canAddCronJob($account)) {
            return back()->withErrors(['command' => 'Cron job limit reached for your hosting package.']);
        }

        // Validate cron schedule expression format
        $cronPattern = '/^[0-9,\-\/\*]+$/';
        foreach (['minute', 'hour', 'day_of_month', 'month', 'day_of_week'] as $field) {
            if (!preg_match($cronPattern, $validated[$field])) {
                return back()->withErrors([$field => "Invalid cron schedule expression for {$field}."])->withInput();
            }
        }

        $cron = $account->cronJobs()->create(array_merge($validated, [
            'is_active' => true,
        ]));

        AuditLog::record('cron.created', 'CronJob', $cron->id, [
            'command' => $cron->command,
            'schedule' => $cron->expression,
        ]);

        return back()->with('status', 'Cron job schedule created successfully.');
    }

    public function toggle(CronJob $cronJob)
    {
        $account = $this->getAuthenticatedAccount();
        if ($cronJob->hosting_account_id !== $account->id) {
            abort(403, 'Unauthorized access to cron job.');
        }

        $cronJob->update(['is_active' => !$cronJob->is_active]);
        $state = $cronJob->is_active ? 'enabled' : 'disabled';

        AuditLog::record('cron.toggled', 'CronJob', $cronJob->id, ['state' => $state]);

        return back()->with('status', "Cron job {$state} successfully.");
    }

    public function destroy(CronJob $cronJob)
    {
        $account = $this->getAuthenticatedAccount();
        if ($cronJob->hosting_account_id !== $account->id) {
            abort(403, 'Unauthorized access to cron job.');
        }

        $cmd = $cronJob->command;
        $cronJob->delete();

        AuditLog::record('cron.deleted', 'CronJob', null, ['command' => $cmd]);

        return back()->with('status', 'Cron job deleted successfully.');
    }

    protected function getAuthenticatedAccount(): HostingAccount
    {
        return HostingAccount::where('user_id', Auth::id())->firstOrFail();
    }
}
