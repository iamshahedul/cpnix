<?php

namespace App\Http\Controllers\Customer;

use App\Http\Controllers\Controller;
use App\Models\AccountDomain;
use App\Models\AuditLog;
use App\Models\HostingAccount;
use App\Services\Agent\NodeAgentClient;
use App\Services\Package\QuotaService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class DomainController extends Controller
{
    public function index()
    {
        $account = $this->getAuthenticatedAccount();
        $domains = $account->domains()->latest()->get();

        return view('customer.domains.index', compact('account', 'domains'));
    }

    public function store(Request $request, QuotaService $quotaService)
    {
        $account = $this->getAuthenticatedAccount();

        $validated = $request->validate([
            'domain' => ['required', 'string', 'regex:/^([a-z0-9]+(-[a-z0-9]+)*\.)+[a-z]{2,}$/i', 'unique:account_domains,domain'],
            'folder' => ['required', 'string', 'regex:/^[a-zA-Z0-9_\-\/]+$/'],
            'php_version' => ['required', 'in:7.4,8.0,8.1,8.2,8.3'],
        ]);

        if (!$quotaService->canAddDomain($account)) {
            return back()->withErrors(['domain' => 'You have reached the maximum allowed domains for your hosting package.']);
        }

        // Enforce safe path boundary inside account home
        $cleanFolder = trim($validated['folder'], '/');
        $docRoot = "/home/{$account->username}/{$cleanFolder}";

        $domain = $account->domains()->create([
            'domain' => strtolower($validated['domain']),
            'document_root' => $docRoot,
            'is_primary' => false,
            'is_subdomain' => false,
            'php_version' => $validated['php_version'],
        ]);

        // Configure vhost on server via agent
        $agent = new NodeAgentClient($account->server);
        $agent->configureVhost($domain->domain, $account->username, $docRoot, $domain->php_version, false);

        AuditLog::record('domain.created', 'AccountDomain', $domain->id, ['domain' => $domain->domain]);

        return back()->with('status', "Domain {$domain->domain} added successfully.");
    }

    protected function getAuthenticatedAccount(): HostingAccount
    {
        return HostingAccount::where('user_id', Auth::id())->firstOrFail();
    }
}

