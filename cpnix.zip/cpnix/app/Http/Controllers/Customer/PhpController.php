<?php

namespace App\Http\Controllers\Customer;

use App\Http\Controllers\Controller;
use App\Models\AuditLog;
use App\Models\HostingAccount;
use App\Services\Agent\NodeAgentClient;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class PhpController extends Controller
{
    public function index()
    {
        $account = $this->getAuthenticatedAccount();
        $allowedVersions = $account->package->allowed_php_versions ?? config('cpnix.server.supported_php');

        // Current account resource settings
        $settings = $account->resource_limits['php'] ?? [
            'memory_limit' => '256M',
            'max_execution_time' => '120',
            'upload_max_filesize' => '64M',
            'post_max_size' => '64M',
            'display_errors' => 'Off',
        ];

        return view('customer.php.index', compact('account', 'allowedVersions', 'settings'));
    }

    public function updateVersion(Request $request)
    {
        $account = $this->getAuthenticatedAccount();
        $allowedVersions = $account->package->allowed_php_versions ?? config('cpnix.server.supported_php');

        $validated = $request->validate([
            'php_version' => ['required', 'in:' . implode(',', $allowedVersions)],
        ]);

        $oldVersion = $account->php_version;
        $account->update(['php_version' => $validated['php_version']]);

        // Reconfigure PHP-FPM pool and web vhosts on node agent
        $agent = new NodeAgentClient($account->server);
        $agent->configurePhpPool($account->username, $validated['php_version']);

        foreach ($account->domains as $domain) {
            $agent->configureVhost(
                $domain->domain,
                $account->username,
                $domain->document_root,
                $validated['php_version'],
                $domain->ssl_enabled
            );
        }

        AuditLog::record('php.version_changed', 'HostingAccount', $account->id, [
            'old_version' => $oldVersion,
            'new_version' => $validated['php_version'],
        ]);

        return back()->with('status', "PHP runtime switched to PHP {$validated['php_version']} successfully.");
    }

    public function updateDirectives(Request $request)
    {
        $account = $this->getAuthenticatedAccount();

        $validated = $request->validate([
            'memory_limit' => ['required', 'in:128M,256M,512M,1024M'],
            'max_execution_time' => ['required', 'in:30,60,120,300'],
            'upload_max_filesize' => ['required', 'in:16M,32M,64M,128M'],
            'display_errors' => ['required', 'in:On,Off'],
        ]);

        $limits = $account->resource_limits ?? [];
        $limits['php'] = $validated;
        $account->update(['resource_limits' => $limits]);

        // Re-apply pool settings via node agent
        $agent = new NodeAgentClient($account->server);
        $agent->configurePhpPool($account->username, $account->php_version);

        AuditLog::record('php.directives_updated', 'HostingAccount', $account->id, $validated);

        return back()->with('status', 'PHP directives updated and pool reloaded successfully.');
    }

    protected function getAuthenticatedAccount(): HostingAccount
    {
        return HostingAccount::where('user_id', Auth::id())->firstOrFail();
    }
}

