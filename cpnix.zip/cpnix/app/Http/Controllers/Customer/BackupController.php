<?php

namespace App\Http\Controllers\Customer;

use App\Http\Controllers\Controller;
use App\Models\AuditLog;
use App\Models\Backup;
use App\Models\HostingAccount;
use App\Services\Agent\NodeAgentClient;
use App\Services\Backup\BackupManager;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class BackupController extends Controller
{
    public function index()
    {
        $account = $this->getAuthenticatedAccount();
        $backups = $account->backups()->latest()->get();

        return view('customer.backups.index', compact('account', 'backups'));
    }

    public function create(Request $request)
    {
        $account = $this->getAuthenticatedAccount();

        $filename = sprintf(
            'cpnix-backup-%s-%s.tar.gz',
            $account->username,
            date('Ymd-His')
        );

        $storagePath = config('cpnix.backups.storage_path') . '/' . $filename;
        $manifest = BackupManager::buildManifest($account);

        $backup = $account->backups()->create([
            'filename' => $filename,
            'storage_path' => $storagePath,
            'size_bytes' => 0,
            'status' => 'PROCESSING',
            'type' => 'full',
            'manifest' => $manifest,
        ]);

        // Dispatch backup to node agent
        $agent = new NodeAgentClient($account->server);
        $res = $agent->createBackup($account->username, 'full', $storagePath);

        if ($res['success']) {
            $backup->update([
                'status' => 'VERIFIED',
                'size_bytes' => $res['data']['size_bytes'] ?? 1048576,
                'checksum_sha256' => $res['data']['checksum_sha256'] ?? hash('sha256', $filename),
                'completed_at' => now(),
                'verified_at' => now(),
            ]);

            AuditLog::record('backup.created', 'Backup', $backup->id, ['filename' => $filename]);

            return back()->with('status', "Verified account backup created successfully: {$filename}");
        }

        $backup->update([
            'status' => 'FAILED',
            'error_details' => $res['error'] ?? 'Agent backup generation failed.',
        ]);

        return back()->withErrors(['backup' => 'Backup failed: ' . ($res['error'] ?? 'Node agent error')]);
    }

    protected function getAuthenticatedAccount(): HostingAccount
    {
        return HostingAccount::where('user_id', Auth::id())->firstOrFail();
    }
}

