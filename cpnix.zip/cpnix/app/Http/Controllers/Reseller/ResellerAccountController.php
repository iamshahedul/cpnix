<?php

namespace App\Http\Controllers\Reseller;

use App\Http\Controllers\Controller;
use App\Models\AuditLog;
use App\Models\HostingAccount;
use App\Models\HostingPackage;
use App\Models\Reseller;
use App\Models\Server;
use App\Models\User;
use App\Services\Package\QuotaService;
use App\Services\Provisioning\AccountProvisioner;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;

class ResellerAccountController extends Controller
{
    public function index()
    {
        $reseller = Reseller::where('user_id', Auth::id())->firstOrFail();
        $accounts = HostingAccount::where('reseller_id', $reseller->id)
            ->with(['package', 'server'])
            ->latest()
            ->paginate(20);

        return view('reseller.accounts.index', compact('accounts', 'reseller'));
    }

    public function create()
    {
        $reseller = Reseller::where('user_id', Auth::id())->firstOrFail();
        
        // Permitted servers
        $permittedServerIds = $reseller->permitted_servers ?? Server::where('is_active', true)->pluck('id')->toArray();
        $servers = Server::whereIn('id', $permittedServerIds)->where('is_active', true)->get();

        // Reseller packages
        $packages = HostingPackage::where(function ($q) use ($reseller) {
            $q->where('reseller_id', $reseller->id)
              ->orWhereNull('reseller_id');
        })->where('is_active', true)->get();

        return view('reseller.accounts.create', compact('reseller', 'servers', 'packages'));
    }

    public function store(Request $request, QuotaService $quotaService, AccountProvisioner $provisioner)
    {
        $reseller = Reseller::where('user_id', Auth::id())->firstOrFail();

        $validated = $request->validate([
            'domain' => ['required', 'string', 'regex:/^([a-z0-9]+(-[a-z0-9]+)*\.)+[a-z]{2,}$/i', 'unique:hosting_accounts,primary_domain'],
            'username' => ['required', 'string', 'alpha_num', 'min:3', 'max:16', 'unique:hosting_accounts,username'],
            'password' => ['required', 'string', 'min:8'],
            'owner_email' => ['required', 'email'],
            'server_id' => ['required', 'exists:servers,id'],
            'package_id' => ['required', 'exists:hosting_packages,id'],
            'php_version' => ['required', 'in:7.4,8.0,8.1,8.2,8.3'],
        ]);

        $package = HostingPackage::findOrFail($validated['package_id']);

        // Enforce hierarchical reseller capacity check
        $capacity = $quotaService->validateResellerCapacity($reseller, $package);
        if (!$capacity['allowed']) {
            return back()->withErrors(['package_id' => $capacity['reason']])->withInput();
        }

        return DB::transaction(function () use ($validated, $reseller, $provisioner) {
            $user = User::firstOrCreate(
                ['email' => $validated['owner_email']],
                [
                    'name' => $validated['username'],
                    'password' => Hash::make($validated['password']),
                    'role' => 'customer',
                ]
            );

            $maxUid = HostingAccount::max('uid') ?? 10000;
            $nextUid = max(10001, $maxUid + 1);

            $account = HostingAccount::create([
                'user_id' => $user->id,
                'reseller_id' => $reseller->id,
                'server_id' => $validated['server_id'],
                'package_id' => $validated['package_id'],
                'username' => strtolower($validated['username']),
                'uid' => $nextUid,
                'gid' => $nextUid,
                'primary_domain' => strtolower($validated['domain']),
                'home_directory' => '/home/' . strtolower($validated['username']),
                'php_version' => $validated['php_version'],
                'status' => 'PENDING',
            ]);

            $account->domains()->create([
                'domain' => strtolower($validated['domain']),
                'document_root' => '/home/' . strtolower($validated['username']) . '/public_html',
                'is_primary' => true,
                'is_subdomain' => false,
                'php_version' => $validated['php_version'],
            ]);

            AuditLog::record('reseller.account_created', 'HostingAccount', $account->id);

            $provisioner->provision($account);

            return redirect()->route('reseller.accounts.index')
                ->with('status', 'Customer account created and queued for provisioning.');
        });
    }

    public function suspend(Request $request, HostingAccount $account, AccountProvisioner $provisioner)
    {
        $reseller = Reseller::where('user_id', Auth::id())->firstOrFail();
        if ($account->reseller_id !== $reseller->id) {
            abort(403, 'Unauthorized access to customer account.');
        }

        $provisioner->suspend($account, 'Suspended by reseller.');
        return back()->with('status', 'Account suspended.');
    }

    public function unsuspend(HostingAccount $account, AccountProvisioner $provisioner)
    {
        $reseller = Reseller::where('user_id', Auth::id())->firstOrFail();
        if ($account->reseller_id !== $reseller->id) {
            abort(403, 'Unauthorized access to customer account.');
        }

        $provisioner->unsuspend($account);
        return back()->with('status', 'Account unsuspended.');
    }
}

