<?php

namespace App\Http\Controllers\Reseller;

use App\Http\Controllers\Controller;
use App\Models\AuditLog;
use App\Models\HostingPackage;
use App\Models\Reseller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Str;

class ResellerPackageController extends Controller
{
    public function index()
    {
        $reseller = Reseller::where('user_id', Auth::id())->firstOrFail();
        $packages = HostingPackage::where('reseller_id', $reseller->id)
            ->withCount('hostingAccounts')
            ->latest()
            ->paginate(20);

        return view('reseller.packages.index', compact('reseller', 'packages'));
    }

    public function create()
    {
        $reseller = Reseller::where('user_id', Auth::id())->firstOrFail();
        return view('reseller.packages.create', compact('reseller'));
    }

    public function store(Request $request)
    {
        $reseller = Reseller::where('user_id', Auth::id())->firstOrFail();

        $validated = $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'description' => ['nullable', 'string'],
            'disk_quota_mb' => ['required', 'integer', 'min:100', 'max:' . $reseller->disk_quota_mb],
            'bandwidth_quota_mb' => ['required', 'integer', 'min:500', 'max:' . $reseller->bandwidth_quota_mb],
            'max_domains' => ['required', 'integer', 'min:1', 'max:50'],
            'max_subdomains' => ['required', 'integer', 'min:0', 'max:100'],
            'max_databases' => ['required', 'integer', 'min:0', 'max:100'],
            'max_email_accounts' => ['required', 'integer', 'min:0', 'max:200'],
            'max_cron_jobs' => ['required', 'integer', 'min:0', 'max:20'],
        ]);

        $package = HostingPackage::create(array_merge($validated, [
            'reseller_id' => $reseller->id,
            'slug' => Str::slug($validated['name']) . '-' . Str::random(5),
            'allowed_php_versions' => config('cpnix.server.supported_php'),
            'allow_custom_dns' => true,
            'allow_ssl_management' => true,
            'backup_retention_days' => 7,
            'is_active' => true,
        ]));

        AuditLog::record('reseller.package_created', 'HostingPackage', $package->id, ['name' => $package->name]);

        return redirect()->route('reseller.packages.index')->with('status', "Package {$package->name} created successfully.");
    }
}

