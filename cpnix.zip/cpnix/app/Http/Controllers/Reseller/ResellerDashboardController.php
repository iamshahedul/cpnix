<?php

namespace App\Http\Controllers\Reseller;

use App\Http\Controllers\Controller;
use App\Models\HostingAccount;
use App\Models\Reseller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class ResellerDashboardController extends Controller
{
    public function index()
    {
        $reseller = Reseller::where('user_id', Auth::id())->firstOrFail();
        $accounts = HostingAccount::where('reseller_id', $reseller->id)->get();

        $totalAccounts = $accounts->count();
        $activeAccounts = $accounts->where('status', 'ACTIVE')->count();
        $suspendedAccounts = $accounts->where('status', 'SUSPENDED')->count();

        $usedDiskMb = $reseller->totalAllocatedDiskMb();
        $totalDiskMb = $reseller->disk_quota_mb;
        $diskPercentage = $totalDiskMb > 0 ? (int) round(($usedDiskMb / $totalDiskMb) * 100) : 0;

        return view('reseller.dashboard', compact(
            'reseller',
            'accounts',
            'totalAccounts',
            'activeAccounts',
            'suspendedAccounts',
            'usedDiskMb',
            'totalDiskMb',
            'diskPercentage'
        ));
    }
}

