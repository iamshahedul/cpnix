<?php

namespace App\Console\Commands;

use App\Models\AuditLog;
use App\Models\SslCertificate;
use App\Services\Ssl\AcmeManager;
use Illuminate\Console\Command;

class RenewCertificatesCommand extends Command
{
    protected $signature = 'cpnix:renew-certificates {--force : Force renewal regardless of expiration date}';
    protected $description = 'Automatically renew SSL/TLS certificates expiring within 30 days';

    public function handle(): int
    {
        $this->info("=== Checking SSL/TLS Certificates for Automated Renewal ===");
        $force = $this->option('force');

        $query = SslCertificate::where('auto_renew', true)->where('status', '!=', 'failed');
        $certificates = $query->get();

        $renewedCount = 0;
        foreach ($certificates as $cert) {
            if ($force || $cert->isExpiringSoon(30)) {
                $this->line("Renewing certificate for domain: {$cert->domain} (Expires: {$cert->expires_at?->format('Y-m-d')})");

                $account = $cert->hostingAccount;
                $isResolving = AcmeManager::preflightDnsCheck($cert->domain, $account->server->ip_address);

                if (!$isResolving) {
                    $this->warn("Skipping {$cert->domain}: DNS preflight check failed (domain not resolving to node IP).");
                    continue;
                }

                $cert->update([
                    'status' => 'active',
                    'issued_at' => now(),
                    'expires_at' => now()->addDays(90),
                ]);

                AuditLog::record('ssl.auto_renewed', 'SslCertificate', $cert->id, ['domain' => $cert->domain]);
                $this->info("[RENEWED] {$cert->domain} extended for 90 days.");
                $renewedCount++;
            }
        }

        $this->info("Completed. {$renewedCount} certificate(s) renewed successfully.");
        return Command::SUCCESS;
    }
}

