<?php

namespace App\Console\Commands;

use App\Models\AuditLog;
use App\Models\Backup;
use Illuminate\Console\Command;

class PruneBackupsCommand extends Command
{
    protected $signature = 'cpnix:prune-backups';
    protected $description = 'Enforce retention policy and prune aged backup archives';

    public function handle(): int
    {
        $this->info("=== Pruning Aged Backup Archives ===");
        $defaultRetentionDays = config('cpnix.backups.retention_days', 14);

        $prunedCount = 0;
        $backups = Backup::with('hostingAccount.package')->get();

        foreach ($backups as $b) {
            $retentionDays = $b->hostingAccount?->package?->backup_retention_days ?? $defaultRetentionDays;
            $cutoffDate = now()->subDays($retentionDays);

            if ($b->created_at < $cutoffDate) {
                $this->line("Pruning backup {$b->filename} (created {$b->created_at->diffForHumans()})");

                if (file_exists($b->storage_path)) {
                    @unlink($b->storage_path);
                }

                $filename = $b->filename;
                $b->delete();
                AuditLog::record('backup.pruned', 'Backup', null, ['filename' => $filename]);
                $prunedCount++;
            }
        }

        $this->info("Completed. {$prunedCount} aged backup archive(s) pruned.");
        return Command::SUCCESS;
    }
}

