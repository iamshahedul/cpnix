<?php

namespace App\Services\Dns;

use App\Models\DnsZone;
use Exception;

class PowerDnsManager
{
    /**
     * Validate DNS record syntax
     */
    public static function validateRecord(string $type, string $name, string $content, ?int $priority = null): array
    {
        $type = strtoupper($type);
        $allowedTypes = ['A', 'AAAA', 'CNAME', 'MX', 'TXT', 'NS', 'SRV', 'CAA', 'PTR'];

        if (!in_array($type, $allowedTypes)) {
            return ['valid' => false, 'error' => "Unsupported record type {$type}."];
        }

        if ($type === 'A' && !filter_var($content, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
            return ['valid' => false, 'error' => "Invalid IPv4 address format for A record."];
        }

        if ($type === 'AAAA' && !filter_var($content, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6)) {
            return ['valid' => false, 'error' => "Invalid IPv6 address format for AAAA record."];
        }

        if ($type === 'MX' && ($priority === null || $priority < 0 || $priority > 65535)) {
            return ['valid' => false, 'error' => "MX record requires a valid priority between 0 and 65535."];
        }

        return ['valid' => true, 'error' => null];
    }

    /**
     * Format BIND-compatible zone file representation
     */
    public static function exportBindZone(DnsZone $zone): string
    {
        $out = [];
        $out[] = "; CPNix Authoritative DNS Zone Export: {$zone->name}";
        $out[] = "\$TTL {$zone->ttl}";
        $out[] = "@ IN SOA {$zone->primary_ns}. {$zone->admin_email}. (";
        $out[] = "    {$zone->serial} ; Serial";
        $out[] = "    {$zone->refresh} ; Refresh";
        $out[] = "    {$zone->retry} ; Retry";
        $out[] = "    {$zone->expire} ; Expire";
        $out[] = "    {$zone->ttl} ) ; Minimum TTL";
        $out[] = "";

        foreach ($zone->records as $r) {
            $p = $r->priority !== null ? "{$r->priority} " : "";
            $out[] = sprintf("%-24s %-6s IN %-6s %s%s", $r->name, $r->ttl, $r->type, $p, $r->content);
        }

        return implode("\n", $out) . "\n";
    }
}

