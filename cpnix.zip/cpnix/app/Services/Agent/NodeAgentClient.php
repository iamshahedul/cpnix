<?php

namespace App\Services\Agent;

use App\Models\Server;
use Exception;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;

class NodeAgentClient
{
    protected Server $server;
    protected int $timeout;

    public function __construct(Server $server, int $timeout = 30)
    {
        $this->server = $server;
        $this->timeout = $timeout;
    }

    /**
     * Send signed RPC request to node agent
     */
    public function dispatch(string $endpoint, array $payload = []): array
    {
        $endpoint = '/' . ltrim($endpoint, '/');
        $baseUrl = sprintf('https://%s:%d', $this->server->ip_address, $this->server->port);
        $url = $baseUrl . $endpoint;

        $credential = $this->server->credential;
        $sharedSecret = $credential ? $credential->auth_token : 'cpnix_default_node_token';

        $timestamp = (string) time();
        $nonce = Str::random(16);
        $jsonBody = json_encode($payload);

        // Generate HMAC-SHA256 signature
        $messageToSign = sprintf("POST\n%s\n%s\n%s\n%s", $endpoint, $timestamp, $nonce, $jsonBody);
        $signature = hash_hmac('sha256', $messageToSign, $sharedSecret);

        $headers = [
            'Accept' => 'application/json',
            'Content-Type' => 'application/json',
            'X-CPNix-Timestamp' => $timestamp,
            'X-CPNix-Nonce' => $nonce,
            'X-CPNix-Signature' => $signature,
        ];

        try {
            $options = [
                'timeout' => $this->timeout,
                'verify' => false, // Set to true with CA bundle in full mTLS production
            ];

            // In actual mTLS mode with local or remote certificates:
            if (config('cpnix.agent.mtls_enabled') && $credential && $credential->client_certificate) {
                // Attach client cert & ca bundle
                $options['cert'] = [$credential->client_certificate, $credential->client_private_key];
                $options['ssl_key'] = $credential->client_private_key;
            }

            $response = Http::withHeaders($headers)
                ->withOptions($options)
                ->post($url, $payload);

            if ($response->failed()) {
                Log::error("Node Agent Error [{$this->server->hostname}] {$endpoint}: " . $response->body());
                return [
                    'success' => false,
                    'error' => $response->json('error') ?? $response->body() ?? 'Agent request failed with HTTP ' . $response->status(),
                    'status_code' => $response->status(),
                ];
            }

            return [
                'success' => true,
                'data' => $response->json(),
                'status_code' => $response->status(),
            ];
        } catch (Exception $e) {
            Log::error("Node Agent Connection Exception [{$this->server->hostname}]: " . $e->getMessage());
            return [
                'success' => false,
                'error' => 'Agent connection failed: ' . $e->getMessage(),
                'status_code' => 500,
            ];
        }
    }

    /**
     * Check node health and collect telemetry
     */
    public function ping(): array
    {
        return $this->dispatch('/api/v1/health');
    }

    /**
     * Fetch real-time system metrics (CPU, RAM, Inodes, Disks)
     */
    public function getMetrics(): array
    {
        return $this->dispatch('/api/v1/metrics');
    }

    /**
     * Create isolated Linux user and directory tree
     */
    public function createLinuxAccount(string $username, int $uid, int $gid, string $homeDir, ?int $diskQuotaMb): array
    {
        return $this->dispatch('/api/v1/account/create', [
            'username' => $username,
            'uid' => $uid,
            'gid' => $gid,
            'home_dir' => $homeDir,
            'disk_quota_mb' => $diskQuotaMb,
        ]);
    }

    /**
     * Configure isolated PHP-FPM pool for account
     */
    public function configurePhpPool(string $username, string $phpVersion, int $maxChildren = 10): array
    {
        return $this->dispatch('/api/v1/php/pool', [
            'username' => $username,
            'php_version' => $phpVersion,
            'max_children' => $maxChildren,
        ]);
    }

    /**
     * Deploy and test Nginx virtual host configuration
     */
    public function configureVhost(string $domain, string $username, string $documentRoot, string $phpVersion, bool $sslEnabled = false): array
    {
        return $this->dispatch('/api/v1/web/vhost', [
            'domain' => $domain,
            'username' => $username,
            'document_root' => $documentRoot,
            'php_version' => $phpVersion,
            'ssl_enabled' => $sslEnabled,
        ]);
    }

    /**
     * Provision MariaDB database and scoped user
     */
    public function createDatabase(string $dbName, string $dbUser, string $dbPassword): array
    {
        return $this->dispatch('/api/v1/database/create', [
            'database' => $dbName,
            'username' => $dbUser,
            'password' => $dbPassword,
        ]);
    }

    /**
     * Apply DNS Zone changes
     */
    public function syncDnsZone(string $zoneName, array $records): array
    {
        return $this->dispatch('/api/v1/dns/sync', [
            'zone' => $zoneName,
            'records' => $records,
        ]);
    }

    /**
     * Suspend account (lock user, disable vhost, stop pool)
     */
    public function suspendAccount(string $username): array
    {
        return $this->dispatch('/api/v1/account/suspend', [
            'username' => $username,
        ]);
    }

    /**
     * Unsuspend account
     */
    public function unsuspendAccount(string $username): array
    {
        return $this->dispatch('/api/v1/account/unsuspend', [
            'username' => $username,
        ]);
    }

    /**
     * Terminate account and purge data
     */
    public function terminateAccount(string $username): array
    {
        return $this->dispatch('/api/v1/account/terminate', [
            'username' => $username,
        ]);
    }

    /**
     * Execute verified backup creation on node
     */
    public function createBackup(string $username, string $backupType, string $destinationPath): array
    {
        return $this->dispatch('/api/v1/backup/create', [
            'username' => $username,
            'type' => $backupType,
            'destination' => $destinationPath,
        ]);
    }
}

