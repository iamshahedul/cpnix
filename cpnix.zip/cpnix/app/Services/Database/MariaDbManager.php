<?php

namespace App\Services\Database;

use App\Models\HostingAccount;
use Exception;

class MariaDbManager
{
    /**
     * Sanitize and format database identifier (prefixed with account username)
     */
    public static function formatDatabaseName(string $username, string $customSuffix): string
    {
        $sanitizedSuffix = preg_replace('/[^a-zA-Z0-9_]/', '', $customSuffix);
        $fullName = "{$username}_{$sanitizedSuffix}";
        
        // MariaDB identifier limit is 64 chars
        if (strlen($fullName) > 64) {
            throw new Exception("Database name exceeds maximum allowable length of 64 characters.");
        }

        return strtolower($fullName);
    }

    /**
     * Sanitize and format database username
     */
    public static function formatDatabaseUser(string $username, string $customSuffix): string
    {
        $sanitizedSuffix = preg_replace('/[^a-zA-Z0-9_]/', '', $customSuffix);
        $fullUser = "{$username}_{$sanitizedSuffix}";

        // MariaDB user limit is 32 chars in modern versions
        if (strlen($fullUser) > 32) {
            throw new Exception("Database username exceeds maximum allowable length of 32 characters.");
        }

        return strtolower($fullUser);
    }

    /**
     * Generate safe SQL statements for least-privilege customer database creation
     */
    public static function generateProvisionSql(string $dbName, string $dbUser, string $dbPassword, string $host = 'localhost'): array
    {
        return [
            "CREATE DATABASE IF NOT EXISTS `{$dbName}` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;",
            "CREATE USER IF NOT EXISTS '{$dbUser}'@'{$host}' IDENTIFIED BY " . self::escapePassword($dbPassword) . ";",
            "GRANT ALL PRIVILEGES ON `{$dbName}`.* TO '{$dbUser}'@'{$host}';",
            "FLUSH PRIVILEGES;",
        ];
    }

    protected static function escapePassword(string $password): string
    {
        return "'" . addslashes($password) . "'";
    }
}

