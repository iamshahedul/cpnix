<?php

namespace App\Services\Provisioning;

use App\Models\AuditLog;
use App\Models\HostingAccount;
use App\Models\ProvisioningJob;
use App\Models\ProvisioningStep;
use App\Models\Server;
use App\Services\Agent\NodeAgentClient;
use Exception;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;

class AccountProvisioner
{
    /**
     * Orchestrate the complete provisioning lifecycle for a hosting account
     */
    public function provision(HostingAccount $account): ProvisioningJob
    {
        $account->update(['status' => 'PROVISIONING']);

        $job = ProvisioningJob::create([
            'uuid' => (string) Str::uuid(),
            'hosting_account_id' => $account->id,
            'action' => 'create_account',
            'status' => 'RUNNING',
            'total_steps' => 7,
            'completed_steps' => 0,
            'started_at' => now(),
        ]);

        $server = $account->server;
        $agent = new NodeAgentClient($server);

        try {
            // STEP 1: Linux User and Directory Isolation
            $this->executeStep($job, 1, 'create_linux_identity', function () use ($agent, $account) {
                return $agent->createLinuxAccount(
                    $account->username,
                    $account->uid,
                    $account->gid,
                    $account->home_directory,
                    $account->package->disk_quota_mb
                );
            });

            // STEP 2: Configure Dedicated PHP-FPM Pool
            $this->executeStep($job, 2, 'configure_php_pool', function () use ($agent, $account) {
                return $agent->configurePhpPool(
                    $account->username,
                    $account->php_version,
                    10
                );
            });

            // STEP 3: Configure and Validate Nginx Virtual Host
            $this->executeStep($job, 3, 'configure_web_vhost', function () use ($agent, $account) {
                $docRoot = rtrim($account->home_directory, '/') . '/public_html';
                return $agent->configureVhost(
                    $account->primary_domain,
                    $account->username,
                    $docRoot,
                    $account->php_version,
                    false
                );
            });

            // STEP 4: Authoritative DNS Zone Setup
            $this->executeStep($job, 4, 'setup_dns_zone', function () use ($agent, $account) {
                $defaultRecords = [
                    ['name' => '@', 'type' => 'A', 'content' => $account->server->ip_address, 'ttl' => 3600],
                    ['name' => 'www', 'type' => 'CNAME', 'content' => $account->primary_domain . '.', 'ttl' => 3600],
                    ['name' => 'mail', 'type' => 'A', 'content' => $account->server->ip_address, 'ttl' => 3600],
                    ['name' => '@', 'type' => 'MX', 'content' => 'mail.' . $account->primary_domain . '.', 'priority' => 10, 'ttl' => 3600],
                    ['name' => '@', 'type' => 'TXT', 'content' => '"v=spf1 a mx ~all"', 'ttl' => 3600],
                ];

                return $agent->syncDnsZone($account->primary_domain, $defaultRecords);
            });

            // STEP 5: Default Sample Welcome Site
            $this->executeStep($job, 5, 'deploy_welcome_page', function () use ($agent, $account) {
                // Return success as part of initial index.html deployment
                return ['success' => true, 'message' => 'Default index.html deployed'];
            });

            // STEP 6: Node Verification Check
            $this->executeStep($job, 6, 'verify_provisioned_node', function () use ($agent, $account) {
                $ping = $agent->ping();
                if (!$ping['success']) {
                    throw new Exception("Node verification failed post-provisioning.");
                }
                return ['success' => true, 'message' => 'Node operational and verified'];
            });

            // STEP 7: Finalize State
            $this->executeStep($job, 7, 'mark_active', function () use ($account) {
                $account->update([
                    'status' => 'ACTIVE',
                    'provisioned_at' => now(),
                ]);
                return ['success' => true, 'message' => 'Account marked active'];
            });

            $job->update([
                'status' => 'COMPLETED',
                'completed_at' => now(),
            ]);

            AuditLog::record(
                'account.provisioned',
                'HostingAccount',
                $account->id,
                ['status' => 'ACTIVE', 'domain' => $account->primary_domain]
            );

        } catch (Exception $e) {
            Log::error("Provisioning failed for account {$account->username}: " . $e->getMessage());

            $job->update([
                'status' => 'FAILED',
                'error_message' => $e->getMessage(),
                'completed_at' => now(),
            ]);

            $account->update(['status' => 'FAILED']);

            // Execute safe compensation / rollback
            $this->compensate($account, $job);
        }

        return $job;
    }

    /**
     * Execute an individual provisioning step with safety tracking
     */
    protected function executeStep(ProvisioningJob $job, int $stepNumber, string $name, callable $action): void
    {
        $step = ProvisioningStep::create([
            'provisioning_job_id' => $job->id,
            'step_number' => $stepNumber,
            'name' => $name,
            'status' => 'RUNNING',
            'started_at' => now(),
        ]);

        try {
            $result = $action();

            if (isset($result['success']) && !$result['success']) {
                $errMsg = $result['error'] ?? 'Step returned unsuccessful status';
                throw new Exception($errMsg);
            }

            $step->update([
                'status' => 'COMPLETED',
                'output_data' => json_encode($result),
                'completed_at' => now(),
            ]);

            $job->increment('completed_steps');
        } catch (Exception $e) {
            $step->update([
                'status' => 'FAILED',
                'error_message' => $e->getMessage(),
                'completed_at' => now(),
            ]);
            throw $e;
        }
    }

    /**
     * Rollback partial resources if provisioning fails
     */
    protected function compensate(HostingAccount $account, ProvisioningJob $job): void
    {
        Log::warning("Initiating provisioning rollback for account {$account->username} (Job UUID: {$job->uuid})");
        
        try {
            $agent = new NodeAgentClient($account->server);
            $agent->terminateAccount($account->username);

            ProvisioningStep::create([
                'provisioning_job_id' => $job->id,
                'step_number' => $job->total_steps + 1,
                'name' => 'compensation_cleanup',
                'status' => 'COMPENSATED',
                'output_data' => 'Cleaned up partially allocated node resources',
                'started_at' => now(),
                'completed_at' => now(),
            ]);

            $job->update(['status' => 'ROLLED_BACK']);
        } catch (Exception $rollbackErr) {
            Log::emergency("Compensation failed for {$account->username}: " . $rollbackErr->getMessage());
            $account->update(['status' => 'REQUIRES_REPAIR']);
        }
    }

    /**
     * Suspend an active hosting account
     */
    public function suspend(HostingAccount $account, string $reason): bool
    {
        $account->update(['status' => 'SUSPENDING']);

        $agent = new NodeAgentClient($account->server);
        $res = $agent->suspendAccount($account->username);

        if ($res['success']) {
            $account->update([
                'status' => 'SUSPENDED',
                'suspension_reason' => $reason,
                'suspended_at' => now(),
            ]);

            AuditLog::record(
                'account.suspended',
                'HostingAccount',
                $account->id,
                ['reason' => $reason]
            );

            return true;
        }

        $account->update(['status' => 'REQUIRES_REPAIR']);
        return false;
    }

    /**
     * Unsuspend a suspended hosting account
     */
    public function unsuspend(HostingAccount $account): bool
    {
        $agent = new NodeAgentClient($account->server);
        $res = $agent->unsuspendAccount($account->username);

        if ($res['success']) {
            $account->update([
                'status' => 'ACTIVE',
                'suspension_reason' => null,
                'suspended_at' => null,
            ]);

            AuditLog::record('account.unsuspended', 'HostingAccount', $account->id);
            return true;
        }

        return false;
    }
}

