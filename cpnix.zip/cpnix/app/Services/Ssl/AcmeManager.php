<?php

namespace App\Services\Ssl;

use App\Models\HostingAccount;
use App\Models\SslCertificate;
use Exception;
use Illuminate\Support\Facades\Log;

class AcmeManager
{
    /**
     * Check if domain points to this server before attempting ACME challenge
     */
    public static function preflightDnsCheck(string $domain, string $expectedIp): bool
    {
        $resolvedIps = @dns_get_record($domain, DNS_A);
        if (!$resolvedIps) {
            return false;
        }

        foreach ($resolvedIps as $rec) {
            if (isset($rec['ip']) && $rec['ip'] === $expectedIp) {
                return true;
            }
        }

        return false;
    }

    /**
     * Parse and inspect certificate metadata
     */
    public static function inspectCertificate(string $pemCert): ?array
    {
        $parsed = openssl_x509_parse($pemCert);
        if (!$parsed) {
            return null;
        }

        return [
            'subject' => $parsed['subject']['CN'] ?? null,
            'issuer' => $parsed['issuer']['O'] ?? ($parsed['issuer']['CN'] ?? 'Unknown'),
            'valid_from' => date('Y-m-d H:i:s', $parsed['validFrom_time_t']),
            'valid_to' => date('Y-m-d H:i:s', $parsed['validTo_time_t']),
            'is_expired' => $parsed['validTo_time_t'] < time(),
            'san' => isset($parsed['extensions']['subjectAltName']) ? explode(', ', $parsed['extensions']['subjectAltName']) : [],
        ];
    }
}

