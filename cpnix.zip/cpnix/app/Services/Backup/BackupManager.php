<?php

namespace App\Services\Backup;

use App\Models\Backup;
use App\Models\HostingAccount;
use Exception;
use Illuminate\Support\Facades\File;

class BackupManager
{
    /**
     * Compute SHA256 checksum of completed backup file
     */
    public static function calculateChecksum(string $filePath): string
    {
        if (!file_exists($filePath)) {
            throw new Exception("Backup file not found at: {$filePath}");
        }
        return hash_file('sha256', $filePath);
    }

    /**
     * Build the structured manifest for an account backup
     */
    public static function buildManifest(HostingAccount $account): array
    {
        return [
            'version' => '1.0',
            'created_at' => now()->toIso8601String(),
            'generator' => 'CPNix ' . config('cpnix.version'),
            'account' => [
                'username' => $account->username,
                'uid' => $account->uid,
                'gid' => $account->gid,
                'primary_domain' => $account->primary_domain,
                'home_directory' => $account->home_directory,
                'php_version' => $account->php_version,
            ],
            'domains' => $account->domains->map(fn($d) => [
                'domain' => $d->domain,
                'document_root' => $d->document_root,
                'is_primary' => $d->is_primary,
                'is_subdomain' => $d->is_subdomain,
            ])->toArray(),
            'databases' => $account->databases->pluck('name')->toArray(),
            'database_users' => $account->databaseUsers->pluck('username')->toArray(),
            'email_accounts' => $account->emailAccounts->pluck('email')->toArray(),
            'cron_jobs' => $account->cronJobs->map(fn($c) => [
                'expression' => $c->expression,
                'command' => $c->command,
            ])->toArray(),
        ];
    }
}

