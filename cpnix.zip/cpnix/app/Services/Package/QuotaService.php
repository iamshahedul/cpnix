<?php

namespace App\Services\Package;

use App\Models\HostingPackage;
use App\Models\Reseller;
use Exception;

class QuotaService
{
    /**
     * Validate that a reseller has sufficient capacity to allocate a package or create an account
     */
    public function validateResellerCapacity(Reseller $reseller, HostingPackage $package): array
    {
        // 1. Check account count
        $currentAccounts = $reseller->hostingAccounts()->count();
        if ($currentAccounts >= $reseller->max_accounts) {
            return [
                'allowed' => false,
                'reason' => "Reseller has reached the maximum permitted accounts ({$reseller->max_accounts}).",
            ];
        }

        // 2. Check cumulative disk allocation
        $allocatedDisk = $reseller->hostingAccounts()
            ->join('hosting_packages', 'hosting_accounts.package_id', '=', 'hosting_packages.id')
            ->sum('hosting_packages.disk_quota_mb');

        if (($allocatedDisk + $package->disk_quota_mb) > $reseller->disk_quota_mb) {
            $remainingMb = max(0, $reseller->disk_quota_mb - $allocatedDisk);
            return [
                'allowed' => false,
                'reason' => "Insufficient reseller disk quota. Requested: {$package->disk_quota_mb} MB, Available: {$remainingMb} MB.",
            ];
        }

        // 3. Check bandwidth quota
        $allocatedBandwidth = $reseller->hostingAccounts()
            ->join('hosting_packages', 'hosting_accounts.package_id', '=', 'hosting_packages.id')
            ->sum('hosting_packages.bandwidth_quota_mb');

        if (($allocatedBandwidth + $package->bandwidth_quota_mb) > $reseller->bandwidth_quota_mb) {
            $remainingBw = max(0, $reseller->bandwidth_quota_mb - $allocatedBandwidth);
            return [
                'allowed' => false,
                'reason' => "Insufficient reseller bandwidth quota. Requested: {$package->bandwidth_quota_mb} MB, Available: {$remainingBw} MB.",
            ];
        }

        return ['allowed' => true, 'reason' => null];
    }

    /**
     * Check if a hosting account can add another domain
     */
    public function canAddDomain(\App\Models\HostingAccount $account): bool
    {
        $currentDomains = $account->domains()->where('is_subdomain', false)->count();
        return $currentDomains < $account->package->max_domains;
    }

    /**
     * Check if a hosting account can add another database
     */
    public function canAddDatabase(\App\Models\HostingAccount $account): bool
    {
        return $account->databases()->count() < $account->package->max_databases;
    }

    /**
     * Check if a hosting account can add another email account
     */
    public function canAddEmailAccount(\App\Models\HostingAccount $account): bool
    {
        return $account->emailAccounts()->count() < $account->package->max_email_accounts;
    }

    /**
     * Check if a hosting account can add another cron job
     */
    public function canAddCronJob(\App\Models\HostingAccount $account): bool
    {
        return $account->cronJobs()->count() < $account->package->max_cron_jobs;
    }
}

