<?php

namespace App\Services\WebServer;

class ApacheManager
{
    /**
     * Generate an isolated Apache 2.4 VirtualHost configuration with mod_proxy_fcgi
     */
    public static function generateVhostConfig(
        string $domain,
        string $username,
        string $documentRoot,
        string $phpVersion,
        bool $sslEnabled = false
    ): string {
        $phpSocket = "/run/php/php-fpm-cpnix-{$username}.sock";
        $accessLog = "/home/{$username}/logs/{$domain}-access.log";
        $errorLog = "/home/{$username}/logs/{$domain}-error.log";

        $config = <<<APACHE
# CPNix Generated Apache 2.4 VirtualHost - {$domain}
# Account Owner: {$username}
# PHP Version: {$phpVersion}

<VirtualHost *:80>
    ServerName {$domain}
    ServerAlias www.{$domain}
    DocumentRoot "{$documentRoot}"

    CustomLog "{$accessLog}" combined
    ErrorLog "{$errorLog}"

    <Directory "{$documentRoot}">
        Options -Indexes +FollowSymLinks
        AllowOverride All
        Require all granted
    </Directory>

    # Route PHP requests to isolated PHP-FPM Unix socket via mod_proxy_fcgi
    <FilesMatch \.php$>
        SetHandler "proxy:unix:{$phpSocket}|fcgi://localhost"
    </FilesMatch>

    # ACME Let's Encrypt webroot challenge
    Alias /.well-known/acme-challenge/ "/var/cpnix/acme-challenges/"
    <Directory "/var/cpnix/acme-challenges/">
        AllowOverride None
        Require all granted
    </Directory>
</VirtualHost>
APACHE;

        return $config;
    }
}

