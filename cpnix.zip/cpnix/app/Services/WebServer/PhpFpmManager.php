<?php

namespace App\Services\WebServer;

class PhpFpmManager
{
    /**
     * Generate an isolated PHP-FPM pool configuration string
     */
    public static function generatePoolConfig(
        string $username,
        string $homeDirectory,
        int $maxChildren = 10,
        int $startServers = 2,
        int $minSpareServers = 1,
        int $maxSpareServers = 3
    ): string {
        $socketPath = "/run/php/php-fpm-cpnix-{$username}.sock";
        $tmpDir = rtrim($homeDirectory, '/') . '/tmp';

        $config = <<<INI
; CPNix Isolated PHP-FPM Pool for [{$username}]
[cpnix-{$username}]
user = {$username}
group = {$username}

listen = {$socketPath}
listen.owner = {$username}
listen.group = cpnix-web
listen.mode = 0660

pm = ondemand
pm.max_children = {$maxChildren}
pm.process_idle_timeout = 60s
pm.max_requests = 1000

; Jail execution to customer home directory
php_admin_value[open_basedir] = {$homeDirectory}:/tmp:/usr/share/php:/usr/share/pear
php_admin_value[upload_tmp_dir] = {$tmpDir}
php_admin_value[session.save_path] = {$tmpDir}
php_admin_value[soap.wsdl_cache_dir] = {$tmpDir}

; Disable dangerous administrative shell execution
php_admin_value[disable_functions] = exec,passthru,shell_exec,system,proc_open,popen,show_source,posix_getpwuid,posix_kill

; Resource Limits
php_admin_value[memory_limit] = 256M
php_admin_value[max_execution_time] = 120
php_admin_value[post_max_size] = 64M
php_admin_value[upload_max_filesize] = 64M

catch_workers_output = yes
decorate_workers_output = no
INI;

        return $config;
    }
}

