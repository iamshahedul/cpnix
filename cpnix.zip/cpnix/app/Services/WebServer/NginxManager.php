<?php

namespace App\Services\WebServer;

class NginxManager
{
    /**
     * Generate an isolated Nginx server block configuration string
     */
    public static function generateVhostConfig(
        string $domain,
        string $username,
        string $documentRoot,
        string $phpVersion,
        bool $sslEnabled = false,
        bool $forceHttps = false
    ): string {
        $phpSocket = "/run/php/php-fpm-cpnix-{$username}.sock";
        $accessLog = "/home/{$username}/logs/{$domain}-access.log";
        $errorLog = "/home/{$username}/logs/{$domain}-error.log";

        $config = <<<NGINX
# CPNix Generated Virtual Host - {$domain}
# Account Owner: {$username}
# PHP Version: {$phpVersion}

server {
    listen 80;
    listen [::]:80;
    server_name {$domain} www.{$domain};

    root {$documentRoot};
    index index.php index.html index.htm;

    access_log {$accessLog} combined;
    error_log {$errorLog} warn;

    # Security Headers
    add_header X-Content-Type-Options nosniff always;
    add_header X-XSS-Protection "1; mode=block" always;
    add_header X-Frame-Options SAMEORIGIN always;

    # Deny access to hidden files
    location ~ /\. {
        deny all;
        access_log off;
        log_not_found off;
    }

    # ACME Let's Encrypt challenge webroot
    location ^~ /.well-known/acme-challenge/ {
        default_type "text/plain";
        root /var/cpnix/acme-challenges;
    }

    location / {
        try_files \$uri \$uri/ /index.php?\$args;
    }

    location ~ \.php$ {
        include fastcgi_params;
        fastcgi_intercept_errors on;
        fastcgi_index index.php;
        fastcgi_param SCRIPT_FILENAME \$document_root\$fastcgi_script_name;
        fastcgi_param PATH_INFO \$fastcgi_path_info;
        fastcgi_pass unix:{$phpSocket};
        fastcgi_read_timeout 300s;
    }
}
NGINX;

        return $config;
    }
}

