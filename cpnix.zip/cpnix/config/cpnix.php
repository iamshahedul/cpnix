<?php

return [
    'version' => '1.0.0',
    'domain' => env('APP_URL', 'https://cpnix.org'),

    /*
    |--------------------------------------------------------------------------
    | Node Agent Communication Settings
    |--------------------------------------------------------------------------
    |
    | Configuration for mutual TLS and signed RPC between the control plane
    | and distributed or local cpnix-agent nodes.
    |
    */
    'agent' => [
        'default_port' => env('CPNIX_AGENT_DEFAULT_PORT', 9443),
        'timeout' => env('CPNIX_AGENT_TIMEOUT', 30),
        'mtls_enabled' => env('CPNIX_AGENT_MTLS_ENABLED', true),
        'ca_cert_path' => env('CPNIX_AGENT_CA_CERT', '/etc/cpnix/certs/ca.crt'),
        'client_cert_path' => env('CPNIX_AGENT_CLIENT_CERT', '/etc/cpnix/certs/client.crt'),
        'client_key_path' => env('CPNIX_AGENT_CLIENT_KEY', '/etc/cpnix/certs/client.key'),
        'signature_algorithm' => 'sha256',
        'replay_window_seconds' => 60,
    ],

    /*
    |--------------------------------------------------------------------------
    | System Software & Runtime Configuration
    |--------------------------------------------------------------------------
    */
    'server' => [
        'web' => env('CPNIX_WEB_SERVER', 'nginx'),
        'default_php' => env('CPNIX_DEFAULT_PHP_VERSION', '8.2'),
        'supported_php' => explode(',', env('CPNIX_ALLOWED_PHP_VERSIONS', '7.4,8.0,8.1,8.2,8.3')),
        'database_engine' => 'mariadb',
        'dns_server' => 'powerdns',
        'mail_stack' => [
            'mta' => 'postfix',
            'mda' => 'dovecot',
            'dkim' => 'opendkim',
        ],
    ],

    /*
    |--------------------------------------------------------------------------
    | Hosting Account Defaults & System Boundaries
    |--------------------------------------------------------------------------
    */
    'accounts' => [
        'uid_min' => 10000,
        'uid_max' => 65000,
        'base_home_dir' => '/home',
        'web_group' => 'cpnix-web',
        'default_shell' => '/bin/false',
        'sftp_shell' => '/usr/lib/openssh/sftp-server',
        'reserved_usernames' => [
            'root', 'admin', 'administrator', 'cpnix', 'daemon', 'bin', 'sys',
            'sync', 'games', 'man', 'lp', 'mail', 'news', 'uucp', 'proxy',
            'www-data', 'nginx', 'apache', 'mysql', 'mariadb', 'postfix',
            'dovecot', 'named', 'pdns', 'redis', 'nobody', 'sshd', 'systemd',
        ],
    ],

    /*
    |--------------------------------------------------------------------------
    | DNS Defaults
    |--------------------------------------------------------------------------
    */
    'dns' => [
        'default_ns1' => env('CPNIX_NAMESERVER_1', 'ns1.cpnix.org'),
        'default_ns2' => env('CPNIX_NAMESERVER_2', 'ns2.cpnix.org'),
        'default_ttl' => 3600,
        'soa_refresh' => 10800,
        'soa_retry' => 3600,
        'soa_expire' => 604800,
        'soa_minimum' => 3600,
    ],

    /*
    |--------------------------------------------------------------------------
    | Backup Defaults
    |--------------------------------------------------------------------------
    */
    'backups' => [
        'storage_path' => env('CPNIX_BACKUP_STORAGE_PATH', '/var/cpnix/backups'),
        'retention_days' => (int) env('CPNIX_BACKUP_RETENTION_DAYS', 14),
        'compression' => 'gzip', // 'gzip' or 'zstd'
        'verify_checksum' => true,
    ],
];

