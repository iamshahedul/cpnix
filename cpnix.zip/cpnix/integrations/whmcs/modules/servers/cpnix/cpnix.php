<?php
/**
 * CPNix WHMCS Server Provisioning Module
 *
 * @copyright Copyright (c) CPNix (https://cpnix.org)
 * @license Apache-2.0
 */

if (!defined("WHMCS")) {
    die("This file cannot be accessed directly");
}

function cpnix_MetaData()
{
    return [
        'DisplayName' => 'CPNix Hosting Control Panel',
        'APIVersion' => '1.1',
        'RequiresServer' => true,
        'DefaultNonSSLPort' => '8443',
        'DefaultSSLPort' => '8443',
    ];
}

function cpnix_ConfigOptions()
{
    return [
        'package_id' => [
            'Type' => 'text',
            'Size' => '5',
            'Description' => 'Package ID defined in CPNix Control Plane',
        ],
        'php_version' => [
            'Type' => 'dropdown',
            'Options' => '8.2,8.3,8.1,8.0,7.4',
            'Description' => 'Default PHP runtime version',
        ],
    ];
}

function cpnix_CreateAccount(array $params)
{
    try {
        $serverHost = $params['serverhostname'] ?: $params['serverip'];
        $apiUrl = sprintf('https://%s:%s/api/v1/accounts', $serverHost, $params['serverport'] ?: '8443');
        $apiToken = $params['serveraccesshash'] ?: $params['serverpassword'];

        $postData = [
            'domain' => $params['domain'],
            'username' => $params['username'],
            'password' => $params['password'],
            'owner_email' => $params['clientsdetails']['email'],
            'server_id' => 1, // Default cluster node or configurable
            'package_id' => (int) $params['configoption1'],
            'php_version' => $params['configoption2'] ?: '8.2',
        ];

        $response = cpnix_ApiRequest('POST', $apiUrl, $postData, $apiToken);

        if (!empty($response['success'])) {
            return 'success';
        }

        return $response['error']['message'] ?? 'Account provisioning failed on CPNix';
    } catch (\Exception $e) {
        return $e->getMessage();
    }
}

function cpnix_SuspendAccount(array $params)
{
    try {
        $serverHost = $params['serverhostname'] ?: $params['serverip'];
        $apiUrl = sprintf('https://%s:%s/api/v1/accounts/suspend-by-domain', $serverHost, $params['serverport'] ?: '8443');
        $apiToken = $params['serveraccesshash'] ?: $params['serverpassword'];

        $response = cpnix_ApiRequest('POST', $apiUrl, [
            'domain' => $params['domain'],
            'reason' => $params['suspendreason'] ?: 'Suspended by billing system',
        ], $apiToken);

        return !empty($response['success']) ? 'success' : ($response['error'] ?? 'Suspension failed');
    } catch (\Exception $e) {
        return $e->getMessage();
    }
}

function cpnix_UnsuspendAccount(array $params)
{
    try {
        $serverHost = $params['serverhostname'] ?: $params['serverip'];
        $apiUrl = sprintf('https://%s:%s/api/v1/accounts/unsuspend-by-domain', $serverHost, $params['serverport'] ?: '8443');
        $apiToken = $params['serveraccesshash'] ?: $params['serverpassword'];

        $response = cpnix_ApiRequest('POST', $apiUrl, ['domain' => $params['domain']], $apiToken);
        return !empty($response['success']) ? 'success' : ($response['error'] ?? 'Unsuspension failed');
    } catch (\Exception $e) {
        return $e->getMessage();
    }
}

function cpnix_TerminateAccount(array $params)
{
    try {
        $serverHost = $params['serverhostname'] ?: $params['serverip'];
        $apiUrl = sprintf('https://%s:%s/api/v1/accounts/terminate-by-domain', $serverHost, $params['serverport'] ?: '8443');
        $apiToken = $params['serveraccesshash'] ?: $params['serverpassword'];

        $response = cpnix_ApiRequest('POST', $apiUrl, ['domain' => $params['domain']], $apiToken);
        return !empty($response['success']) ? 'success' : ($response['error'] ?? 'Termination failed');
    } catch (\Exception $e) {
        return $e->getMessage();
    }
}

function cpnix_TestConnection(array $params)
{
    try {
        $serverHost = $params['serverhostname'] ?: $params['serverip'];
        $apiUrl = sprintf('https://%s:%s/api/v1/servers', $serverHost, $params['serverport'] ?: '8443');
        $apiToken = $params['serveraccesshash'] ?: $params['serverpassword'];

        $response = cpnix_ApiRequest('GET', $apiUrl, [], $apiToken);
        return [
            'success' => !empty($response['success']),
            'error' => $response['error']['message'] ?? '',
        ];
    } catch (\Exception $e) {
        return ['success' => false, 'error' => $e->getMessage()];
    }
}

function cpnix_ClientArea(array $params)
{
    $serverHost = $params['serverhostname'] ?: $params['serverip'];
    $panelUrl = sprintf('https://%s:%s', $serverHost, $params['serverport'] ?: '8443');

    return [
        'templatefile' => 'clientarea',
        'vars' => [
            'panelUrl' => $panelUrl,
            'domain' => $params['domain'],
            'username' => $params['username'],
        ],
    ];
}

function cpnix_ApiRequest(string $method, string $url, array $data, string $token): array
{
    $ch = curl_init();
    $headers = [
        'Accept: application/json',
        'Content-Type: application/json',
        'Authorization: Bearer ' . $token,
    ];

    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); // Toggle based on commercial cert
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);

    if ($method === 'POST') {
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
    }

    $raw = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    $json = json_decode($raw, true);
    return is_array($json) ? $json : ['success' => false, 'error' => ['message' => "HTTP {$httpCode}: {$raw}"]];
}

